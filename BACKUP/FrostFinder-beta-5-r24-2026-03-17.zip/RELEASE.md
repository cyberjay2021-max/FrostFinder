
# FrostFinder — Release Notes

| Field       | Value                              |
|-------------|------------------------------------|
| **Build**  | FrostFinder-beta-5-r24-2026-03-17 |
| **Status** | Beta |
| **Version**| 5 |
| **Revision**| 24 |
| **Date**   | 2026-03-17 |

---

## What's in Beta-5-r24

**Rust recompile required.** Two `main.rs` fixes for `zip 2` and Tauri v2 lifetime changes.

### Fix — `FileOptions::default()` ambiguous type parameter (`src-tauri/src/main.rs`)

**Root cause:** `zip 2` made `FileOptions` generic — `FileOptions<'k, T: FileOptionExtension>` — where `T` can be either `()` (no extended options) or `ExtendedFileOptions`. `FileOptions::default()` no longer infers `T` without a usage site that constrains it, so rustc cannot resolve the `FileOptionExtension` bound (E0283).

**Fix:** Added turbofish `FileOptions::<()>::default()`. The `()` type satisfies `FileOptionExtension`, is the correct default for standard zip entries, and requires no behaviour change.

```rust
// Before
let options = FileOptions::default()
    .compression_method(zip::CompressionMethod::Deflated)
    .unix_permissions(0o755);

// After
let options = FileOptions::<()>::default()
    .compression_method(zip::CompressionMethod::Deflated)
    .unix_permissions(0o755);
```

---

### Fix — `app.handle()` borrows `app`, escapes `setup` closure lifetime (`src-tauri/src/main.rs`)

**Root cause:** In Tauri v2, `app` inside `.setup(|app| {...})` has type `&'1 mut tauri::App` — a reference valid only for the closure body. `app.handle()` returns `&'1 AppHandle`, also tied to that lifetime. `std::thread::spawn` requires a `'static` closure, so moving the borrowed handle into the drive hot-plug thread fails with E0521.

**Fix:** `app.handle().clone()`. `AppHandle` implements `Clone` + `Send` + `'static` — the clone is an owned, Arc-backed handle that outlives the setup closure and is safe to move into a `'static` thread.

```rust
// Before — borrowed reference, tied to setup closure lifetime
let app_handle = app.handle();
std::thread::spawn(move || { ... });

// After — owned clone, 'static, safe for thread::spawn
let app_handle = app.handle().clone();
std::thread::spawn(move || { ... });
```

---

## What's in Beta-5-r23

**Rust recompile required.** Four `main.rs` fixes for `image 0.25` and Tauri v2 API changes.

### Fix — `image::ImageOutputFormat` removed in `image 0.25` (`src-tauri/src/main.rs`)

**Root cause:** `image 0.25` removed `ImageOutputFormat` entirely. The two `write_to(..., image::ImageOutputFormat::Jpeg(N))` call sites — one in the thumbnail-from-video path (quality 85) and one in the thumbnail-from-image path (quality 80) — no longer compile.

**Fix:** Replaced both sites with `write_with_encoder(JpegEncoder::new_with_quality(&mut cursor, N))`. This is the correct `image 0.25` pattern for quality-controlled JPEG output and preserves the original quality values.

```rust
// Before (image 0.24)
dyn_thumb.write_to(&mut std::io::Cursor::new(&mut buf), image::ImageOutputFormat::Jpeg(85))
    .map_err(|e| e.to_string())?;

// After (image 0.25)
{
    let mut cursor = std::io::Cursor::new(&mut buf);
    let encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(&mut cursor, 85);
    dyn_thumb.write_with_encoder(encoder).map_err(|e| e.to_string())?;
}
```

---

### Fix — `image::io::Reader` deprecated → `image::ImageReader` (`src-tauri/src/main.rs`)

**Root cause:** `image::io::Reader` was moved and renamed to `image::ImageReader` in `image 0.25`. Still compiles with a deprecation warning, but fixed now to keep the build warning-clean.

```rust
// Before
let reader = image::io::Reader::open(p)...
// After
let reader = image::ImageReader::open(p)...
```

---

### Fix — `use tauri::Emitter` missing — all `.emit()` calls fail (`src-tauri/src/main.rs`)

**Root cause:** In Tauri v2, `Emitter` is a trait (not a blanket re-export). `Window`, `WebviewWindow`, and `AppHandle` all implement it, but the trait must be explicitly imported for `.emit()` to be in scope. The 33 `.emit()` call sites across streaming directory listing, file operations, trash, compress, extract, ISO-burn, and drive-watch functions all failed with `E0599`.

**Fix:** Added `Emitter` to the existing `tauri` import on line 12:

```rust
// Before
use tauri::{Window, Manager};
// After
use tauri::{Window, Manager, Emitter};
```

---

### Fix — `app_handle.emit_all()` removed in Tauri v2 (`src-tauri/src/main.rs`)

**Root cause:** `emit_all()` was removed in Tauri v2. The drive hot-plug watcher used it to broadcast `drives-changed` to all windows. In v2, `app_handle.emit()` broadcasts to all windows by default.

```rust
// Before (Tauri v1)
let _ = app_handle.emit_all("drives-changed", drives);
// After (Tauri v2)
let _ = app_handle.emit("drives-changed", drives);
```

---

## What's in Beta-5-r22

**No Rust recompile required.** Config-only fix: corrects the Tauri v2 capability file introduced in r21.

### Fix — Invalid capability permission `core:asset-protocol:allow-read` (`src-tauri/capabilities/main.json`)

**Root cause:** `core:asset-protocol:allow-read` does not exist in Tauri v2's permission registry. In Tauri v1 the asset protocol was enabled via `tauri.allowlist.protocol.asset = true`. The r21 migration incorrectly mapped this to a capability permission string, which does not exist — Tauri v2 moved asset protocol configuration to `tauri.conf.json` under `app.security.assetProtocol`.

**Fix — `src-tauri/capabilities/main.json`:** Removed the invalid `core:asset-protocol:allow-read` entry. Also removed the inline scope object form for `fs:allow-write-text-file` (object syntax not supported in this context) and replaced it with the plain string permission.

```diff
-    "core:asset-protocol:allow-read",
-    {
-      "identifier": "fs:allow-write-text-file",
-      "allow": [{ "path": "**" }]
-    },
+    "fs:allow-write-text-file",
```

**Fix — `src-tauri/tauri.conf.json`:** Added `app.security.assetProtocol` block (the correct v2 location for this setting):

```json
"security": {
  "csp": "...",
  "assetProtocol": {
    "enable": true,
    "scope": ["**"]
  }
}
```

---

## What's in Beta-5-r21

**Rust recompile required.** Full stack upgrade: Tauri v1 → v2, WebKit2GTK 4.0 → 4.1.

### Upgrade — Tauri v1 → v2

All dependencies, configuration, and JS/Rust APIs have been updated to Tauri v2.

**`Cargo.toml`**
- `tauri-build` `1.5` → `2`
- `tauri` `1.6` → `2` (features list removed; capabilities file replaces allowlist)
- `raw-window-handle` `0.5` → `0.6`
- `image` `0.24` → `0.25`
- `zip` `0.6` → `2`
- Added: `tauri-plugin-dialog = "2"`, `tauri-plugin-fs = "2"`, `tauri-plugin-shell = "2"`
- `rust-version` bumped `1.70` → `1.77`

**`tauri.conf.json`** — full rewrite to v2 schema
- Schema URL updated to `https://schema.tauri.app/config/2`
- `build.devPath` → `build.devUrl`; `build.distDir` → `build.frontendDist`
- `tauri.windows` → `app.windows`; `tauri.security` → `app.security`
- `tauri.allowlist` block removed entirely
- `bundle.deb` / `bundle.rpm` / `bundle.appimage` moved into `bundle.linux.*`
- WebKit runtime dep updated: `libwebkit2gtk-4.0-37` → `libwebkit2gtk-4.1-0` (deb), `webkit2gtk3` → `webkit2gtk4.1` (rpm)

**`src-tauri/capabilities/main.json`** — new file (replaces v1 allowlist)
- All window, fs, dialog, shell, asset-protocol, and event permissions declared explicitly per the Tauri v2 capabilities system.
- Applies to both `main` and `quicklook` windows.

**`src-tauri/src/main.rs`** — 6 targeted patches, zero behaviour changes

1. `use raw_window_handle::{HasRawWindowHandle, RawWindowHandle}` → `{HasWindowHandle, RawWindowHandle}` (rwh 0.6 API)
2. `get_native_window_handle`: `Window` → `tauri::WebviewWindow`; `raw_window_handle()` → `window_handle()?.as_raw()`; `XcbWindowHandle.window` now `NonZeroU32` so `.get()` added; `WaylandWindowHandle.surface` now `NonNull` so `.as_ptr()` added
3. All five window-control commands (`window_minimize`, `window_maximize`, `window_close`, `window_set_fullscreen`, `window_is_maximized`): `Window` → `tauri::WebviewWindow`
4. `on_window_event` closure: v2 signature is `|window, event|` (separate args) vs v1 `|event|` (event wraps window)
5. `setup` block: `app.get_window("main")` → `app.get_webview_window("main")`; `tauri::Icon::Rgba { ... }` → `tauri::image::Image::new_owned(...)`
6. `tauri::Builder`: `.plugin(tauri_plugin_dialog::init())`, `.plugin(tauri_plugin_fs::init())`, `.plugin(tauri_plugin_shell::init())` registered before `.invoke_handler`

**JS frontend** (`src/main.js`, `src/views.js`, `src/ql-window.js`)
- `from '@tauri-apps/api/tauri'` → `from '@tauri-apps/api/core'`
- `from '@tauri-apps/api/dialog'` → `from '@tauri-apps/plugin-dialog'`
- `from '@tauri-apps/api/fs'` → `from '@tauri-apps/plugin-fs'`
- `import { appWindow } from '@tauri-apps/api/window'` → `import { getCurrentWindow as _getAppWindow } from '@tauri-apps/api/window'; const appWindow = _getAppWindow()`
- All `appWindow.` call-sites are unchanged — the `const appWindow` shim preserves all existing usage without touching any logic

**`package.json`**
- `@tauri-apps/api` `^1.6.0` → `^2.0.0`
- `@tauri-apps/cli` `^1.6.0` → `^2.0.0`
- Added: `@tauri-apps/plugin-dialog`, `@tauri-apps/plugin-fs`, `@tauri-apps/plugin-shell` as runtime dependencies

**`BUILD.md`**
- All `webkit2gtk-4.0` references updated to `webkit2gtk-4.1` (build and runtime)
- `webkit2gtk3-devel` (Fedora) → `webkit2gtk4.1-devel`
- `webkit2gtk` (Arch) → `webkit2gtk-4.1`
- Added Ubuntu 22.04+ minimum requirement note (4.1 not available on 20.04)
- Added Tauri v2 / Rust ≥ 1.77 requirement note

### Distro compatibility after this upgrade

| Distro | Minimum version | Status |
|--------|----------------|--------|
| Ubuntu / Debian | 22.04 Jammy + | ✅ supported |
| Ubuntu 20.04 Focal | — | ❌ dropped (no webkit2gtk-4.1) |
| Fedora | 37+ | ✅ supported |
| Arch / CachyOS | rolling (webkit2gtk-4.1 in extra) | ✅ supported |
| openSUSE Tumbleweed | rolling | ✅ supported |

---

## What's in Beta-5-r20

**Rust recompile required.** Changes in `src-tauri/src/main.rs` and `src/main.js`.

### Fix — Unused import warning: `std::io::Read` in `mobi_to_text` (`src-tauri/src/main.rs`)

`mobi_to_text` imported `std::io::Read` at the top of the function body. The function uses `fs::read()` which returns `Vec<u8>` directly and never calls any `Read` trait methods, so the import was dead code. Removed. Build now produces zero warnings.

---

### Fix — Column trail glitch persists on keyboard Right-arrow navigation (`src/main.js`)

**Root cause:** The r19 fix cleared `sel._paths` before `navigate()` in the *click handler*, but the keyboard ArrowRight handler (`state.viewMode === 'column'`) called `navigateDebounced()` without applying the same fix. Pressing Right to navigate into a folder still caused the selected row to show bright `.sel` during the streaming renders inside `navigateDebounced()` instead of the correct muted `.trail` highlight.

**Fix:** Applied the identical trail fix to the ArrowRight branch: `sel._paths.delete(en.path)` and `state.selIdx = -1` are now set immediately before `await navigateDebounced(...)`. All streaming renders inside the navigation now see `isSel = false → isTrail = true` from the very first frame, regardless of whether navigation was triggered by click or keyboard.

---

### Perf — `DIR_CACHE`: `Mutex` → `RwLock` for concurrent read access (`src-tauri/src/main.rs`)

**Root cause:** `DIR_CACHE` used a `Mutex<Option<DirCache>>`. Every `cache_get()` call — including ones fired concurrently from `list_directory_streamed` and `preload_dir` threads — acquired an exclusive write lock even for a pure read. With many columns open and multiple `preload_dir` threads in flight, these readers serialised each other, adding unnecessary latency to cache hits.

**Fix:** Changed `DIR_CACHE` to `RwLock<Option<DirCache>>`. `cache_get()` now takes a shared read lock (multiple callers hold it simultaneously with zero contention). `cache_insert()` and `cache_evict()` take the exclusive write lock, which is correct and rare. Read-path latency for cache hits is now fully parallel.

---

### Perf — `preload_dir`: raw OS thread → Tokio `spawn_blocking` (`src-tauri/src/main.rs`)

**Root cause:** `preload_dir` called `std::thread::spawn` per hover event. Hovering quickly over many directory rows (a natural motion when scanning column view) spawned N independent OS threads in rapid succession. OS thread creation costs ~100µs each and the thread pool is unbounded, so aggressive hovering could create dozens of threads simultaneously.

**Fix:** Switched to `tauri::async_runtime::spawn_blocking`. Tokio's blocking thread pool is bounded and reuses threads, so repeated hovers over many directories draw from an existing pool rather than paying OS thread creation cost each time. The work inside is identical; only the scheduling mechanism changes.

---

### Fix — App icon missing on native Wayland compositors (`src-tauri/src/main.rs`)

**Root cause:** The existing `win.set_icon(tauri::Icon::Rgba{...})` call sets the `_NET_WM_ICON` X11 window property. On **native Wayland** (Hyprland, Sway, GNOME, KDE Plasma under Wayland), most compositors do not read `_NET_WM_ICON` at all. Instead they resolve the taskbar/dock icon by matching the `xdg_toplevel` `app_id` (`"frostfinder"`) against installed `.desktop` files, then looking up `Icon=frostfinder` in the XDG hicolor icon theme at `~/.local/share/icons/hicolor/`. Without that icon installed, the compositor shows a generic placeholder.

**Fix:** Added a background thread in `setup()` (Linux only) that on first launch writes all bundled PNG sizes (16×16 through 512×512) to `~/.local/share/icons/hicolor/<size>/apps/frostfinder.png` and runs `gtk-update-icon-cache -f -t` on the hicolor tree. The thread is fire-and-forget and only writes files that don't already exist — subsequent launches are a no-op. The `set_icon()` call is retained for XWayland and X11 compatibility.

```
Icons installed on first launch:
  ~/.local/share/icons/hicolor/16x16/apps/frostfinder.png
  ~/.local/share/icons/hicolor/32x32/apps/frostfinder.png
  ~/.local/share/icons/hicolor/48x48/apps/frostfinder.png
  ~/.local/share/icons/hicolor/64x64/apps/frostfinder.png
  ~/.local/share/icons/hicolor/128x128/apps/frostfinder.png
  ~/.local/share/icons/hicolor/256x256/apps/frostfinder.png
  ~/.local/share/icons/hicolor/512x512/apps/frostfinder.png
```

After the first launch the icon appears in all Wayland-native taskbars, docks, app switchers, and application launchers without any manual installation step.

---

## What's in Beta-5-r19

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src/utils.js`, `src/views.js`, `src/ql-window.js`, `src/main.js`.

### Fix — Column trail glitch: clicking a folder still shows `.sel` during navigation (`src/views.js`)

**Root cause identified and definitively fixed.** The r10 fix placed `sel._paths.delete(entry.path)` *after* `await navigate()` resolved. This fixed the visual state *at the end* of navigation but not *during* it.

`navigate()` is async and emits streaming renders as it receives chunks from Rust (`list_directory_full_streamed`). Each streaming `render()` call goes through `renderColumnView` → `_patchEntries` for every existing column. At that point `sel._paths` still contained the clicked folder's path, so `isSel = sel.hasp(path) = true` → `isTrail = !isSel && ... = false`. Every streaming frame showed the clicked folder as bright `.sel` (selected) instead of muted `.trail` (navigated-through). The deletion at the end only fixed the *final* frame.

**Fix:** Move `sel._paths.delete(entry.path)` and `state.selIdx = -1` to *before* `await navigate(...)`. This means every render inside `navigate()` — including first-chunk and done-chunk streaming frames — already sees `isSel = false`, so `isTrail = true` fires immediately and the trail highlight is correct from the very first frame of navigation. The `col.selIdx` (set to `ei` before the navigate call) still correctly identifies which row index gets the `.trail` class.

```js
// Before (r10): delete AFTER navigate — streaming renders during nav still showed .sel
await navigate(entry.path, liveCI + 1, false);
if (state.columns.length > liveCI + 1) {
  sel._paths.delete(entry.path);
  state.selIdx = -1;
  render();
}

// After (r19): delete BEFORE navigate — all renders inside nav see correct trail
sel._paths.delete(entry.path);
state.selIdx = -1;
await navigate(entry.path, liveCI + 1, false);
```

---

### Feature — epub / mobi / azw / azw3 preview in panel, gallery, and Quick Look

#### Rust: text extraction (`src-tauri/src/main.rs`)

**`epub_to_text(path)`** — ePub 2/3 (ZIP + XHTML). Reads `META-INF/container.xml` to locate the OPF manifest, parses the spine order from `<itemref>` elements, builds an `id→href` map from `<item>` entries, then reads each XHTML content document in spine order. Strips HTML tags, maps block elements (`<p>`, `<div>`, `<h1>`–`<h6>`, `<li>`, `<br>`) to newlines, decodes XML/HTML entities, collapses blank lines. Falls back to finding all `.xhtml`/`.html` files in the ZIP if OPF parsing fails. Capped at 256 KB.

**`mobi_to_text(path)`** — Mobipocket / AZW / AZW3 (proprietary binary). Scans the raw binary for the HTML payload (looks for `<html`, `<body`, `<p` markers after the PalmDOC record header), extracts and lossily UTF-8-decodes up to 512 KB of content, strips HTML tags with block-element newline conversion, filters garbage bytes. Returns `None` if extracted text is fewer than 50 characters (indicating the file is not parseable by this method — e.g. DRM-encrypted AZW3). No external crates added.

Both wired into `get_file_preview` returning `is_text: true` with the extracted content. The existing `<pre class="preview-code">` render path handles display automatically.

New MIME types: `application/epub+zip` for epub, `application/x-mobipocket-ebook` for mobi/azw/azw3.

#### JS: new `BOOK_EXTS` constant and wiring

**`src/utils.js`**
- `BOOK_EXTS = ['epub','mobi','azw','azw3']` — new export
- `fileColor`: ebooks → `#fb923c` (orange, distinct from docs)
- `fileIcon`: ebooks → `getIcon('doc')`
- `mimeLabel`: `'application/epub+zip': 'ePub Book'`, `'application/x-mobipocket-ebook': 'Mobipocket Book'`

**`src/views.js`** — `BOOK_EXTS` added to import; gallery `_buildMainHtml` and `_loadContent` doc-slot guards; `_qlBody` `isDoc` check.

**`src/ql-window.js`** — `BOOK_EXTS` added to import and `isDoc` check in `renderEntry`.

**`src/main.js`** — `BOOK_EXTS` added to import.

---

## What's in Beta-5-r18

**Rust recompile required** (warning fixes). JS changes in `src/ql-window.js` and `src/views.js`.

### Fix — doc/docx/xls/xlsx not showing in preview panel or Quick Look (`src/ql-window.js`, `src/views.js`)

**Root cause:** Two `isDoc` checks that route files to the text-preview slot only checked `DOC_EXTS` (plain text formats: md, txt, rs, py, etc.) but not `OFFICE_EXTS` (doc, docx, xls, xlsx). Office files therefore fell through to the `renderUnknown` branch, showing only the file icon and size instead of extracted text.

**Fix 1 — `src/ql-window.js` `renderEntry()`:**
```js
// Before:
const isDoc = DOC_EXTS.includes(ext);
// After:
const isDoc = DOC_EXTS.includes(ext) || OFFICE_EXTS.includes(ext);
```
Also added `OFFICE_EXTS` to the import from `utils.js`. Office files now route to the `isDoc` branch which calls `get_file_preview` and renders the extracted text in a `<pre>` element — identical to how plain text docs are shown in Quick Look.

**Fix 2 — `src/views.js` `_qlBody()`** (the inline Quick Look overlay used in list/column view):
```js
// Before:
const isDoc = DOC_EXTS.includes(ext);
// After:
const isDoc = DOC_EXTS.includes(ext) || OFFICE_EXTS.includes(ext);
```

The gallery view (`_buildMainHtml`, `_loadContent`) and main preview panel (`renderPreview` via `is_text` response) were already correct from r17 — only these two QL code paths were missed.

---

### Fix — Rust compiler warnings in `xlsx_to_text` (`src-tauri/src/main.rs`)

Two warnings emitted during build:
- `variable does not need to be mutable: mut in_si`
- `unused variable: in_si`

**Root cause:** The shared strings parser in `xlsx_to_text` had two approaches written simultaneously: a character-by-character loop (incomplete, never produced any output — `in_t` was declared but never set to `true`) and a `split("<si>")` boundary parser below it that did the actual work correctly. The char loop was dead code with two unused variables (`in_t` set but never read for actual accumulation, `in_si` declared but never used at all).

**Fix:** Removed the dead char loop entirely. The `split("<si>")` parser is the sole shared-strings implementation and works correctly. No functional change — the actual xlsx text extraction output is identical.

---

## What's in Beta-5-r17

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src-tauri/tauri.conf.json`, `src/utils.js`, `src/views.js`, and `src/main.js`.

### Fix — PDF preview blank in production builds (`src-tauri/tauri.conf.json`)

**Root cause:** The CSP (Content Security Policy) lacked a `frame-src` directive. In dev mode (`npm run tauri dev`), the app is served by the Vite HTTP dev server and the browser barely enforces the CSP. In production builds (`npm run tauri build`), Tauri serves the app from the custom `tauri://localhost` protocol and enforces the full CSP — any `<iframe>` attempting to load content from `http://127.0.0.1:PORT/...` was silently blocked, rendering a blank white or grey rectangle where the PDF should appear. The media server was running and reachable; only the iframe embed was blocked.

**Fix:** Added `frame-src http://127.0.0.1:*;` to the CSP string:

```
"csp": "... frame-src http://127.0.0.1:*; ..."
```

This unblocks all iframes loading from the local media server — PDFs in the preview panel, gallery PDF slot, Quick Look PDF slot, and HTML file previews (`<iframe sandbox>`) are all now permitted in production builds.

---

### Feature — doc / docx / xls / xlsx preview (`src-tauri/src/main.rs`, `src/utils.js`, `src/views.js`, `src/main.js`)

#### Rust: text extraction (`src-tauri/src/main.rs`)

**`docx_to_text(path: &Path) -> Option<String>`** — Extracts readable text from `.docx` (and `.doc` saved in OOXML format). Opens the file as a ZIP archive, reads `word/document.xml`, strips all XML tags, converts `<w:p>` paragraph boundaries to newlines, decodes `&amp;`, `&lt;`, `&gt;`, `&quot;`, `&apos;` entities, and collapses excess blank lines. Uses the `zip` crate already present in `Cargo.toml`.

**`xlsx_to_text(path: &Path) -> Option<String>`** — Extracts cell content from `.xlsx` (and `.xls` saved in OOXML format). Opens the file as a ZIP archive, reads the shared string table from `xl/sharedStrings.xml` (where most text content lives), then reads `xl/worksheets/sheet1.xml` to walk rows and cells. Handles shared-string references (`t="s"`), inline strings (`t="inlineStr"`), and numeric/formula values. Outputs tab-separated values with one row per line. Capped at 200 rows to keep preview fast for large spreadsheets.

Both functions are wired into `get_file_preview()` before the existing `is_image` and `is_text` paths. When extraction succeeds, Rust returns `is_text: true` with the extracted content — the existing `<pre class="preview-code">` render path in the JS preview panel handles it automatically. When extraction fails (e.g. a legacy binary `.doc`/`.xls` that is not OOXML), Rust returns `is_text: false` and the preview panel shows the standard binary fallback with icon and mime label.

Also added MIME types for both formats to `get_file_preview`: `application/msword` for doc/docx, `application/vnd.ms-excel` for xls/xlsx.

#### JS: file type wiring (`src/utils.js`, `src/views.js`, `src/main.js`)

**`src/utils.js`**
- New `OFFICE_EXTS = ['doc','docx','xls','xlsx']` export — used across views to route office files to the text-preview slot
- `fileColor`: `doc`/`docx` → `#5b8dd9` (Word blue); `xls`/`xlsx` → `#34d399` (Excel green, consistent with CSV)
- `mimeLabel`: added `'application/msword': 'Word Document'` and `'application/vnd.ms-excel': 'Excel Spreadsheet'`
- `fileIcon`: `doc`/`docx`/`xls`/`xlsx` → `getIcon('doc')` — document icon with correct color from above

**`src/views.js`**
- `OFFICE_EXTS` imported from `utils.js`
- Gallery `_buildMainHtml`: `DOC_EXTS.includes(ext) || OFFICE_EXTS.includes(ext)` — both show the `#gallery-doc-slot` which loads via `get_file_preview` and renders the extracted text
- Gallery `_loadContent`: same guard ensures the doc slot fires for office files

**`src/main.js`**
- `OFFICE_EXTS` added to the import from `utils.js`
- `loadPreview` already calls `get_file_preview` for all non-image/non-media files — office files automatically go through the Rust extraction path with no extra routing needed

---

## What's in Beta-5-r16

**No Rust recompile required.** Changes in `src-tauri/tauri.conf.json` and `BUILD.md` only.

### Fix — Fedora `.rpm` install fails: wrong package names in `rpm.depends` (`src-tauri/tauri.conf.json`)

Two wrong package names in the RPM `depends` block caused `dnf install` to abort with depsolve errors.

**`webkit2gtk4.0` → `webkit2gtk3`**

`webkit2gtk4.0` does not exist universally across Fedora releases. The package that provides `libwebkit2gtk-4.0.so.37()(64bit)` — the exact shared library Tauri v1 links against — on every supported Fedora version is `webkit2gtk3`. This resolves the install on all Fedora releases (36 through 40+).

**`libayatana-appindicator` → removed**

This package does not exist in Fedora's repos at all — it is Ubuntu/Debian-specific. It is also not needed: `Cargo.toml` has `features = ["shell-open"]` with no `system-tray` or `ayatana-tray` feature, so appindicator is never linked. Also removed the Ubuntu equivalent `libayatana-appindicator3-1` from `deb.depends` for the same reason.

`BUILD.md` — Fedora build dep corrected to `webkit2gtk3-devel`, `libayatana-appindicator-devel` removed.

---

## What's in Beta-5-r15

**Rust recompile required.** Fix in `src-tauri/src/main.rs` only.

### Fix — `Icon::Raw` compile error → correct `Icon::Rgba` variant (`src-tauri/src/main.rs`)

r14 used `tauri::Icon::Raw(Vec<u8>)` which does not exist in Tauri v1. The correct variant is `tauri::Icon::Rgba { rgba: Vec<u8>, width: u32, height: u32 }` which requires the raw RGBA pixel bytes and explicit image dimensions.

**Fix:** Decode the embedded PNG with the `image` crate (already a dependency, PNG feature already enabled) to get the pixel data and dimensions:

```rust
const ICON_PNG: &[u8] = include_bytes!("../icons/128x128.png");
if let Ok(img) = image::load_from_memory(ICON_PNG) {
    let rgba = img.into_rgba8();
    let (width, height) = rgba.dimensions();
    let _ = win.set_icon(tauri::Icon::Rgba {
        rgba: rgba.into_raw(),
        width,
        height,
    });
}
```

`image::load_from_memory` is already called elsewhere in `main.rs` (thumbnail generation) so no new imports are needed. `img.into_rgba8()` converts any pixel format (including indexed or grayscale PNGs) to the packed `u8` RGBA layout that `tauri::Icon::Rgba` requires. `rgba.dimensions()` returns `(width, height)` as `u32` matching the struct fields exactly.

---

## What's in Beta-5-r14

**Rust recompile required.** Change in `src-tauri/src/main.rs` only.

### Fix — Taskbar / dock shows generic "F" letter instead of app icon (`src-tauri/src/main.rs`)

**Root cause:** Tauri v1 does **not** automatically set `_NET_WM_ICON` on the live window. `_NET_WM_ICON` is the X11/Wayland window property that taskbars, alt-tab switchers, and docks read to display the app icon. Without it, every window manager falls back to a text placeholder derived from the window title — hence the "F" initial shown in the taskbar. This is a known Tauri v1 limitation; the bundle icons in `tauri.conf.json` are only used when generating `.desktop` files and package metadata, not for the running window itself.

**Fix:** Added a `win.set_icon()` call at the top of the `.setup()` closure:

```rust
if let Some(win) = app.get_window("main") {
    let _ = win.set_icon(tauri::Icon::Raw(
        include_bytes!("../icons/128x128.png").to_vec()
    ));
}
```

`include_bytes!("../icons/128x128.png")` embeds the PNG directly into the compiled binary at build time — zero runtime filesystem reads, works identically whether the app is run as a raw binary, from a `.deb`/`.rpm`/`.AppImage` install, or via `npm run tauri dev`. `tauri::Icon::Raw` decodes the PNG and passes the pixel data to the underlying GTK/Wayland window, which sets `_NET_WM_ICON`. All taskbars, docks, and window switchers that read this property will now show the FrostFinder icon immediately on launch.

The 128×128 size is used as the source; the window manager rescales to whatever size it needs for the dock or taskbar slot.

---

## What's in Beta-5-r13

**No Rust recompile required.** Changes in `src-tauri/tauri.conf.json`, `src-tauri/icons/` (new sizes), `packaging/frostfinder.desktop` (new), `PKGBUILD` (new), `BUILD.md` (new). Also adds `packaging/` and new icon size PNGs to the zip.

### Feature — Full Linux packaging: Ubuntu `.deb`, Fedora `.rpm`, portable `.AppImage`, AUR `PKGBUILD`

Running `npm run tauri build` now produces all three Linux bundle formats in one pass. A `PKGBUILD` for AUR is included. Icons are properly sized and installed across the hicolor theme tree.

---

**`src-tauri/tauri.conf.json` — Build targets and metadata**

`targets` changed from `["deb", "rpm", "nsis", "msi", "dmg"]` to `["deb", "rpm", "appimage"]`. Windows (NSIS/MSI) and macOS (DMG) removed from the default target list — the Linux-only targets now build without errors on a Linux host. Run `npm run tauri build -- --bundles deb` to build a single format if needed.

Added package metadata used by all three formats:
- `shortDescription` / `longDescription` — shown in package managers
- `category` — `"Utility"` maps to the XDG `Utility;FileManager;` categories
- `copyright` — embedded in `.deb` control and `.rpm` spec

`.deb` now lists `udisks2` as a dependency (required for ISO/DMG/USB one-click mount). `.rpm` lists the correct Fedora package names (`webkit2gtk4.0` not `libwebkit2gtk-4.0-37`).

`appimage.bundleMediaFramework` is `false` — the AppImage must not bundle WebKit2GTK or GStreamer; it depends on the system stack for VA-API hardware decode and correct media handling. The env vars `APPIMAGE_EXTRACT_AND_RUN=1` and `NO_STRIP=1` in `.cargo/config.toml` handle Arch/CachyOS AppImage toolchain quirks automatically.

---

**`src-tauri/icons/` — Complete hicolor size set**

Added `16x16.png`, `48x48.png`, `64x64.png`, `256x256.png`, `512x512.png` — all generated from the existing `128x128@2x.png` (256px source) using LANCZOS resampling. All standard XDG hicolor sizes are now present so desktop environments display the correct icon at any size without upscaling artefacts. The `icon` array in `tauri.conf.json` lists all sizes so Tauri embeds them in every bundle format.

---

**`packaging/frostfinder.desktop` — Linux desktop entry (new)**

Standard XDG `.desktop` file for launcher/taskbar/application-menu integration. Includes `Categories=Utility;FileManager;`, `MimeType=inode/directory;` (registers as a default file manager candidate), `StartupWMClass=frostfinder` (taskbar grouping), and `Keywords` for desktop search.

Used by:
- The `PKGBUILD` (`makepkg`) installs it to `/usr/share/applications/`
- Packagers can also install it manually: `install -Dm644 packaging/frostfinder.desktop /usr/share/applications/frostfinder.desktop`

---

**`PKGBUILD` — AUR packaging (new)**

Full `makepkg`-compatible PKGBUILD. Declares correct `depends`/`makedepends`/`optdepends`, runs `npm install` + `npm run tauri build` in the `build()` step, and installs binary + all icon sizes + `.desktop` file in `package()`. Includes a commented local-development variant for building directly from the project directory without a real source tarball.

Usage:
```bash
# Requires base-devel, rust, nodejs, npm, and the webkit2gtk/gtk3 build deps
makepkg -si
```

---

**`BUILD.md` — Full build instructions (new)**

Step-by-step build guide for Ubuntu/Debian, Fedora/RHEL, and Arch/CachyOS. Covers system build dependencies, per-format build commands (`--bundles deb`, `--bundles rpm`, `--bundles appimage`), install commands, AppImage FUSE notes, optional runtime tools (ffmpeg, mpv, udisks2, libheif), and manual icon installation for packagers who don't use the PKGBUILD.

---

## What's in Beta-5-r12

**No Rust recompile required.** Full line-by-line code audit. One bug fixed in `src/views.js`.

### Audit — Full codebase review

Every line of `src/views.js` (3249 lines), `src/main.js` (2552 lines), `src/ql-window.js` (630 lines), `src/utils.js`, `src/style.css`, `src-tauri/src/main.rs` (3659 lines), and all config files was reviewed.

**All 79 Tauri commands confirmed registered** in `invoke_handler` with none missing or unregistered. All previously fixed mechanisms verified intact: r7 live-DOM `_patchEntries` trail fix, r10 post-navigate `sel._paths.delete` trail fix, r5 multi-path `watch_dir`, r6 `delete_items_stream`, `empty_trash_stream`, `_sbProgress`, `_toolbarFp`, `_jsCacheEvict`/`_jsCacheSet`, `_watcherRefreshPending`. No stale Tauri API calls to removed commands (`delete_file`, `burn_iso`, `list_optical_drives`). Dead-code functions (`is_xcf_ext`, `is_html_ext`, `is_dmg_ext`) confirmed absent from `main.rs`.

---

### Fix — List view scroll position reset to top on every click and right-click (`src/views.js`)

**Root cause:** After `handleEntryClick(entry, i, ev)` is called from the list view click handler, it calls `render()`, which calls `renderListView(host)`, which executes `host.innerHTML = '...'` — rebuilding the entire list view DOM from scratch. This detaches the old `#lv-wrap` element. Both `requestAnimationFrame` callbacks still referenced the captured-at-build-time `lvWrap` variable, which now pointed to the detached element. Setting `scrollTop` on a detached element is a browser no-op (silently ignored). The same issue existed in the `contextmenu` handler's RAF. Result: every click or right-click in list view reset the scroll position to the top of the list.

**Why this wasn't previously reported:** The bug exists on every list view click, but it's most noticeable when selecting items in the middle of a long directory. For short directories or when clicking near the top, the position jump is imperceptible. It was consistent and silent.

**Fix:** Both RAFs now use `host.querySelector('#lv-wrap')` to find the newly-created `#lv-wrap` element produced by the rebuild, rather than the stale captured reference:

```js
// Before — targets detached element, silently no-ops:
requestAnimationFrame(() => { if (lvWrap) lvWrap.scrollTop = sv; });

// After — queries the live #lv-wrap in the rebuilt DOM:
requestAnimationFrame(() => { const lw = host.querySelector('#lv-wrap'); if (lw) lw.scrollTop = sv; });
```

`host` (`#view-host`) is the stable container element that `renderListView` receives as a parameter and writes into — it is never replaced, only its `innerHTML` is. It is therefore always a valid, connected DOM element to query from. Applied to both the `click` handler and the `contextmenu` handler RAFs.

---

## What's in Beta-5-r11

**No Rust recompile required.** Changes in `src/style.css` only.

### Feature — Full modern UI overhaul: unified radius scale, glass popups, layered shadows (`src/style.css`)

Complete visual redesign of the entire app. Every surface, popup, dialog, and interactive element has been updated to a coherent modern dark design language.

---

**Radius scale** — CSS variables `--r-xs` through `--r-xl` now drive all border-radius values consistently instead of scattered ad-hoc pixel values:

| Variable | Value | Used for |
|---|---|---|
| `--r-xs` | 4px | Tiny elements: badges, dots, close buttons |
| `--r-sm` | 8px | Buttons, rows, small interactive items |
| `--r-md` | 12px | Inputs, cards, image thumbnails |
| `--r-lg` | 16px | Dropdowns, context menus, sort popup |
| `--r-xl` | 20px | Full modals: permission dialog, Open With |

**Shadow scale** — `--shadow-sm` / `--shadow-md` / `--shadow-lg` / `--shadow-xl` provide layered depth. All floating elements (context menus, dropdowns, dialogs) now use the appropriate tier with inset highlight line for depth.

---

**Main window** — Added `border-radius:12px` and `border:1px solid rgba(255,255,255,.1)` to `.window`. Since `transparent:true` is already set in `tauri.conf.json`, this gives the app window itself rounded corners against the desktop wallpaper — the same effect as macOS apps and modern Linux tools.

**All glass popups** — Context menu, sort popup, new-file dropdown, permission dialog, Open With dialog all now use `backdrop-filter:blur(24-32px)` with semi-transparent backgrounds (`rgba(36,36,40,.92-.97)`). They float visually above the rest of the UI with clear depth separation.

**Context menu** — `border-radius:16px`, glass background, `--shadow-xl`. Row hover radius `10px`.

**Sort popup** — `border-radius:16px`, glass background, `--shadow-lg`.

**New-file dropdown** — `border-radius:16px`, glass background, deeper shadow.

**Permission dialog** — `border-radius:20px`, glass background, `--shadow-xl`. Buttons now `border-radius:10px`. Cancel button has explicit `background:rgba(255,255,255,.05)` so it reads as a distinct control.

**Open With dialog** — `border-radius:20px`, glass background, `--shadow-xl`. Search input `border-radius:10px` with focus ring. App rows `border-radius:10px`.

**Toast notifications** — `border-radius:12px`, `backdrop-filter:blur(12px)`, tinted border matching toast color. Elevated shadow for clear floating feel.

**Lightbox close button** — Added `backdrop-filter:blur(8px)` so it reads clearly over any image.

**Breadcrumb input** — `border-radius:12px` with focus glow ring `box-shadow:0 0 0 3px rgba(91,141,217,.15)`.

**Search input** — `border-radius:10px` with matching focus ring.

**View switcher** — `border-radius:10px` container with `border:1px solid rgba(255,255,255,.06)`.

**Tags** — All tag pills are now fully rounded (`border-radius:20px`) — pill shape throughout preview panel, context menu, and row badges.

**Gallery thumbnails (`.gthumb`)** — `border-radius:10px`, inner image top radius `6px 6px 0 0` matches.

**Icon items (`.icon-item`)** — `border-radius:10px`, `ico-big border-radius:12px`.

**ISO/DMG action buttons** — `border-radius:10px` for a more modern card-button look.

**Font install button** — `border-radius:10px`.

**Font specimen card** — `border-radius:10px` with matching border.

---

## What's in Beta-5-r10

**No Rust recompile required.** Changes in `src/views.js` only.

### Fix — Column 5+ folder clicks glitch: trail shows `.sel` instead of `.trail` after click (`src/views.js`)

Two compounding bugs caused mouse clicks in any parent column to display the wrong highlight state on the clicked folder, while arrow-key navigation showed the correct `.trail` highlight. Confirmed by debug log `frostfinder-debug-1773576167449.log` showing repeated ci=4 and ci=5 clicks with correct navigation but wrong visual state.

---

**Bug 1 — `_makeColRow` used build-time `ci` for `isTrail` (same category as r7 fix)**

`_makeColRow` is called from `_paintColList` every time new rows enter the virtual-scroll viewport (scrolling, resize, or full rebuild). The `isTrail` check was:

```js
const isTrail = !isSel && (ci < state.columns.length - 1) && col.selIdx === ei;
```

`ci` is captured at column build time. `_paintColList` runs independently from `render()` — scroll events and `ResizeObserver` callbacks fire asynchronously. Between the time a column is built and the time `_paintColList` runs, `state.columns.length` may have changed (due to navigations and watcher events). Using the build-time `ci` against the live `state.columns.length` gives the wrong `isParent` result.

**Fix:** Compute the live column index from the DOM position at the time `_makeColRow` runs — exactly the same strategy used by `_patchEntries` (r7 fix) and the click handler (r7 fix):

```js
const _rowLiveCI = colEl.parentElement
  ? Array.from(colEl.parentElement.children).indexOf(colEl)
  : ci; // fallback only if somehow detached
const isTrail = !isSel && (_rowLiveCI !== -1) && (_rowLiveCI < state.columns.length - 1) && col.selIdx === ei;
```

---

**Bug 2 — After clicking a directory to navigate into it, `sel._paths` still contains that folder's path**

This is the primary cause of the "click glitch vs arrow keys work fine" asymmetry.

**Root cause:** The click handler calls `sel.set(ei)` which adds the clicked folder to `sel._paths`. Navigate then opens the child column. In every render inside `navigate()` (streaming renders), `isSel = sel.hasp(entry.path) = true` for the clicked folder. `isTrail = !isSel && ... = false`. The folder shows `.sel` (bright blue) instead of `.trail` (muted blue).

**Why arrow keys work:** Arrow-key navigation moves selection *inside the child column* — `sel.set(child_idx)` replaces `sel._paths` with a child column item. Now `sel.hasp(parent_folder_path) = false` → `isTrail = true` → `.trail` shown correctly.

**Fix:** After `navigate()` resolves and the child column is confirmed open, remove the navigated folder's path from `sel._paths`. `col.selIdx` (set during the click) still tracks which row gets the trail.

```js
await navigate(entry.path, liveCI + 1, false);
if (state.columns.length > liveCI + 1) {
  sel._paths.delete(entry.path);
  state.selIdx = -1;
  render();
}
```

The guard `state.columns.length > liveCI + 1` ensures we only do this when the child column actually opened (i.e., navigate didn't fail silently). The `sel._paths.delete` is surgical — it removes only the navigated folder, leaving any multi-selection context in other columns intact.

---

## What's in Beta-5-r9

**No Rust recompile required.** Changes in `src/views.js`, `src/style.css`.

### Feature — Column view navigation trail (`src/views.js`, `src/style.css`)

When navigating into subdirectories in column view, each parent column now shows a persistent highlight on the folder that leads to the next column — matching macOS Finder's column trail behaviour.

**Before:** Parent columns showed no visual indicator of the navigation path. Once you clicked a file in a deep column, all parent-column highlights vanished. Finding your position required scanning every column individually.

**After:** Every folder in the active navigation path is highlighted with a muted blue `.frow.trail` background. The selected item in the rightmost column retains the full bright `.frow.sel` blue so the endpoint stays visually dominant. The complete path from the leftmost column to the current selection is visible at a glance.

**Root cause of why this was silently broken before:** `_makeColRow` used `sel.hasp(e.path) || col.selIdx === ei` for `isSel`, which marked trail folders correctly on first column build — but columns are almost always *patched* rather than rebuilt via `_patchEntries`. Both `_patchEntries` fast-paths only checked `sel.hasp(e.path)` and never `col.selIdx`, so trail folders lost their highlight silently on every watcher event, render cycle, or navigation after the initial build.

**Implementation details:**

**`src/views.js` — `_makeColRow`:** `isSel` now uses only `sel.hasp(e.path)` (correct — multi-select aware). New `isTrail = !isSel && ci < state.columns.length - 1 && col.selIdx === ei` drives the `.trail` class. Tag tint background is suppressed when a row is trail-highlighted so the two visuals don't compete.

**`src/views.js` — `_patchEntries` pre-sort fast-path:** Now toggles `.trail` on any row where `+row.dataset.idx === newSelIdx` and the column is not the last one (`!isLast`). Trail highlight survives watcher-triggered refreshes and sort changes without a full column rebuild.

**`src/views.js` — `_patchEntries` post-sort fast-path:** Same fix applied identically.

**Full-rebuild path:** `_patchEntries` evicts and repaints via `_paintColList` → `_makeColRow`, which already carries the `isTrail` logic — no extra work needed here.

**`src/style.css` — `.frow.trail`:** Background `rgba(59,95,160,0.38)` — the `--bg-selected` blue at ~38% opacity, clearly in the same blue family as `.frow.sel` but noticeably dimmer so the active selection dominates. `.frow.trail .fname` uses `#c0d4f5` (pale blue-white) and `.frow.trail .fchev` uses `rgba(91,141,217,.7)` so the disclosure chevron reads as "this column continues". A hover state brightens the trail row slightly without reaching full selection intensity.

---

## What's in Beta-5-r8

**No Rust recompile required.** Changes in `PACK.sh`, `src-tauri/tauri.conf.json`, `src-tauri/Cargo.toml`, `package.json`.

### Fix — Version strings stale in `tauri.conf.json`, `Cargo.toml`, and `package.json`

All three files were stuck at their Beta-5-r1 value (`5.0.1`) while the project had advanced to r7. `package.json` was still at the original `0.1.0`. The compiled binary, `.deb`/`.rpm` package metadata, and npm tooling all reported incorrect version numbers.

**Fix:** Updated all three files to `5.0.8` (semver encoding: `{version}.0.{revision}`).

### Fix — `PACK.sh` never synced versions on repack

`PACK.sh` correctly updated `RELEASE.md` and the `VERSION` file on every run, but left `tauri.conf.json`, `Cargo.toml`, and `package.json` untouched. Versions would fall further out of sync with each subsequent revision.

**Fix:** Added `_sedi` calls in `PACK.sh` after the `RELEASE.md` update block to rewrite the `"version"` field in all three files on every pack run. Semver is derived as `${VERSION}.0.${REVISION}` so it tracks the build scheme automatically. `Cargo.toml` uses a `0,/pattern/s//…/` range address (GNU sed) or a `perl -i` fallback (BSD/macOS) to update only the package-level version line, leaving all dependency version strings untouched.

---

## What's in Beta-5-r7

**Rust recompile NOT required.** Changes in `src/views.js`, `src/ql-window.js`, `ql.html`, `src-tauri/src/main.rs` (dead code only).

### Fix — Column 5+ folder clicks glitch / wrong selection target (`src/views.js`)

`_patchEntries` is the incremental update callback stored on each column DOM element. It was closing over `ci` (the column index at build time) and using it in four places to check `ci === state.columns.length - 1` — the "is this the rightmost column?" test that controls:
- Which column's `sel._e` (the entries array driving selection/keyboard nav) gets updated
- Whether the in-column search filter is applied

`ci` is correct at build time but goes stale as soon as columns are added or removed. On the 5th column (ci=4): navigating forward adds column 5 (length=6), then clicking a folder in column 5 splices to length=5 and pushes the new path. The next watcher-triggered `_patchEntries` call fires with `ci=4`, `state.columns.length=5` — `4 === 4` is `true` and `sel._e` is wrongly assigned to column 5's entries instead of the actual rightmost column. Result: arrow keys, rubber-band drag, and context menus all operated on the wrong column's file list, producing phantom selections and navigate-to-wrong-path bugs.

**Fix:** Compute the live column index from DOM position inside `_patchEntries` using `Array.from(colEl.parentElement.children).indexOf(colEl)` — identical to the strategy already used in the click handler since r49. Replaced all four `ci === state.columns.length - 1` guards with `isLast` derived from the live DOM index.

---

### Feature — Quick Look font preview with Install button (`src/ql-window.js`, `ql.html`)

OTF/TTF/WOFF/WOFF2 files now show the same live font specimen in Quick Look as in the preview panel.

A `@font-face` rule is injected into the QL window's `<head>`, using the font file served via the media port. The specimen shows a 52px display sample, the full A–Z alphabet, digit/symbol row, and two pangrams. An Install button below the specimen calls `install_font` with an animated progress bar, turning green and locking on success.

`FONT_EXTS` added to `ql-window.js` imports. `isFont` detection added alongside `isHtml`/`isXcf`/`isDmg`. `isFont` included in the media port pre-fetch guard. Font CSS added to `ql.html`.

---

### Fix — Dead code warnings (`src-tauri/src/main.rs`)

Removed three unused helper functions that produced `#[warn(dead_code)]` warnings on compile:
- `fn is_xcf_ext` — ext comparison inlined at usage site
- `fn is_html_ext` — ext comparison inlined at usage site
- `fn is_dmg_ext` — ext comparison inlined at usage site

---


## What's in Beta-5-r6

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src/utils.js`, `src/views.js`, `src/main.js`, `src/style.css`.

### Fix — App freezes when deleting/trashing large files (`src-tauri/src/main.rs`, `src/main.js`)

`delete_file` was a synchronous `fn` that ran on the Tauri async runtime thread. A cross-device trash of a 5 GB file performed a blocking `fs::copy` loop on that thread, stalling all IPC and freezing the UI until the copy finished.

**Fix:** `delete_file` is now `async fn` with all I/O dispatched via `tauri::async_runtime::spawn_blocking`. The fast path (same-filesystem `fs::rename`) is still instant. The slow cross-device path emits `delete-progress` events `{name, done, total, finished}` per file so the sidebar progress bar shows live feedback.

New `delete_items_stream` command replaces the sequential `delete_file` loop in `deleteEntries` — one IPC round-trip for the whole batch instead of N serial awaits. JS `deleteEntries` (`src/main.js`) now wires a `delete-progress` listener to `_sbProgress` before firing the command and tears it down on completion.

A global `delete-progress` listener in the init boot section covers single-file deletes triggered via context menu or keyboard.

---

### Fix — RTF shows raw markup instead of document text (`src-tauri/src/main.rs`)

RTF files use an escape-heavy control-word syntax. Passing raw bytes to the preview panel produced unreadable markup.

**Fix:** `rtf_to_text()` Rust function strips control words (`\keyword`), hex escapes (`\'xx`), Unicode `\uN`, ignorable `\*` destinations, and brace groups. Paragraph marks (`\par`, `\line`) become newlines. Runs of 3+ blank lines collapse to 2. Applied in `get_file_preview` before returning `content` for `.rtf` files.

---

### Fix — HTML preview serves as download instead of rendering (`src-tauri/src/main.rs`)

`mime_for_path` in the local HTTP media server returned `application/octet-stream` for `.html`/`.htm` files. WebKit treated the response as a file download.

**Fix:** Added `"html"|"htm" => "text/html"` to `mime_for_path`. The sandboxed iframe now receives the correct MIME type and renders the page.

---

### Fix — DMG mount fails: "Object is not a mountable filesystem" (`src-tauri/src/main.rs`)

DMG files contain a partition table (Apple Partition Map or GPT). `udisksctl loop-setup` creates `/dev/loopN` but the filesystem lives on the first partition `/dev/loopNp1`. Passing the loop device directly to `udisksctl mount` failed because it is not itself a filesystem.

**Fix:** Switched to `losetup --find --read-only --partscan --show` which creates partition nodes. After a 400 ms udev settle delay, scans `/sys/block/loopN/` for `loopNpM` entries and mounts the first partition. Falls back to the loop device itself for flat DMGs with no partition table. Cleanup on mount failure uses `losetup -d`.

---

### Feature — Font preview with Install button (`src/utils.js`, `src/views.js`, `src-tauri/src/main.rs`, `src/style.css`)

`.otf` and `.ttf` (and `.woff`/`.woff2`) files now show a live font specimen in the preview panel and a one-click Install button.

**Specimen (`src/views.js`):** A `@font-face` rule served via the media port loads the font into the preview panel. The specimen shows a large display sample (`Aa Bb Cc`), the full alphabet, digit/symbol row, and two pangrams at different sizes.

**Install button:** Clicking Install calls `install_font` (Rust). An indeterminate progress bar animates during the `fc-cache` rebuild. On success the button turns green and is disabled. On failure the error is shown inline with a red bar.

**Rust (`src-tauri/src/main.rs`):**
- `install_font(path)` — async, copies to `~/.local/share/fonts/`, runs `fc-cache -f`. Returns installed path.
- `is_font_installed(filename)` — sync check; used to disable the Install button if already present.

**`src/utils.js`:** Added `FONT_EXTS = ['otf','ttf','woff','woff2']`, orange colour accent (`#fb923c`), `mimeLabel` entries for all four font MIME types.

---


## What's in Beta-5-r5

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src/utils.js`, `src/views.js`, `src/ql-window.js`, `src/style.css`.

### Fix — Auto-refresh: only the last-navigated column was watched (`src-tauri/src/main.rs`, `src/main.js`)

`watch_dir` previously accepted a single `path: String` and watched only the most recently navigated directory. In column view with three columns open (e.g. Home → Projects → src), only the rightmost column fired `dir-changed`. Files transferred, downloaded, or pasted into any other open column were never detected until the user navigated away and back.

**Fix (`src-tauri/src/main.rs`):** `watch_dir` now accepts `paths: Vec<String>` and registers a `RecursiveMode::NonRecursive` watcher on every path in the list. The debounce thread now uses `HashSet<String>` to coalesce bursts per directory — rapid events across multiple directories within the 300 ms window each produce exactly one `dir-changed` emission with the specific changed path as payload.

**Fix (`src/main.js`):** The `watch_dir` call site now passes all currently-open column paths plus the just-navigated path: `invoke('watch_dir', { paths: [...new Set([...state.columns.map(c => c.path), path])] })`. All standard triggers that refresh the directory listing are covered — transfer complete, paste complete, download complete (`.crdownload → filename` rename), drag-drop, terminal create/delete.

---

### Feature — RTF file support (`src/utils.js`, `src-tauri/src/main.rs`)

`.rtf` files are now recognised as documents throughout the app.

- Added `'rtf'` to `DOC_EXTS` in `utils.js` — RTF files get the document icon and doc-grey colour.
- Added `'rtf'` to `text_exts` in `get_file_preview` (Rust) — the file is read as plain text and shown in the preview code block and QL text pane. RTF source is human-readable markup, so the raw text preview is genuinely useful.
- Added `mime_type` entry: `"rtf" => "application/rtf"`.
- Added `'application/rtf': 'RTF Document'` to `mimeLabel` in `utils.js`.

---

### Feature — XCF (GIMP) file support (`src/utils.js`, `src/views.js`, `src/ql-window.js`, `src/style.css`)

`.xcf` files are now recognised as images for icon/colour purposes, with a graceful "can't render inline" fallback in all preview surfaces.

- Added `'xcf'` to `IMAGE_EXTS` — gets the image icon and GIMP-green (`#34d399`) colour accent.
- Added `mime_type`: `"xcf" => "image/x-xcf"` and `mimeLabel` entry `'image/x-xcf': 'GIMP Image'`.
- **Preview panel (`src/views.js`):** New `ext2 === 'xcf'` branch renders a centred icon + "XCF files cannot be rendered inline. Open in GIMP to view or edit." nudge instead of attempting an `<img>` decode that would silently fail.
- **Gallery (`src/views.js`):** `IMAGE_EXTS.includes(ext) && ext !== 'xcf'` guard prevents XCF from entering the image-slot path. XCF falls through to a `gallery-dir-preview` card showing the icon and "GIMP Image · Cannot preview inline".
- **Quick Look (`src/ql-window.js`):** `isXcf` branch renders the same open-in-app message in the QL window body.
- **CSS (`src/style.css`):** Added `.preview-xcf`, `.xcf-label`, `.xcf-hint` rules.

---

### Feature — DMG (Apple Disk Image) mount/unmount (`src-tauri/src/main.rs`, `src/utils.js`, `src/views.js`, `src/ql-window.js`)

`.dmg` files are now treated as mountable drives, mirroring the existing ISO workflow.

**Rust (`src-tauri/src/main.rs`):** Three new `#[tauri::command]` functions:
- `mount_dmg(path)` — `udisksctl loop-setup --read-only` + `udisksctl mount`; returns mountpoint. Falls back to `losetup -j` if udisksctl output parsing fails.
- `unmount_dmg(loop_dev)` — `udisksctl unmount` + `udisksctl loop-delete`; falls back to `losetup -d`.
- `get_dmg_loop_device(dmg_path)` — scans `losetup --list --json` to find the active loop device for a given DMG path.

All three are Linux-only (`#[cfg(target_os = "linux")]`) with clear error messages on other platforms. All three registered in `invoke_handler`.

**`src/utils.js`:** Added `DMG_EXTS = ['dmg']`; disc icon; pink (`#f472b6`) colour; `mime_type` `application/x-apple-diskimage`; `mimeLabel` `'Apple Disk Image'`.

**Preview panel (`src/views.js`):** New `DMG_EXTS.includes(ext2)` branch renders Mount/Unmount buttons (reusing `.iso-btn` / `.iso-actions` styles). `_wireDmgPreview()` controller wires async mount-state check + Mount/Unmount click handlers. On mount success, navigates into the mountpoint automatically.

**Gallery (`src/views.js`):** DMG files render a disc-icon info card (size + "Apple Disk Image" label). No inline mount controls in gallery — user opens the file to use the preview panel.

**Quick Look (`src/ql-window.js`):** `isDmg` branch renders a compact Mount/Unmount panel directly inside the QL window body, wired inline.

---

### Feature — HTML file web-page preview (`src/utils.js`, `src/views.js`, `src/ql-window.js`, `src/style.css`)

`.html` and `.htm` files previously displayed as raw source text. They now render as a live web page via a sandboxed `<iframe>` served through the existing media port, in all three preview surfaces.

- **`src/utils.js`:** Added `HTML_EXTS = ['html', 'htm']`. Removed `'html'` from `DOC_EXTS` (source-text treatment). Added `mimeLabel` entry `'text/html': 'HTML Document'`. HTML files get the document icon.
- **Preview panel (`src/views.js`):** New `HTML_EXTS.includes(ext2)` branch inserts `<iframe class="preview-html" sandbox="allow-scripts allow-same-origin">` inside `.preview-html-wrap` — same flex/border-radius pattern as `.preview-pdf-wrap`.
- **Gallery (`src/views.js`):** New `HTML_EXTS.includes(ext)` branch returns a `gallery-html-slot` iframe. Slot is included in the zoom-target selector.
- **Quick Look (`src/ql-window.js`):** `isHtml` branch appends a full-body `<iframe class="ql-html-frame">`. Media port gate includes `isHtml` so the port is fetched before rendering.
- **CSS (`src/style.css`):** Added `.preview-html-wrap`, `.preview-html`, `.gallery-html`, `.ql-html-frame` rules — mirrors the existing PDF iframe rules.

---


## What's in Beta-5-r1

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src-tauri/Cargo.toml`, `src-tauri/tauri.conf.json`, `src/main.js`, `src/style.css`, `index.html`.

### Feature — Sidebar operation progress bar (`src/main.js`, `src/style.css`, `index.html`)

All file operations now show a progress bar with live percentage at the bottom of the sidebar instead of floating toast bars.

#### Operations covered

| Operation | Trigger |
|---|---|
| Copy (Ctrl+C → Ctrl+V) | Paste via keyboard or menu |
| Move (Ctrl+X → Ctrl+V) | Paste via keyboard or menu |
| Drag-and-drop copy/move | Drop onto folder |
| Empty Trash | Trash banner button or context menu |

#### Design

A fixed slot `#sb-ops-progress` is appended inside `index.html` immediately after the sidebar `<aside>`. It slides up from below the sidebar when an operation starts (`transform: translateY(0)`) and slides back down when complete. The bar colour transitions to green on success or red on error, then auto-hides after 1.4 s (success) or 2.8 s (error).

The `_sbProgress` controller (`main.js`) exposes three methods used by all operations:
- `start(label, total)` — show bar, set initial label
- `update(done, total, label)` — advance bar and percentage counter in real time
- `finish(success, msg)` — snap to 100%, flash green/red, auto-hide

#### `empty_trash_stream` Rust command

The old synchronous `empty_trash` is supplemented by a new `empty_trash_stream` command that:
1. Counts total trash items first so progress can be computed
2. Emits `trash-progress` events `{done, total, finished}` per item deleted
3. Runs in `spawn_blocking` so the UI stays responsive during large trash operations

The JS `_emptyTrashWithProgress()` helper subscribes to `trash-progress` before invoking the command (preventing the missed-event race) and drives the sidebar bar.

### Status bump: Beta 4 → Beta 5

All core features are stable and complete:
- Column view, list view, icon view, gallery view
- Quick Look floating native window
- ISO mount / write-to-USB
- HEIC preview (via heif-convert)
- Multi-tab navigation, undo/redo
- File tags, search, drag-and-drop
- Sidebar operation progress bar (this release)

---

---

## What's in Beta-4-r50

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src-tauri/Cargo.toml`, `src/views.js`.

### Fix — ISO preview panel not showing (`src/views.js`)

The ISO branch in `renderPreview`'s if-chain was missing its closing `}else if(d2?.is_text...)` continuation. The ISO content string was built correctly, then immediately overwritten by `content=\`<pre class="preview-code">...\`` on the very next line. Result: selecting a `.iso` file showed the text preview fallback (which crashed trying to render `d2.content` on a binary file) instead of the ISO panel with Mount/Write to USB controls.

**Fix:** Restored the correct `}else if(d2?.is_text&&d2?.content!=null){` continuation after the ISO branch.

---

### Fix — ISO mount_iso: loop device not found (`src-tauri/src/main.rs`)

udisksctl writes "Mapped file ... as /dev/loopN." to **stderr** on some versions, not stdout. The original parser only scanned stdout, so the loop device path was never found and mount always failed.

**Fix:**
1. Combined stdout + stderr before scanning for the `/dev/loop` token
2. Cleaner token extraction: `trim_end_matches(['.', ',', ';'])` instead of fragile `.or(Some(w))` chain
3. Added `losetup -j <path>` fallback — if udisksctl output parsing still fails, `losetup -j` queries all active loop devices by backing file and returns the correct device

---

### Fix — Column 4+ click glitch: DOM-position-based column index (`src/views.js`)

The r49 fix used `state.columns.findIndex(c => c.path === col.path)` to find the live column index. This fails in two cases:
- **Same directory open twice**: if the user navigates into the same folder at two different depths, both columns share the same path. `findIndex` returns the first match, which is the wrong column.
- **State rebuild race**: after a rapid navigation, state.columns may be rebuilt with a new object at the same index. The old `col` (closure-captured) is no longer in state.columns, but another column *with the same path* still is — `findIndex` matches it incorrectly.

**Fix:** Use `Array.from(colEl.parentElement.children).indexOf(colEl)` — the colEl's actual DOM position among its siblings. This is always unambiguous: each DOM element has exactly one position, regardless of paths or state rebuilds. Added bounds check (`liveCI >= state.columns.length`) to catch the case where state.columns was truncated below the column's position.

---

---

## What's in Beta-4-r49

**No Rust recompile required.** Change in `src/views.js` only.

### Fix — Column view glitch when clicking folders in subdirectories (`src/views.js`)

Two related bugs in the column list click handler caused glitches specifically when clicking directories in deep columns (3rd level and beyond).

#### Bug 1 — Stale closure-captured `ci` used for `state.columns.splice()`

**Root cause:** The click handler used `ci`, which is captured from the `forEach` index at column BUILD time. This is normally correct because columns are only appended/trimmed from the end and never reordered. However, during rapid navigation (user clicks before the previous `navigate()` resolves), the async `navigate()` from a previous click could rebuild state.columns with a different layout. If a click event fired from a column whose `ci` no longer matched its actual position in `state.columns`, `state.columns.splice(ci + 1)` would truncate at the wrong index — potentially removing the wrong trailing columns or leaving stale ones.

**Fix:** At the start of the click handler, the column's *live* position is found by path: `state.columns.findIndex(c => c.path === col.path)`. If the column's path is no longer in `state.columns` at all (the column was removed by a concurrent navigation), the handler bails immediately. All subsequent `splice` and `navigate` calls use `liveCI` instead of `ci`.

#### Bug 2 — Detached `colList` could still receive queued click events

**Root cause:** When the reconciliation loop removes a column from the DOM (e.g. because the user navigated to a sibling folder), the column's `colList` element is detached. However, a click event that was already queued in the browser's event loop (user clicked just before reconciliation ran) could still fire on the detached element. The existing guard `row.closest('.col-list') !== colList` only checked that the row belongs to *this* colList — it did not check whether colList was still in the document.

A click on a detached `colList` would run `state.columns.splice(ci + 1)` (now using the stale `ci`) and call `navigate()`, corrupting the column state and causing the visible glitch: wrong columns appearing, columns jumping, or the view resetting unexpectedly.

**Fix:** Added `if (!colList.isConnected) return` as the first check in the click, dblclick, and contextmenu handlers. A detached list cannot have valid column state and any event on it is discarded immediately.

---

---

## What's in Beta-4-r48

**Rust recompile required.** Fixes two build errors from r47.

### Fix — JS syntax error: orphaned media-slot code outside any function (`src/views.js`)

The `str_replace` that inserted the ISO preview wiring accidentally left a duplicate copy of the video/audio media-slot block (lines 2681–2718) outside any function, between `_showIsoBurnDialog`'s closing brace and the Tags UI section. esbuild's parser rejected the file with `Unexpected "}"`.

**Fix:** Removed the orphaned duplicate. The authoritative copy inside `renderPreview` (which was always correct) is unchanged.

### Fix — `ExitStatus::from_raw` trait not in scope (`src-tauri/src/main.rs`)

`write_iso_to_usb` used `std::process::ExitStatus::from_raw(1)` as a fallback when `child.wait()` fails. `from_raw` requires the `std::os::unix::process::ExitStatusExt` trait to be in scope, which was not imported.

**Fix:** Replaced the `unwrap_or_else(|_| from_raw(1))` pattern with a direct `let success = child.wait().map(|s| s.success()).unwrap_or(false)` check, eliminating the trait dependency entirely.

---

---

## What's in Beta-4-r47

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src-tauri/Cargo.toml`, `src/views.js`, `src/main.js`, `src/style.css`.

### Fix — HEIC grayscale: use heif-convert as primary decoder (`src-tauri/src/main.rs`)

**Root cause:** ffmpeg's MJPEG encoder requires `yuvj420p`, but HEIC files often contain Display P3, bt2020 (HDR), or 10-bit (`yuv420p10le`) colorspaces. Even with the `format=yuv420p` filter added in r44, ffmpeg's libheif wrapper doesn't always correctly perform the colorspace conversion before the encoder — the internal negotiation path varies by ffmpeg build and libheif version, producing silent grayscale output on many Arch/CachyOS systems.

**Fix:** `heif-convert` (from the `libheif-examples` package) is now tried first for both thumbnail generation and full-resolution `/heic-jpeg/` display. `heif-convert` uses libheif's native colorspace handling — it always outputs correct RGB regardless of the input colorspace. Workflow:

1. Run `heif-convert -q 90 input.heic /tmp/ff_heic_NNN.png`
2. Load the PNG with the `image` crate, resize, encode as JPEG → cache
3. If `heif-convert` is not installed or fails: fall back to ffmpeg with `format=yuv420p -pix_fmt yuvj420p`

Install the required package:
```bash
sudo pacman -S libheif   # includes heif-convert
```

> **Note:** Delete `~/.cache/frostfinder/thumbs/` after upgrading to force thumbnail regeneration with the new decoder.

---

### Fix — "Burn" renamed to "Write to USB Drive" (`src-tauri/src/main.rs`, `src/views.js`, `src/main.js`)

**Previous behaviour:** The "Burn to Disc…" button/action was wired to `wodim` targeting optical drives.

**New behaviour:** The feature is now "Write to USB Drive" and writes the ISO to a removable USB drive using `dd`. No extra tools needed — `dd` is standard on all Linux systems.

#### `list_usb_drives()` replaces `list_optical_drives()`
Lists removable whole-disk devices via `lsblk -J -b -o NAME,SIZE,TYPE,RM,HOTPLUG,...`. Returns `Vec<(device, label, size_bytes)>`. Filters: `type=disk`, `rm=true or hotplug=true`, not mounted at `/` or `/boot`. Sizes shown in drive selector dropdown.

#### `write_iso_to_usb(iso_path, device)` replaces `burn_iso()`
- Multiple safety checks: only `/dev/sd*`, `/dev/hd*`, `/dev/vd*`, `/dev/mmcblk*`; whole disk only (no partition numbers); refuses to touch the system root disk
- Unmounts all partitions on the target device before writing (best-effort `umount -l`)
- Runs `dd if=<iso> of=<device> bs=4M status=progress oflag=sync`
- Progress via SIGUSR1 ticker thread → parses dd's byte-count lines → emits `iso-burn-progress` events with `{percent, line, bytes_written, done, error?}`
- Final `sync` to flush kernel write buffers to hardware before reporting complete
- All work in `spawn_blocking` — UI fully responsive during write

Emits `iso-burn-progress` events identical to before so the progress bar UI in the preview panel is unchanged.

---

---

## What's in Beta-4-r46

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src-tauri/Cargo.toml`, `src/utils.js`, `src/views.js`, `src/main.js`, `src/style.css`.

### Feature — ISO disc image: mount and burn (`src-tauri/src/main.rs`, `src/views.js`, `src/main.js`, `src/utils.js`, `src/style.css`)

#### Four new Rust commands

**`mount_iso(path)`** — Mounts a `.iso` file as a read-only loop device using `udisksctl loop-setup` + `udisksctl mount`. Returns the mountpoint (e.g. `/run/media/user/LABEL`). No sudo required — Polkit handles privilege via udisks2. After mounting, FrostFinder automatically navigates into the ISO contents.

**`unmount_iso(loop_dev)`** — Unmounts and detaches the loop device. First tries `udisksctl loop-delete`, falls back to `losetup -d`.

**`get_iso_loop_device(iso_path)`** — Checks whether an ISO is currently mounted by scanning `losetup --list --json` for a matching back-file. Returns the loop device path (`/dev/loopN`) or empty string.

**`list_optical_drives()`** — Lists writable optical drives by scanning `lsblk -J -o NAME,TYPE,VENDOR,MODEL` for entries with `type=rom`. Returns `Vec<(device, label)>` e.g. `[("/dev/sr0", "ASUS DRW-24D5MT")]`.

**`burn_iso(iso_path, device)`** — Burns an ISO to an optical drive using `wodim`. Runs in a `spawn_blocking` thread so the UI stays responsive during the entire burn (which can take 10+ minutes). Parses wodim's `Track 01: XX MB written` output lines to compute percentage progress. Emits `iso-burn-progress` events: `{percent, line, done, error?}`. Automatically ejects the disc when done.

#### ISO preview panel (`src/views.js`)

Selecting a `.iso` file in the preview panel shows a dedicated ISO view with:
- Disc icon with glow effect
- File size
- Mount status (checked async via `get_iso_loop_device` on load)
- **Mount ISO** button → calls `mount_iso`, navigates to mountpoint on success
- **Unmount** button (shown when mounted) → calls `unmount_iso`
- **Burn to Disc…** button → opens optical drive picker dialog

The status indicator updates live: green "Mounted as /dev/loopN" or grey "Not mounted".

#### Burn dialog (`src/views.js`)

A modal dialog with drive selector (populated from `list_optical_drives`), safety warning, and inline progress bar. Progress lines from wodim stream in real-time via the `iso-burn-progress` Tauri event.

#### Context menu actions (`src/main.js`)

Right-clicking a `.iso` file adds two items:
- **Mount ISO** — mounts immediately, navigates to mountpoint
- **Burn to Disc…** — opens the burn dialog via the preview panel

#### Utils additions (`src/utils.js`)
- `ISO_EXTS = ['iso']` constant
- `disc` SVG icon (concentric circles)
- `mount` / `unmount` / `burn` SVG icons
- ISO color `#f472b6` (pink)
- ISO file icon → `disc`
- `mimeLabel` entry for `application/x-iso9660-image`

#### Dependencies
- `udisks2` — required for mount/unmount (install: `sudo pacman -S udisks2`)
- `wodim` — required for burning (install: `sudo pacman -S cdrtools`)
- `util-linux` — provides `losetup` (standard on all Linux)

---

---

## What's in Beta-4-r45

**No Rust recompile required.** Change in `src/style.css` only.

### Fix — Column view layout thrash and glitches on deep navigation (`src/style.css`)

Three CSS bugs were causing column-view glitches that worsened with each level of depth navigated.

#### Bug 1 — `.col:last-child { flex:1 }` caused width snapping on every navigation

**Root cause:** The last column in the strip had `flex:1`, making it expand to fill remaining horizontal space. Every time a column was added or removed:

1. The previous last-child lost `flex:1` and snapped from a variable wide width back to 220px
2. The new last-child gained `flex:1` and expanded
3. That synchronous width change triggered the `ResizeObserver` on the affected column's `col-list`
4. `_paintColList` ran unnecessarily on a column whose content hadn't changed
5. The visible width flash showed as a column "jumping" on every navigation step

This matched the document's diagnosis: *"If glitches start around column 3, there's a high chance your UI is doing layout reflow when columns overflow the container."*

**Fix:** Removed `flex:1` from `.col:last-child`. All columns are now fixed-width at all times. `min-width:max-content` on `.cols-container` already handles strip expansion. Only `border-right:none` is kept on the last child.

```css
/* Before */
.col:last-child { border-right:none; flex:1; }

/* After */
.col:last-child { border-right:none; }
```

#### Bug 2 — Missing `contain` on `.col` allowed cross-column layout propagation

**Root cause:** Without CSS containment, a reflow inside any column (row elements added/removed by the virtual scroller, spacer height change) could propagate across all sibling columns. This is the CSS equivalent of the document's warning about layout feedback loops — each column should be fully isolated from its neighbours.

**Fix:** Added `contain:layout style paint` to `.col`. Each column is now a layout containment boundary. Reflows inside one column cannot affect any other column.

```css
/* Before */
.col { width:220px; flex-shrink:0; ... }

/* After */
.col { width:220px; min-width:220px; flex-shrink:0; contain:layout style paint; ... }
```

`min-width:220px` added alongside `width` so the column cannot be squeezed below its intended width by a flex parent even when `contain` changes its box model participation.

#### Bug 3 — Dead `will-change:transform` + `transition` on `.cols-container`

**Root cause:** `.cols-container` had `will-change:transform` and `transition:transform 0.18s`. The transform value was never actually changed in any JS code path, so the animation never fired — but `will-change:transform` told the GPU to allocate a dedicated compositing layer for the *entire column strip*, including all columns and their contents. This was unnecessary VRAM usage and forced the browser to composite the full strip as a single texture.

**Fix:** Removed both `will-change:transform` and `transition:transform`. The GPU compositor now handles each column independently via the `contain` and `will-change:scroll-position` rules already present.

---

---

## What's in Beta-4-r44

**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src-tauri/Cargo.toml`, `src/views.js`.

### Fix — HEIC/HEIF images display in grayscale (`src-tauri/src/main.rs`)

**Root cause:** Both the `make_thumbnail` function and the `/heic-jpeg/` full-resolution endpoint used `ffmpeg -vcodec mjpeg` without specifying a pixel format. The MJPEG encoder requires `yuvj420p` (JPEG-range 8-bit YUV). HEIC files frequently use non-compatible internal pixel formats:

- 10-bit HEIC → `yuv420p10le` — MJPEG cannot encode this directly
- HDR/wide-gamut HEIC → `bt2020` colorspace — chroma conversion fails silently

When ffmpeg receives a pixel format the MJPEG encoder cannot handle, it silently drops the chroma plane and emits a grayscale JPEG. No error is logged.

**Fix — two sites in `main.rs`:**

**1. `make_thumbnail` (thumbnail generation):** Added `format=yuv420p` to the `-vf` filter chain and `-pix_fmt yuvj420p` flag. `format=yuv420p` forces an 8-bit SDR colorspace conversion before the encoder; `-pix_fmt yuvj420p` explicitly selects the JPEG-range variant the MJPEG encoder expects.

```
Before: -vf "scale=256:256:force_original_aspect_ratio=decrease" -f image2 -vcodec mjpeg
After:  -vf "scale=256:256:force_original_aspect_ratio=decrease,format=yuv420p" -pix_fmt yuvj420p -f image2 -vcodec mjpeg
```

**2. `/heic-jpeg/` full-resolution endpoint:** Same fix — added `-vf format=yuv420p -pix_fmt yuvj420p` before the output flags. This corrects full-resolution HEIC display in the preview panel, gallery main view, lightbox, and Quick Look window.

```
Before: -f image2 -vcodec mjpeg pipe:1
After:  -vf format=yuv420p -pix_fmt yuvj420p -f image2 -vcodec mjpeg pipe:1
```

**Important:** Any HEIC thumbnails already in the cache will still be grayscale until the cache entry expires (or the source file is modified). Delete `~/.cache/frostfinder/thumbs/` to force regeneration.

---

### Fix — Preview panel image flickers on every watcher event (`src/views.js`)

**Root cause:** `renderPreview()` had a `sameVideo` short-circuit guard (skips full panel rebuild when the same video is already playing), but no equivalent guard for images. Every `render()` call — including those triggered by filesystem watcher events every ~300ms during active downloads — tore down and recreated the `<img>` element unconditionally. The browser fetched the image URL again on each rebuild, producing a visible reload flash every few hundred milliseconds whenever a download was in progress or any file in the watched directory was being written.

**Fix:** Added a `sameImage` guard mirroring `sameVideo`. When the same image path is already displayed (`panel.dataset.previewPath === e.path`), the extension hasn't changed, and `#preview-img` is still connected to the DOM, `renderPreview` returns immediately after refreshing only the tags section — no `<img>` teardown, no network reload, no flash.

```js
const sameImage = e && IMAGE_EXTS.includes(newExt)
  && panel.dataset.previewPath === e.path
  && panel.dataset.previewExt  === newExt
  && _previewImg?.isConnected;
if (sameImage) {
  // refresh tags only — image element untouched
  return;
}
```

---

## What's in Beta-4-r43



**Rust recompile required** (off-by-one fix in `main.rs`). Also changes `src/main.js`.

### Fix — Watcher-triggered freeze on large folders (`src/main.js`)

**Root cause:** `refreshColumns()` was calling `listDirectory(col.path)`, which maps to the `list_directory` Rust command. That command stats every file with full metadata (size, mtime, permissions) using rayon, then serialises the entire `Vec<FileEntry>` as one JSON blob across the IPC bridge. On a Downloads folder with 1500 files this produces a ~300 KB payload that WebKit blocks the main thread deserialising — and it happened on every watcher event (debounced to 300 ms).

**Fix:** `refreshColumns()` now calls `invoke('list_directory_fast', {path})` instead. This returns `FileEntryFast` (name + type only, zero `stat()` calls — `file_type()` is free on Linux from the `dirent` `d_type` field). The payload shrinks from ~300 KB to ~40 KB and involves no syscalls beyond `read_dir`. Column view only needs names and directory flags for the fingerprint check and row display; full metadata is fetched lazily on selection as before.

---

### Fix — Column stuck at 60 entries after fast navigation (`src/main.js`)

**Root cause:** When the user clicked quickly through subdirectories (col1 → col2 → col3 before col2 finished streaming), the stale guard in `_streamDir` fired `resolve(null)` as soon as `mySeq !== _navSeq` — abandoning the stream immediately. The col2 element was left frozen at its first-paint chunk (60 entries) because the full entry list never arrived. The column looked wrong and was empty for most of its files until the user revisited it.

**Fix:** The stale guard no longer abandons mid-stream. When `mySeq !== _navSeq`, chunks are still accumulated silently. On `done:true`:
1. The Rust cache is already populated (happens inside `list_directory_streamed` before the final emit).
2. `col.entries` and `col._fp` are patched in-place on the state object.
3. `_jsCacheSet` stores the full list for zero-IPC revisits.
4. `colEl._patchEntries()` is called directly on the DOM column element to update the visible rows without triggering a full `render()`.

The column fills in completely regardless of how fast the user navigated through it.

---

### Fix — Duplicate entries in dirs with exactly 60 files (`src-tauri/src/main.rs`)

**Root cause:** In `list_directory_streamed`, `already_sent` was computed as:

```rust
let already_sent = if total <= FIRST_CHUNK { 0 } else { ... };
```

The first-paint chunk fires when `all.len() == FIRST_CHUNK` (exact equality). With `<=`, a directory containing exactly 60 files set `already_sent = 0` and re-sent all 60 entries in the `done` chunk — JS accumulated 120 entries and rendered every file twice.

**Fix:** Changed `<=` to `<`:

```rust
let already_sent = if total < FIRST_CHUNK { 0 } else { ... };
```

Directories with exactly `FIRST_CHUNK` entries now correctly set `already_sent = FIRST_CHUNK` and send an empty remainder in the done chunk.

---



**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src/views.js`, `src/ql-window.js`, and `src/main.js`.

### Fix — 3rd-column glitch on deep subfolder navigation (`src/views.js`)

**Root cause:** When navigating into a subdirectory in column view, the streamer emits a first-paint chunk (60 entries) immediately, then continues streaming the rest. When `done:true` arrives, `_patchEntries` fully repaints the column and sets `_cPainted` to the correct rendered range. However, the double-RAF scheduled at column-build time was still pending and fired *after* `_patchEntries` had already finished — it unconditionally reset `_cPainted = {-1,-1}` and called `_paintColList()` again from scratch.

This second repaint used whatever `scrollTop` and `clientHeight` were at that moment (often wrong — the scroll container may have shifted after `_patchEntries` scrolled to the selection), producing rows rendered at the wrong offsets. On the 3rd column and deeper, where the horizontal scroll container had already settled and the column height was stable, this manifested as a visible row flash or misaligned selection.

**Fix:** A guard is added at the top of the double-RAF callback:

```js
if (_cPainted.start !== -1) return;
```

`_patchEntries` always leaves `_cPainted` with a valid non-`{-1,-1}` range after painting. If it ran before the RAF fires, the RAF exits immediately. If the RAF fires first (empty dir or very fast IPC), `_cPainted` is still `{-1,-1}` and the RAF proceeds as normal. The original double-RAF purpose (deferred first-paint for correct `clientHeight`) is fully preserved for all cases where `_patchEntries` hasn't run yet.

---

### Fix — Large folder freeze made worse by r40 (`src-tauri/src/main.rs`)

**Root cause of the regression:** r40 introduced `list_directory_full_streamed` to break the single large IPC response into 100-entry chunks. However, the implementation switched from `raw.into_par_iter()` (rayon parallel stat across all entries simultaneously) to `batch.iter()` (sequential stat within each chunk). This was strictly worse — the same total number of `stat()` syscalls, but now serialised rather than parallelised. A 1500-file Downloads folder went from ~80ms parallel stat to ~600ms+ sequential stat, making the freeze significantly longer.

**Fix:** Restore rayon parallelism for the stat phase, then chunk the *already-built* `Vec<FileEntry>` purely for IPC emission:

```
Phase 1 (rayon): stat all entries in parallel → Vec<FileEntry>   [fast, unchanged from pre-r40]
Phase 2 (emit):  loop chunks(100) over the vec → emit dir-full-chunk events  [new, prevents big IPC blob]
```

This gives the original stat speed back while keeping the chunked emit that prevents WebKit from blocking on one large JSON deserialisation.

---

### Fix — HEIC/HEIF files not displaying (`src-tauri/src/main.rs`, `src/main.js`, `src/views.js`, `src/ql-window.js`)

**Root cause:** The `image` crate used for thumbnail generation has no HEIC decoder. `make_thumbnail` would fail for `.heic`/`.heif` files, leaving `thumb_path` empty. The preview and gallery then fell back to serving the raw HEIC bytes via `getMediaUrl`, which WebKit2GTK cannot decode natively on Linux — so nothing was shown.

**Fix — three parts:**

**1. Thumbnail generation** (`make_thumbnail` in `main.rs`): HEIC/HEIF files are now detected by extension before the `image` crate reader is invoked. ffmpeg is used instead:

```rust
if ext == "heic" || ext == "heif" {
    // ffmpeg -i input.heic -vf scale=256:256:... -f image2 -vcodec mjpeg pipe:1
    // Output captured as bytes, stored in the thumb cache as JPEG.
}
```

The cached thumbnail is a standard JPEG, served via the existing media server like all other thumbnails.

**2. New `/heic-jpeg/` media server endpoint** (`handle_media_request` in `main.rs`): For full-resolution display (preview panel click-to-fullscreen, gallery main view), the raw HEIC file is piped through ffmpeg on-the-fly and served as `image/jpeg`. This avoids loading the entire file into memory — ffmpeg stdout is streamed directly to the TCP socket.

**3. `getHeicJpegUrl()` in JS** (`main.js`, injected into `views.js` and `ql-window.js`): All `<img>` src assignments for HEIC/HEIF files now use `/heic-jpeg/` instead of the direct media URL:
- Preview panel (`renderPreview` in `views.js`)
- Gallery main image slot (`renderGalleryView` in `views.js`)
- Quick Look window image (`ql-window.js`)

Non-HEIC images are unaffected — they continue to use `getMediaUrl` directly.

---



**Rust recompile required.** Changes in `src-tauri/src/main.rs`, `src/main.js`, and `src/utils.js`.

### Feature — HEIC / HEIF added to image types (`src/utils.js`, `src-tauri/src/main.rs`)

`.heic` and `.heif` are now recognised as image files across the entire app:

- `IMAGE_EXTS` in `utils.js` — affects colour coding, icon selection, and preview routing in all views
- `is_image_ext()` in `main.rs` — enables thumbnail generation and image preview path in `preview_file`
- `mime_type` match in `preview_file` — returns `image/heic` / `image/heif` so the media server serves them with the correct content type
- `mime_for_path()` in `main.rs` — media server HTTP handler now serves HEIC/HEIF with correct MIME type

Note: in-app `<img>` preview of HEIC depends on WebKit2GTK having HEIC decode support (present in recent builds with libheif). The preview panel falls back gracefully if the codec is unavailable.

---

### Fix — Large folder freeze (Downloads, etc.) (`src-tauri/src/main.rs`, `src/main.js`)

Opening a folder with hundreds or thousands of files caused the app to freeze for 1–2 seconds. Two independent code paths both had this problem.

#### Root cause 1 — Column view tail chunk (`list_directory_streamed`)

The streamed column-view lister correctly emitted a first-paint chunk of 60 entries immediately. However, all remaining entries — up to 1400+ on a large Downloads folder — were sent as a **single** `dir-chunk` event. WebKit's main thread blocked while deserialising that one large JSON blob.

**Fix:** The tail is now emitted in batches of 150 entries. A 1500-file directory now sends ~10 events of ≤150 entries each instead of one event of 1440, giving WebKit room to breathe between chunks.

```
Before: [60] ——— stall ——— [1440 done]
After:  [60] [150] [150] [150] … [remainder done]
```

#### Root cause 2 — List / Gallery / Icon view (`list_directory` → `list_directory_full_streamed`)

These views called `list_directory`, which stat'd every file in parallel with rayon (good) but then returned the entire `Vec<FileEntry>` as a **single `invoke` response**. The whole blob crossed the Tauri WebKit IPC bridge in one shot — same deserialisation freeze as above, but worse because `FileEntry` carries full stat metadata (size, mtime, permissions, etc.) making each entry larger than the fast `FileEntryFast` used in column view.

**Fix:** A new `list_directory_full_streamed` command emits `dir-full-chunk` events in 100-entry batches using the same event pattern as `list_directory_streamed`. The JS `listDirectoryFull()` function now calls this command and reassembles the entries from the stream, identical in API to the caller. The old `list_directory` command is retained for any internal uses.

---



**No Rust recompile required.** Changes in `src/views.js` and `src/ql-window.js` only.

### Fix — MOV files auto-launched mpv without user action (`src/views.js`, `src/ql-window.js`)

`.mov` was listed in `WEBKIT_SKIP_EXTS` in both `views.js` and `ql-window.js`. This set causes `_mountMpvPlayer` (and its QL equivalent) to bypass the `<video>` element entirely and call `mpv_open_external` immediately — no user interaction required. Any MOV file selected in the gallery, preview panel, or Quick Look window silently launched an mpv process.

**Root cause:** MOV was added to `WEBKIT_SKIP_EXTS` as a precaution, but the backend media server already serves `.mov` as `video/quicktime` and GStreamer handles H.264/AAC QuickTime containers natively on Wayland/Linux. The skip was unnecessary.

**Fix:** `'mov'` removed from `WEBKIT_SKIP_EXTS` in both files.

```js
// Before
const WEBKIT_SKIP_EXTS = new Set(['avi','mov','m4v','ogv']);

// After
const WEBKIT_SKIP_EXTS = new Set(['avi','m4v','ogv']);
```

MOV files now route through the standard `<video>` + local HTTP media server path, identical to `.mp4` and `.webm`. In QL, the existing 5s stall-detection + ffmpeg transcode fallback handles any edge-case MOV codec that GStreamer cannot decode natively. mpv is only involved if the user explicitly clicks the fullscreen/open-with-mpv button, or if both GStreamer and the transcode path fail.

---



**No Rust recompile required.** Change in `src/views.js` only.

### Fix — Column view glitches with deep subdirectory navigation (`src/views.js`)

Three compounding bugs caused progressive rendering degradation as you navigated deeper into subdirectories. The effects accumulated with every new column opened.

#### Bug 1 — `ResizeObserver` never disconnected on column removal

Every column build creates a `ResizeObserver` on its `colList` to repaint when the column is resized. When the reconciliation loop removes a column from the DOM (navigating back to a parent folder and into a sibling), the column element is removed with `.remove()` but the `ResizeObserver` is never explicitly disconnected.

A `ResizeObserver` attached to a detached DOM element stops *firing* but stays alive in memory, holding a reference to the closed-over `_paintColList` function and the entire column closure. After 8+ levels of deep navigation, multiple observers accumulate. When anything causes layout recalculation across the page (e.g. the horizontal scroll container getting a new scrollbar), **all accumulated observers fire simultaneously**, each calling `_paintColList` on their respective (now detached) `colList` elements and fighting the live columns for layout budget.

**Fix:** The `ResizeObserver` instance is now stored as `colEl._colRO`. The reconciliation cleanup helper calls `colEl._colRO.disconnect()` before every `container.lastChild.remove()`.

#### Bug 2 — Rubber-band `document` event listeners never removed

`attachRubberBand` registers two `document`-level listeners (`mousemove`, `mouseup`) per column and returns a cleanup function to remove them. The return value was **never stored or called** in `renderColumnView`, so every column visit permanently added two `document` handlers.

These handlers exit immediately via `if (!armed) return` since `armed` can never be set on a removed column's container, so they don't cause incorrect behavior — but with 10+ columns navigated through, 20+ dead handlers fire on every mouse movement. On large directories, this adds up to visible UI lag that presents as "glitchy" column behavior.

**Fix:** The cleanup function returned by `attachRubberBand` is now stored as `colEl._rbCleanup`. The reconciliation cleanup helper calls `colEl._rbCleanup()` before removal.

#### Bug 3 — Initial `_paintColList` called before column is in the DOM

The first `_paintColList()` was called immediately after setting up the virtual scroller, before `colEl.appendChild(colList)` and `container.appendChild(colEl)`. At this point `colList.clientHeight = 0`, so the fallback `|| 400` was used. This painted approximately 20 rows regardless of the column's actual rendered height.

The `ResizeObserver` corrected this in the next frame, but:
- For deep columns (scrolled far right), the one-frame wrong paint was visible as a flash
- The pre-selection scroll RAF used the same `0 → 400px` fallback, setting scroll position based on wrong height — causing the selected row to appear at the bottom of the column instead of centered

**Fix:** The premature `_paintColList()` is removed. A double-`requestAnimationFrame` (fires after layout + horizontal scrollbar settlement) handles the initial paint and scroll-to-selection together:

```js
requestAnimationFrame(() => requestAnimationFrame(() => {
  if (!colList.isConnected) return;  // safety: column removed before first paint
  _cPainted = {start: -1, end: -1};
  if (col.selIdx >= 0) {
    // scroll to selected row using correct clientHeight
    ...
  }
  _paintColList(); // correct height, correct range, no flash
}));
```

Double-RAF ensures the horizontal scroll container has also settled its scrollbar layout (which reduces `clientHeight` by ~15px when many columns make the container overflow), giving a stable `clientHeight` for the paint range calculation.

---


## What's in Beta-4-r37

**No Rust recompile required.** Change in `src-tauri/tauri.conf.json` only.

### Change — AppImage removed from build targets (`src-tauri/tauri.conf.json`)

AppImage bundling on Arch/CachyOS has proven unreliable across multiple fix attempts due to incompatibilities between Tauri's bundled `appimagetool`/`linuxdeploy` AppImages and the Arch environment (FUSE mount namespacing, `eu-strip` DWARF errors). Since `.deb` and `.rpm` bundles build and install cleanly, AppImage is simply removed from the target list.

`"targets": "all"` → `"targets": ["deb", "rpm", "nsis", "msi", "dmg"]`

The `appimage` config block added in r34/r36 is also removed as it is no longer needed.

---


## What's in Beta-4-r36

**No Rust recompile required.** Change in `src-tauri/.cargo/config.toml` only.

### Fix — AppImage still fails even with `fuse2` installed (`src-tauri/.cargo/config.toml`)

**Root cause — two independent failures in the AppImage toolchain:**

**1. `appimagetool` and `linuxdeploy` are themselves AppImages:**

Tauri downloads `appimagetool` and `linuxdeploy` at bundle time and runs them directly. Both tools are distributed as AppImages. On Arch/CachyOS they can fail to self-mount via FUSE even when `libfuse2` is installed — systemd scope restrictions, mount namespace isolation, or socket path mismatches can all prevent the FUSE mount from succeeding, producing a silent non-zero exit that Tauri reports as `error running appimage.sh`.

`APPIMAGE_EXTRACT_AND_RUN=1` tells these tools to extract their internal squashfs to a temp dir and run from there directly, bypassing FUSE entirely. This works on all systems and is the standard workaround for Arch-family environments.

**2. `eu-strip` crashes on Arch-built `.so` files:**

After `linuxdeploy` copies bundled libraries into the AppImage, it calls `eu-strip` (from `elfutils`) on each one. On Arch, libraries built with GCC 13+ include `-ffile-prefix-map=...` DWARF entries that `eu-strip` cannot represent, causing it to exit non-zero. This kills `appimage.sh`.

`NO_STRIP=1` skips the strip pass entirely. The FrostFinder binary itself is already stripped by cargo's `[profile.release]` settings; skipping `eu-strip` on bundled `.so` files only affects the AppImage size by a few MB.

**Fix — `src-tauri/.cargo/config.toml` `[env]` block:**

Variables in `.cargo/config.toml [env]` are inherited by all child processes spawned during `cargo tauri build`, including the Tauri bundler and the `appimage.sh` script it invokes. No wrapper script or shell export needed — these take effect automatically on every `npm run tauri build` invocation.

```toml
[env]
APPIMAGE_EXTRACT_AND_RUN = "1"   # bypass FUSE mount for appimagetool/linuxdeploy
NO_STRIP = "1"                    # skip eu-strip (crashes on Arch GCC 13+ libs)
```

---


## What's in Beta-4-r35

**No Rust recompile required.** Change in `src-tauri/tauri.conf.json` only.

### Fix — `tauri.conf.json` schema error: `'linux' was unexpected` (`src-tauri/tauri.conf.json`)

**Root cause:** In Tauri v1, `.deb` bundle configuration lives directly under `tauri.bundle.deb`, not wrapped inside a `tauri.bundle.linux` object. The r34 fix incorrectly added a `"linux": { "deb": {...} }` nesting that is valid in Tauri v2 but rejected by the Tauri v1 JSON schema validator with:

```
`tauri.conf.json` error on `tauri > bundle`: Additional properties are not allowed ('linux' was unexpected)
```

This error fires on both `tauri dev` and `tauri build` — the dev server cannot start at all.

**Fix:** Hoisted `deb` directly under `bundle`, removing the `linux` wrapper:

```json
// Before (invalid in Tauri v1):
"bundle": {
  "linux": { "deb": { "depends": [...] } }
}

// After (correct Tauri v1 schema):
"bundle": {
  "deb": { "depends": [...] }
}
```

---


## What's in Beta-4-r34

**No Rust recompile required.** Change in `src-tauri/tauri.conf.json` only.

### Fix — AppImage build fails: `error running appimage.sh` (`src-tauri/tauri.conf.json`)

**Root cause — two compounding issues:**

**1. `bundleMediaFramework` not set to `false`:**

Tauri's `appimage.sh` script, when `bundleMediaFramework` is unset (defaults to `true`), attempts to copy every GStreamer plugin, WebKit2GTK shared library, and associated media framework `.so` into the AppImage's internal `/usr/lib`. It then calls `linuxdeploy --plugin gtk` to recursively resolve and bundle transitive dependencies.

On CachyOS and Arch-based systems, this process fails because:
- WebKit2GTK has ~400 shared library dependencies (Mesa, VA-API, GStreamer elements, libdrm, etc.)
- `linuxdeploy`'s `strip` pass calls `eu-strip` (from `elfutils`) on each `.so`, and elfutils on Arch can fail with `DWARF error: cannot represent -ffile-prefix-map=... in DWARF` for libraries built with newer GCC flags
- The entire `appimage.sh` exits non-zero, Tauri reports `error running appimage.sh`

FrostFinder **cannot** usefully bundle WebKit2GTK inside an AppImage anyway — it uses the system WebKit2GTK and GStreamer pipeline for hardware-decoded video (VA-API, inotify, udisksctl). Bundling would produce a broken AppImage that ignores the system GPU/VA-API stack entirely.

**Fix:** Added `"appimage": { "bundleMediaFramework": false }` to `tauri.conf.json`. Tauri passes this flag to `appimage.sh` which skips the GStreamer/WebKit library bundling pass entirely. The AppImage will still embed the FrostFinder binary and its direct non-system Rust dependencies; all WebKit2GTK/GStreamer libs come from the system at runtime (correct behavior).

**2. Missing `libfuse2` on Arch/CachyOS (system fix, not source):**

AppImage itself requires FUSE 2 (`libfuse2`) to mount the `.AppImage` squashfs at runtime. CachyOS and modern Arch ship only `fuse3`; FUSE 2 is not installed by default. Even after the `bundleMediaFramework` fix, the resulting AppImage will fail to *run* on any Arch system without `libfuse2`.

```bash
# Install on CachyOS / Arch:
yay -S fuse2

# Or run AppImages without FUSE (extract-and-run):
./frost-finder-beta-build_4.0.34_amd64.AppImage --appimage-extract-and-run
```

**Alternative for CachyOS / Arch users:** Use the `.tar.gz` or build directly with `cargo tauri build --bundles deb,rpm`. The `.deb` and `.rpm` bundles completed successfully in r33 and do not require FUSE.

**3. Added `linux.deb.depends` for correct Debian packaging:**

Added explicit runtime dependency declarations for the `.deb` bundle:
- `libwebkit2gtk-4.0-37` — WebKit2GTK rendering engine
- `libgtk-3-0` — GTK3 window toolkit
- `libayatana-appindicator3-1` — system tray support

Without these, `dpkg -i` on Ubuntu/Debian succeeds but the app fails at launch with a missing-library error.

---


## What's in Beta-4-r33

**No Rust recompile required for Linux.** Rust recompile required for macOS and Windows (cross-platform fixes in `src-tauri/src/main.rs` and `src-tauri/Cargo.toml`).

### Fix — Full cross-platform build support: CachyOS, Fedora, Ubuntu, macOS, Windows

**Root cause — Linux-only code in `src-tauri/src/main.rs`:**

The entire Rust backend contained Linux-specific code that broke compilation on macOS and Windows:

1. **`mod libc` shadow module** — defined a custom `mod libc` with `statvfs64` (a Linux glibc extension). This shadowed the `libc` crate entirely, preventing `use libc::...` imports from working. On macOS/Windows, `statvfs64` doesn't exist, causing a linker error.

   **Fix:** Removed the `mod libc` shadow module entirely. `_get_disk_space_impl` now uses `libc::statvfs` (available on both Linux and macOS) behind `#[cfg(unix)]`, and returns `(0, 0)` on Windows.

2. **`get_permissions()` unconditional `std::os::unix::fs::PermissionsExt`** — `PermissionsExt` is a Unix-only trait that doesn't compile on Windows.

   **Fix:** Wrapped in `#[cfg(unix)]` block; Windows returns a placeholder string `"----------"`.

3. **`unlock_and_mount_encrypted()` uses `std::os::unix::fs::PermissionsExt`** — same Windows issue. Also references `/dev/shm` (Linux tmpfs, doesn't exist on macOS/Windows) and `udisksctl` (Linux-only D-Bus client).

   **Fix:** Gated the entire implementation to `#[cfg(target_os = "linux")]`; other platforms return an appropriate error message.

4. **`parse_mounts()`, `is_usb_device()`, `is_rotational()`, `get_volume_label()`, `classify_drive()`, `lsblk_unmounted_all()`, `collect_drives_with_unmounted()`** — all read `/proc/mounts`, `/sys/block`, or call `lsblk` and `udisksctl`, which are Linux-only.

   **Fix:** Each function gated with `#[cfg(target_os = "linux")]`. New `get_drives_platform()` dispatcher calls the Linux block, provides a `/Volumes`-based implementation on macOS, and returns an empty `Vec` on Windows.

5. **`mount_drive()` and `eject_drive()`** — both call `udisksctl` (Linux only). eject_drive also calls `umount`.

   **Fix:** `mount_drive()` gated to Linux. `eject_drive()` has a Linux path (udisksctl/umount) and a macOS path (`diskutil unmount`).

6. **`open_file()` hardcoded `xdg-open`** — Linux-only; macOS has `open`, Windows has `cmd /c start`.

   **Fix:** Three-way `#[cfg]` dispatch.

7. **`open_terminal()` Linux-only terminal list** — no macOS Terminal.app or Windows wt.exe / cmd.exe fallbacks.

   **Fix:** macOS uses AppleScript to open Terminal.app; Windows tries Windows Terminal then cmd.exe; Linux keeps existing emulator list.

8. **`open_in_editor()` uses `which` (not available on Windows in PATH by default)** — no macOS or Windows editor paths.

   **Fix:** macOS falls through to `open_file()`; Windows tries `notepad.exe` as guaranteed fallback.

9. **`open_as_root()` uses `pkexec`** — Linux-only privilege escalation.

   **Fix:** Gated to `#[cfg(target_os = "linux")]`; returns informative error on other platforms.

10. **`list_apps_for_file()` scans Linux `.desktop` directories** — no `.desktop` system on macOS/Windows.

    **Fix:** Returns empty list immediately on non-Linux; the "Open With…" dialog will show nothing on those platforms (correct behavior until native app enumeration is implemented).

11. **WebKit2GTK / GStreamer env vars in `main()`** — These vars are WebKit2GTK-specific (Linux). Silently ignored on macOS (WKWebView) and Windows (WebView2) but cluttered the startup.

    **Fix:** Wrapped in `#[cfg(target_os = "linux")]`.

12. **Hot-plug watcher in `setup()`** — polls `/proc/mounts` and `/sys/block` (Linux-only paths).

    **Fix:** Wrapped in `#[cfg(target_os = "linux")]`; watcher simply doesn't start on macOS/Windows.

### Fix — `Cargo.toml` version and rust-version

- **`rust-version = "1.60"`** was incorrect: `OnceLock` (used in `main.rs`) was not stabilized until Rust 1.70. Builds on Rust 1.60–1.69 would fail with a "use of unstable library feature" error. Updated to `rust-version = "1.70"`.
- **`version = "0.1.0"`** was stale; updated to `"4.0.33"` to match `tauri.conf.json`.
- **`notify = { version = "6", features = ["macos_fsevent"] }`** listed `macos_fsevent` unconditionally, which causes a compile warning on Linux and fails on targets without FSEvents. Moved to a `[target.'cfg(target_os = "macos")'.dependencies]` block.

### Fix — Column view glitch: arrow key selection not scrolling into view (`src/views.js`)

**Root cause:** `_patchEntries()` has two fast-path exits — a *pre-sort* check (count + boundary names identical) and a *post-sort* check (sorted boundary paths identical). Both correctly sync `.sel`/`.cut-item`/tag-tint classes on visible rows, but **neither scrolled the column to bring the newly selected row into view**. The `newSelIdx` parameter passed in from `renderColumnView` was completely ignored in both fast-path branches.

**Symptom:** Pressing ↑/↓ arrow keys in column view showed the highlight moving (`.sel` class toggling) but the column viewport never scrolled. After ~10 key presses the selected row disappeared off-screen and appeared frozen.

**Fix:** Added the same viewport-scroll guard used in the full update path to both fast-path returns. If `newSelIdx` is outside the current visible window, the column scrolls to center it and forces a `_paintColList()` repaint to render the newly visible rows. The guard is a no-op when the row is already on-screen (no unnecessary scroll jitter).

---

### Fix — `PACK.sh` path bugs and macOS compatibility

1. **`VERSION_FILE` and `OUT_DIR` used `$(dirname "$SCRIPT_DIR")`** which resolved to the *parent* of the project root — placing `VERSION` and `releases/` outside the project tree entirely. Fixed to `"$SCRIPT_DIR/VERSION"` and `"$SCRIPT_DIR/releases"`.

2. **`sed -i "s/..."` fails on macOS** — GNU sed accepts `-i` without a backup extension; BSD sed (macOS) requires `-i ''`. Added `_sedi()` helper that auto-detects GNU vs BSD sed and invokes the correct form.

3. **`frostfinder-hyprland.conf` unconditionally listed in `zip`** — if the file doesn't exist, zip emits a warning that confuses build scripts. Changed to only include it when the file exists: `[ -f "frostfinder-hyprland.conf" ] && OPTIONAL_FILES+=("frostfinder-hyprland.conf")`.

4. **`VERSION` file not included in zip** — the script writes a `VERSION` file but never packed it, so the next `./PACK.sh` run couldn't read defaults from the previous build. Added `VERSION` to the zip include list.

5. **`releases/` and `dist/` not excluded from zip** — iterative packing could inadvertently include old releases and the Vite build output. Added `--exclude "*/releases/*"` and `--exclude "*/dist/*"`.

---


## What's in Beta-4-r32

**No Rust recompile required.** Change in `src/main.js` only.

### Fix — JS-side directory listing cache: zero-IPC revisits (`src/main.js`)

**Diagnosis from `frostfinder-debug-1773497977694.log`:**

The r31 Rust cache was working correctly — seq=8 BETA1 revisit returned all 142 entries in the first chunk (no partial column). But cache hit navigation was still 18–21ms. The Rust cache eliminated filesystem reads but not the IPC round-trip.

**Root cause — Tauri WebKit IPC overhead is ~15ms minimum:**

A cache hit in Rust still requires two IPC crossings:
1. JS `invoke()` → Tauri dispatches to Rust → ~5–7ms
2. Rust `window.emit()` → Tauri sends to JS → ~5–7ms

These are hard costs of the Tauri/WebKit bridge, independent of payload size or compute. There is nothing the Rust side can do to eliminate them — the wire is the bottleneck.

**Fix — JS-side LRU cache (`_JS_DIR_CACHE`), 30 paths, Map + deque:**

`navigate()` checks a JS `Map<path, FileEntryFast[]>` before calling `_streamDir`. On a cache hit:
1. Render the column immediately from memory (~1ms)
2. Fire a background `_streamDir` call (fire-and-forget, not awaited)
3. If the background call finds the listing changed, update cache and re-render

The background validation ensures stale data is never shown longer than one navigation cycle. In practice, the watcher already evicts `_jsCacheEvict(path)` the moment `dir-changed` fires, so the background check will almost never find a discrepancy.

**Cache invalidation:**
- `dir-changed` watcher event: `_jsCacheEvict(changedPath)` before `refreshColumns()`
- Navigate to new path (cache miss): background validate + `_jsCacheSet(path, result.entries)` on resolve

**Result:**

| Navigation | r31 (Rust cache) | r32 (JS cache) |
|---|---|---|
| First visit (cold) | ~20ms | ~20ms (unavoidable FS + IPC) |
| Revisit (warm) | ~20ms (IPC still runs) | ~3ms (zero IPC) |
| BETA1 142-file revisit | 20ms | ~3ms |
| claude-miller 74-file revisit | 18ms | ~3ms |

**The two caches work in tandem:**
- **JS cache** → instant revisit navigation (zero IPC)
- **Rust cache** → fast `refreshColumns` IPC calls from watcher path

---

## What's in Beta-4-r31

**Rust recompile required.** Change in `src-tauri/src/main.rs` only.

### Fix — Rust-side directory listing LRU cache (`src-tauri/src/main.rs`)

**Diagnosis from `frostfinder-debug-1773497071535.log`:**

All previous fixes worked as expected:
- Watcher fires: eliminated (zero spurious renders in log)
- BETA1 (142 entries): 64ms → 15ms ✔ (toolbar cache fixed this)
- Music first visit: 62ms (unavoidable — cold page cache)

But Music revisits remain 38–42ms despite toolbar cache, because the bottleneck was never JS — it was the Rust filesystem read itself.

**Root cause — repeated filesystem reads with lstat() overhead:**

`list_directory_streamed` re-reads the full directory from the filesystem on every navigation, even for a folder visited 30 seconds ago. On `/home/jay/Music` (542 entries), the OS returns `DT_UNKNOWN` for `d_type` in the dirent buffer, forcing `entry.file_type()` to call `lstat()` — one syscall per entry.

```
482 remaining entries × ~60μs per lstat() = ~29ms
```

This matches the measured `chunk→resolved` gap of 28–30ms exactly. It's a filesystem-level cost: there is no way to make individual `lstat()` calls faster.

The user navigated Music→Pictures→Music→Pictures→Music four times. Each revisit paid the full 29ms again. That's ~120ms of total wasted time reading data that hadn't changed at all.

**Fix — LRU directory listing cache:**

`DirCache` is a bounded LRU cache (`max=30 entries`) backed by `HashMap<String, Vec<FileEntryFast>>` with a `VecDeque<String>` for eviction ordering.

`list_directory_streamed` checks the cache first:

- **Cache hit:** Emit all entries in a single `done:true` message directly from memory. No filesystem reads, no `lstat()` calls, no `spawn_blocking`. Both the first-chunk and final emits collapse into one — JS receives the full listing immediately, eliminating the partial-column flash (the 60-entry column that briefly appears before expanding to 542). Total time: ~6ms (one IPC call).

- **Cache miss:** Read from filesystem as before (two-emit streaming). After the final emit, `cache_insert()` stores the `Vec<FileEntryFast>` for future hits.

**Cache invalidation:** The inotify watcher already calls `cache_evict(path)` whenever `Create`, `Remove`, or `Modify(Name)` fires for the watched directory. This ensures stale data is never served after a file is added, deleted, or renamed.

**Results:**
| Navigation | Before | After |
|---|---|---|
| Music first visit | 42ms | 42ms (unavoidable FS read) |
| Music every revisit | 42ms | ~6ms |
| BETA1 first visit | 18ms | 18ms |
| BETA1 every revisit | 18ms | ~6ms |
| Partial-column flash | always | only on first visit |

---

## What's in Beta-4-r30

**No Rust recompile required.** Change in `src/main.js` only.

### Fix — `renderToolbar()` rebuilding full innerHTML on every render, blocking IPC queue (`src/main.js`)

**Diagnosis from `frostfinder-debug-1773496515338.log`:**

Zero spurious watcher renders in this log — the r27/r28/r29 watcher fixes worked completely. But slow navigations persisted. The pattern was exact: every slow navigation had a `RENDER` event fired between `NAV_FIRST_CHUNK` and `NAV_RESOLVED`, and the `chunk→resolved` gap was 27–45ms.

This is the streaming architecture working as designed — the first-chunk render is intentional. The problem is what that render *does*:

```
NAV_FIRST_CHUNK fires → navigate() calls render()
  render() → _doRender()
    → renderToolbar()   ← THE PROBLEM
       document.getElementById('toolbar').innerHTML = '...(huge string)...'
       Full breadcrumb rebuild, all buttons, view switcher, search input
       ~15–20ms of JS main thread work
    → renderView() (fast, _patchEntries)
    → renderPreview(), renderStatus()

Meanwhile: Rust finishes reading remaining entries, calls window.emit('dir-chunk', done:true)
  → IPC message queued in WebKit event loop
  → Can't be processed until JS main thread is free
  → JS is busy with renderToolbar()
  → done:true waits 15–20ms in the queue

JS finishes render → processes IPC queue → NAV_RESOLVED fires
```

The `chunk→resolved` gap shown in the log **is not Rust IO time** — it is entirely JS main thread blockage from `renderToolbar()`.

**Why renderToolbar was rebuilding unnecessarily:**

During a streaming navigation, the second render (first-chunk) and any subsequent renders before the user does anything have **identical toolbar state**: same path, same `loading=false`, same view mode, same history index, same everything. There is no reason to rebuild the toolbar at all.

**Fix — toolbar state fingerprint cache:**

`_toolbarFp()` computes a cheap string key from all toolbar-relevant state fields: `currentPath`, `historyIdx`, `history.length`, `loading`, `viewMode`, `showHidden`, `searchMode`, `searchQuery`, `search`, `_bcEditMode`.

`renderToolbar()` checks the fingerprint at the top. If it matches the last build, it returns immediately after updating only the spinner element in-place (the one thing that can change independently of the full rebuild). The `innerHTML` rebuild only runs when the fingerprint changes — i.e. when the user actually navigates, changes view mode, toggles hidden files, etc.

Cache is invalidated explicitly on tab switch (state changes completely) and sort order change (view mode buttons need to reflect new state).

**Result:** The first-chunk render now costs ~1ms instead of ~15–20ms. The `done:true` IPC message is processed within 1–2ms of Rust emitting it instead of waiting in queue. `chunk→resolved` gap drops from 27–45ms to ~5ms (pure Rust IO + one IPC call). Music navigation: 40–67ms → ~20ms.

---

## What's in Beta-4-r29

**No Rust recompile required.** Changes in `src/main.js` and `src/views.js`.

### Fix — watcher-triggered renders still causing UI hitches (`src/main.js`, `src/views.js`)

**Diagnosis from `frostfinder-debug-1773495357769.log`:**

The r27+r28 fixes reduced watcher fires from 1.7/s to 0.14/s (12× less frequent). But each remaining fire still triggered a full `render()` cycle:
- `syncState()` — walks all tab state
- `renderToolbar()` — full innerHTML rebuild of the toolbar
- `renderColumnView()` — `_patchEntries` on every column
- `renderPreview()`, `renderStatus()`

The r28 fingerprint check inside `_patchEntries` correctly identified unchanged directories in <0.1ms, but `refreshColumns` called `render()` unconditionally *after* running the patcher — so the full toolbar/preview/status rebuild happened anyway, for zero visible result.

**Three fixes:**

**1. `_patchEntries` now returns a signal (`src/views.js`)**

Both fast-path exit points (pre-sort fingerprint match, post-sort boundary match) now `return false` instead of bare `return`. The full-update path returns `undefined` (truthy in the `!== false` check). This gives the caller a cheap way to know whether the column listing actually changed.

**2. `refreshColumns` skips `render()` when nothing changed (`src/main.js`)**

`refreshColumns` now calls `_patchEntries` directly on the live DOM column element and collects the return values. If every column returns `false` (fingerprint matched — no listing change), `render()` is not called at all. The sel/cut-item/tag-tint sync that `_patchEntries` already performed is sufficient — the toolbar, tabs, preview panel, and status bar are already correct and don’t need rebuilding.

For file-operation callers (`changedPath=null`) that change the actual listing, `anyChanged` becomes `true` and `render()` fires normally.

**3. `dir-changed` handler watches all open columns, not just `currentPath` (`src/main.js`)**

Previously the handler only called `refreshColumns` when `changedPath === state.currentPath`. This missed cases where a *parent* column’s directory changed while a subfolder was open (e.g. a file was added to Downloads while Downloads/claude-miller was the deepest open column). Fixed to check all open columns.

**Net result:** A watcher fire for an unchanged directory now costs: 1 IPC call (~5ms) + fingerprint compare (~0.1ms) + sel sync (~0.1ms) = ~5ms total, with **zero `render()` call**. The toolbar, tabs, and preview panel are untouched. The app stays fully interactive.

---

## What's in Beta-4-r28

**No Rust recompile required.** Changes in `src/main.js` and `src/views.js`.

### Fix — Downloads/Music/large-folder freeze: `sortEntries` running on every watcher fire (`src/main.js`, `src/views.js`)

**Diagnosis from `frostfinder-debug-1773494131718.log`:**

Navigation to every folder was fast (7–35ms). The freeze was not during navigation. The log showed **13 watcher-triggered `RENDER` calls in 7.7 seconds** while the user was idle in Music (×2 columns, 542 entries). These renders happened at ~1.5/s — the inotify watcher was firing for Music metadata updates (album art, thumbnails, media player atime writes).

Each watcher fire called `_patchEntries` for **all open columns**. `_patchEntries` called `sortEntries()` **before** the fast-path check. The fast-path (skip DOM work if entries unchanged) was correct — but the expensive sort had already run before it could fire.

Root cause: `sortEntries` used `localeCompare(b.name, undefined, {sensitivity:'base'})`. This invokes the ICU Unicode collation library on every comparison. On Linux with glibc ICU, each call takes ~0.05ms. Sorting 542 Music entries requires ~4,900 comparisons: `542 × log2(542) × 0.05ms ≈ 250ms per sort`. With 13 watcher fires: **~3.25 seconds of blocked JS main thread in an 8-second window = 42% of the time the app was unresponsive**.

This affected any folder that received watcher events while large directories were open in other columns — not just Downloads. The user also saw it in Music and claude-miller because those columns stayed open while the watcher fired.

---

### Fix 1 — Pre-sort fingerprint fast-path in `_patchEntries` (`src/views.js`)

**Root cause:** `sortEntries()` ran unconditionally at the top of `_patchEntries`, before any check for whether the directory had actually changed. The fast-path check (comparing sorted first/last entry paths) only fired *after* the sort had already run — too late to save the CPU.

**Fix:** Added a **pre-sort fingerprint** stored per-column at build time: `count + '|' + first_raw_name + '|' + last_raw_name`. On each `_patchEntries` call, this fingerprint is computed from the new raw (unsorted) entries in O(1) and compared to the stored value **before** calling `sortEntries`.

If the fingerprint matches, the directory listing hasn't changed — no sort, no DOM eviction, no repaint. Only visible `.frow` elements are walked to sync `.sel`/`.cut-item`/tag-tint classes (~0.1ms regardless of directory size).

**Cost reduction:**
- Unchanged dir (common case — watcher fires for metadata/atime): `250ms → 0.1ms` (×2500 faster)
- Changed dir (file added/removed/renamed): sort still runs, ~5–10ms with new algorithm

**Edge case:** A rename of a middle file (not alphabetically first or last) won't change the fingerprint's first/last names. The post-sort identical check (comparing sorted first/last paths) catches this case.

---

### Fix 2 — Faster sort algorithm in `sortEntries` (`src/main.js`)

**Root cause:** `localeCompare(b.name, undefined, {sensitivity:'base'})` is called O(n log n) times during a sort. Each call invokes ICU Unicode collation which is 50–100× slower than a plain string comparison for typical filenames.

**Fix:** Schwartzian transform for name sort:
1. Pre-compute `name.toLowerCase()` once per entry — O(n) `toLowerCase()` calls
2. Sort using plain `<`/`>` string comparison — O(n log n) fast native ops, no ICU

```js
const keyed = entries.map(e => ({ e, k: e.name.toLowerCase() }));
keyed.sort((a, b) => dir * (a.k < b.k ? -1 : a.k > b.k ? 1 : 0));
return keyed.map(x => x.e);
```

**Performance:** 542 entries: `~250ms → ~5ms` (×50 faster). This benefits every initial column build and every case where a directory change is detected.

Size/date/type sort columns are unchanged (they use their own comparison logic).

---

## What's in Beta-4-r27

**Rust recompile required.** Change in `src-tauri/src/main.rs` only.

### Fix — Downloads folder slowdown: root cause corrected in watcher event filter (`src-tauri/src/main.rs`)

**Root cause — `Modify(_)` wildcard in watch_dir caught all Modify subtypes:**

The watcher's match arm was:
```rust
Create(_) | Modify(_) | Remove(_) | Other => { /* temp-extension filter... */ }
```

`Modify(_)` matches every `ModifyKind` variant in notify v6:
- `ModifyKind::Data` — file content written (every write to a file)
- `ModifyKind::Metadata` — permissions, timestamps
- `ModifyKind::Name` — rename/move
- `ModifyKind::Other` / `ModifyKind::Any`

When a browser writes to a `.crdownload` file during an active download, the OS fires `Modify(Data(...))` on every write. The event paths contain only the `.crdownload` file, so the downstream `all()` temp-extension filter correctly dropped those — **but only if the extension matched the filter list**.

Two problems remained:
1. The temp-extension filter is a brittle workaround. It required maintaining a list of known browser temp-file extensions and could always be bypassed by an unexpected extension or a lock file written alongside the download.
2. Even with the filter, the event still reached the channel send, the channel buffer, the debounce thread's `recv()`, and the drain loop before being discarded downstream — wasted CPU on every write event, and any write where the path didn't match the extension filter (e.g. a `.tmp2` file, a lock file with no extension, a file whose name starts with `.` and has no extension) would pass through and trigger a full `refreshColumns()` → IPC → DOM cycle.

**Root cause identified:** The Downloads slowdown has always been caused by `Modify(Data)` events — file content writes — reaching the channel. A content write never changes the directory listing (no files are added, removed, or renamed), so refreshing the column on Modify(Data) is always wrong, regardless of what filename triggered it.

**Fix — match only events that actually change the directory listing:**

```rust
let should_emit = match event.kind {
    Create(_) | Remove(_) => true,
    Modify(ModifyKind::Name(_)) => true,   // rename/move — listing changed
    Modify(_) => false,                     // content writes — listing unchanged
    _ => false,
};
```

The temp-extension filter and the `any()`/`all()` debate are now irrelevant — `Modify(Data)` events never reach the channel at all.

**Correctness:** Download completing (`.crdownload` → `.mp4` rename) fires `Modify(Name(_))` → passes through → `dir-changed` fires → column refreshes showing the new file. ✓ Active download writes fire `Modify(Data)` → dropped immediately → zero channel traffic → zero refreshes during the download. ✓

---

## What's in Beta-4-r26


**No Rust recompile required.** Changes in `src/views.js` and `src/main.js`.

### Fix — Column view selection/highlight invisible after click (`src/views.js`)

**Root cause — `_patchEntries` fast-path returned with no DOM update:**

The r19 incremental reconciliation added a fast-path inside `_patchEntries`: when the directory entries haven't changed (same count, same first and last path), the function returned immediately with zero DOM work. This was correct for the `refreshColumns` case (watcher fires, nothing changed → skip).

However, `_patchEntries` is also called from every `render()` triggered by a click. When the user clicks row `ei=5`:
1. `sel.set(5)` adds the path to `sel._paths` ✓
2. `render()` fires → `renderColumnView()` → `_patchEntries(col.entries, 5)`
3. Entries are identical (nothing was added/deleted) → **fast-path fires → `return` immediately**
4. The `.sel` class is never added to row 5 → row stays visually unselected

The user saw their selection not appearing no matter how many times they clicked. Since this applied to every click in every open column, the entire column view felt broken — "widespread glitching" and "select not working" were the same root cause.

**Fix:** In the fast-path branch, before returning, walk every currently rendered `.frow` and sync three visual properties that can change without entries changing:
- `.sel` class — selection highlight
- `.cut-item` class — dimming for cut files
- `background` style — tag color tint

This costs ~0.3ms per call (toggling classList on ~30 rows) and is completely invisible to the user. The DOM stays correct through every click, keyboard navigation, Ctrl+C/X, and tag operation.

---

### Fix — `attachDragSelect` leaked `document` listeners on every column navigation (`src/views.js`)

**Root cause:**

`attachDragSelect` registers two document-level event listeners per column:
```js
document.addEventListener('mousemove', onMove, { passive: false });
document.addEventListener('mouseup',   onUp);
```

When the incremental reconciler removes a stale column element, the `colList` DOM node is detached — its own `.mousedown` listener disappears with it. But the two `document` listeners captured in the closure were **never removed**. They accumulated silently across every directory navigation.

After navigating through 15 folders in column view: 15 `mousemove` + 15 `mouseup` handlers active on `document`. Every mouse movement fired all 15 `onMove` callbacks. Each checks `if (!armed && !active) return` immediately (cheap), but 15 checks per event × 60fps mouse input = 900 extra callback invocations per second of mouse movement. On slower hardware this contributed to the reported sluggishness.

More importantly: stale `onMove` callbacks from dead columns still held references to `armed` and `active` from their original closure. A stale `active=true` surviving from a previous drag-select session could cause phantom selection state to appear in a new column.

**Fix:** A `MutationObserver` watches `document.body` for subtree changes. When `colList.isConnected` becomes `false` (column removed by reconciler), the observer removes both document listeners and disconnects itself. Zero leakage regardless of how many directories the user navigates through.

---

### Fix — `refreshColumns` had no re-entrancy guard for watcher events (`src/main.js`)

**Root cause:**

`refreshColumns(changedPath)` is called from the `dir-changed` event listener every time the filesystem watcher fires. `refreshColumns` is `async` — it `await`s a `listDirectory` IPC call. If `dir-changed` fires a second time while the first call is still awaiting the IPC response, a second `refreshColumns` starts concurrently. Both then call `render()` independently when they complete, producing two rapid repaints in close succession.

In a busy Downloads folder where the Rust watcher debounce was partially filtering events but still passing through rename completions at irregular intervals, this caused visible column thrashing — rows being evicted and recreated twice in quick succession, producing a flash.

**Fix:** Added `_watcherRefreshPending` flag (module-level boolean). When `refreshColumns` is called with a `changedPath` (watcher origin) and the flag is set, the call returns immediately — the in-flight refresh will render the latest state anyway. The flag is cleared in a `finally` block so a failed IPC call can't permanently lock out future refreshes. File-operation callers (`changedPath = null`) bypass the guard and always run.

---

## What's in Beta-4-r25


**No Rust recompile required.** Changes in `PACK.sh`, `src-tauri/tauri.conf.json`, and `src-tauri/icons/`.

### Fix — App icon updated to official FrostFinder branding (`src-tauri/icons/`)

**Change:** All Tauri icon assets replaced with the official FrostFinder icon (yeti mascot holding magnifying glass on winter snowy background).

Updated files:
- `src-tauri/icons/32x32.png` — 32×32 toolbar/taskbar icon
- `src-tauri/icons/128x128.png` — 128×128 standard icon
- `src-tauri/icons/128x128@2x.png` — 256×256 HiDPI icon
- `src-tauri/icons/icon.ico` — Windows multi-resolution ICO (16/32/48/64/128/256px)
- `src-tauri/icons/icon.icns` — macOS ICNS icon bundle

---

### Fix — `PACK.sh` zip command referenced non-existent `BUILD.sh` (`PACK.sh`)

**Root cause:** The zip include list in `PACK.sh` listed `BUILD.sh` as a file to bundle. No such file exists in the project tree — only `PACK.sh` exists. On every pack run, `zip` would warn about a missing file and the packager script itself was absent from the output archive.

**Fix:** Replaced `BUILD.sh` with `PACK.sh` in the zip include list so the packager script is correctly bundled in every release archive.

---

### Fix — `PACK.sh` zip command missing `ql.html` (`PACK.sh`)

**Root cause:** `ql.html` — the Quick Look native window HTML entry point — was not listed in the `zip -r` include list inside `PACK.sh`. Every release archive produced by `PACK.sh` was missing this file. Any recipient building from the archive would get a broken Quick Look window (blank content, no `ql-ready` event ever firing), exactly the regression that was root-caused and fixed in r42/r43 of Beta-3. The file had to be added manually each time.

**Fix:** Added `ql.html \` to the zip include list immediately after `index.html`. It will now be included automatically on every `./PACK.sh` run.

---

### Fix — `tauri.conf.json` version string stale at `4.0.1` (`src-tauri/tauri.conf.json`)

**Root cause:** The `package.version` field in `tauri.conf.json` was never updated from the initial Beta-4-r1 value of `4.0.1`. The bundle version embedded in the compiled binary and shown in system package managers remained `4.0.1` through r2–r24, regardless of the actual revision.

**Fix:** Updated `"version"` to `"4.0.25"` matching this revision.

---

## What's in Beta-4-r24

**No Rust recompile required.** Changes in `src/views.js` and `src/main.js`.

### Fix — Music column shows unsorted entries (`src/views.js`)

**Root cause — deferred sort invalidated by `refreshColumns()`:** The r23 deferred sort (`requestIdleCallback` for >300 entries) was broken by a two-part interaction. First, `listDirectory` returns entries in filesystem order (unsorted). The deferred sort would fire, sort `entries`, and update the closure reference. But `refreshColumns()` — triggered by `dir-changed` watcher events — calls `_patchEntries` with a fresh unsorted batch from IPC, overwriting `entries` with the new unsorted array before the next user interaction. The idle sort fires again, sorts, and the cycle repeats: watcher event → unsorted → sort → watcher event → unsorted → sort. Because `dir-changed` fires every 5–10 seconds while Music is open (observed in the debug log at +5.0s, +23.0s, +32.8s, +50.5s), the column is almost never sorted for more than a few seconds.

**Root cause — fast-path check comparing sorted vs unsorted:** The no-op fast-path added in r23 checked `pEntries[0].path === entries[0].path` before sorting `pEntries`. `pEntries` arrives in unsorted filesystem order from IPC; `entries` is sorted alphabetically. These virtually never match, so the fast-path always missed and always triggered a full repaint even when the directory hadn't changed.

**Fix:** Sort `pEntries` synchronously and unconditionally, *before* the fast-path check. Sorting 893 JS strings takes ~1ms — not a bottleneck. The fast-path boundary check now compares sorted-vs-sorted and correctly identifies unchanged directories. The deferred `requestIdleCallback` sort is removed entirely.

---

### Fix — Downloads folder slowdown: `refreshColumns()` re-lists all open columns on every watcher event (`src/main.js`)

**Root cause:** `refreshColumns()` was called with no arguments from the `dir-changed` handler. It always re-listed every open column with `Promise.all(state.columns.map(...))`. With 2 open columns (e.g. `/home/jay` and `/home/jay/Downloads`), each watcher event triggered 2 IPC calls — even though only Downloads changed. With an active browser download in Downloads (watcher firing every 300ms), this was ~7 IPC calls/second for directories that hadn't changed, each taking 5–10ms.

**Fix:** `refreshColumns(changedPath)` now accepts an optional `changedPath`. When provided, only the column whose path matches `changedPath` is re-listed. The `dir-changed` handler passes `changedPath` so only the single watched directory is re-fetched. File operation callers (drag-drop, paste, delete, rename, etc.) call `refreshColumns()` with no argument and still refresh all open columns, which is correct for those cases.

---

## What's in Beta-4-r23

**No Rust recompile required.** Changes in `src/views.js` only.

### Fix — Music folder glitch: `_patchEntries` paints before updating `scrollTop` (`src/views.js`)

**Root cause:** `_patchEntries` called `_paintColList()` first, then updated `colList.scrollTop`. Each painted row is `position:absolute` at a fixed `top` computed from its index. After the paint, changing `scrollTop` immediately scrolls those rows off-screen. The async `scroll` event listener fires `_paintColList()` in a later microtask, but the browser gets to composite one frame first — a frame where the visible area contains no rows at all. That one-frame blank is the visible glitch on every Music patch render (first-chunk 60 entries → full 893 entries).

**Fix:** Scroll position is now updated *before* evicting rows and calling `_paintColList()`. `_paintColList()` reads `colList.scrollTop` at the moment it runs, so painting with the final scroll position means painted rows are immediately at the correct location. Zero-frame gap, zero flash.

---

### Fix — Downloads slowdown: `_patchEntries` blocks the main thread sorting large directories (`src/views.js`)

**Root cause:** `sortEntries(pEntries)` ran synchronously on the full entry list every time `_patchEntries` was called — including on every `refreshColumns()` triggered by a `dir-changed` watcher event. For a large Downloads folder (2000+ entries), this sort takes 15–40ms on the main thread, causing a visible stall each time the watcher fires. The `dir-changed` watcher fires whenever a file is created, renamed, or modified in the watched directory; an active browser download triggers this repeatedly.

**Fix — deferred sort for large directories:** Entries with ≤ 300 items are still sorted synchronously (fast path, no behaviour change for typical small folders). For lists over 300 entries: the unsorted list is rendered immediately so the column is interactive at once, then `requestIdleCallback` runs the full sort and does one quiet re-render when the browser is idle. First paint is instantaneous regardless of directory size.

---

### Fix — Downloads slowdown: `_patchEntries` evicts and repaints all rows even when entries are unchanged (`src/views.js`)

**Root cause:** Every `refreshColumns()` call — which fires on every `dir-changed` watcher event — updated `col.entries` and then called `_patchEntries`. Inside `_patchEntries`, there was no check for whether the entries actually changed. All visible rows were unconditionally evicted and recreated even when the directory listing was byte-for-byte identical to the last fetch. With the watcher firing every few seconds (active downloads, downloads completing), this caused continuous DOM churn: evict ~20 rows × 3 columns = ~60 DOM node deletions and ~60 re-creations every watcher event, with no visible change to the user.

**Fix — no-op fast path:** At the start of `_patchEntries`, before any DOM work, the new entry list is compared against the current list by length and boundary paths (first + last entry path). If identical, `_patchEntries` returns immediately — no eviction, no repaint, no spacer update. The `sel._e` reference is refreshed (zero cost). For the common case where `refreshColumns()` re-fetches an unchanged directory, the column view is now completely static.

---

## What's in Beta-4-r22

**No Rust recompile required** for the JS fixes. **Rust recompile required** for the watcher fix (`src-tauri/src/main.rs`).

### Fix — Music folder glitch: `attachDragSelect` holding stale first-chunk entries array (`src/views.js`)

**Root cause:** `attachDragSelect(colList, entries, ...)` was called with `entries` passed **by value** at column build time — at that point the array holds only the first 60 streamed entries. When `_patchEntries` subsequently runs and reassigns `entries = pEntries` (all 893 entries), the column's closure variable updates correctly, but `attachDragSelect`'s internal `entries` binding still pointed at the original 60-item array.

After the patch render, `applyRange()`, `syncClasses()`, and `activate()` inside `attachDragSelect` all read from the stale 60-item array. Rows 60–892 were invisible to drag-select: `entries[i]` returned `undefined` for any index ≥ 60, paths were never added to `sel._paths`, and `.sel` class toggling silently did nothing for those rows. The visible symptom was partial selection state — some rows appeared selected but the actual selection didn't match — and occasional flash as a stale render invalidated a row that `syncClasses` thought was unselected.

The rubber-band `onDone` callback captured `entries` the same way and had the same issue.

**Fix:** Changed `attachDragSelect` to accept `getEntries` (a `() => entries` getter closure) instead of the array directly. Every internal callback (`applyRange`, `syncClasses`, `activate`, rubber-band `onDone`) now calls `getEntries()` at invocation time to read the live array. The call site passes `() => entries` so the getter always resolves to whatever `entries` currently points to after any `_patchEntries` reassignment.

---

### Fix — Music folder glitch: `selIdx` out-of-bounds scroll during `_patchEntries` (`src/views.js`)

**Root cause:** If `col.selIdx` was set to a value ≥ 60 (e.g. from a previous navigation that remembered a deep selection) when the first-chunk render fires, `_patchEntries` computed the scroll target as `selIdx × 28px`. With only 60 entries in the first chunk, the spacer height was `60 × 28 = 1680px`. A `selIdx` of 400 produced a scroll target of `11200px` — far past the current spacer bottom — causing the list to snap to the maximum scroll position and then jump again when the spacer expanded to `25004px` on the final patch.

**Fix:** Added a clamp guard in `_patchEntries` before the scroll block: `if (newSelIdx >= entries.length) newSelIdx = -1`. If the selection index is out of range for the current (possibly partial) entry list, the scroll-to-selected is simply skipped for this patch, and the user's scroll position is left undisturbed.

---

### Fix — Downloads folder: watcher swallows download-completion rename events (`src-tauri/src/main.rs`)

**Root cause:** The temp-file extension filter used `any()`: if **any** path in a filesystem event had a temp extension, the entire event was dropped. A browser download completing is implemented by the OS as a rename from `file.mp4.crdownload` → `file.mp4`. The inotify `Rename` event carries **both** paths: the old `.crdownload` path and the new `.mp4` path. Because the old path matched the temp-extension filter, `any()` dropped the event entirely — the Downloads folder never refreshed when a download finished, only when the user navigated away and back.

**Fix:** Changed `any()` to `all()` with an additional `!event.paths.is_empty()` guard. Events are now only suppressed when **every** affected path is a temp-extension file. Active-download write bursts (where all paths are `.crdownload`) are still filtered out. Rename completions (one `.crdownload` path + one real path) now pass through and trigger a `refreshColumns()` as expected.

---

## What's in Beta-4-r21

**Rust recompile required.** Changes in `src/views.js` and `src-tauri/src/main.rs`.

### Fix — Music folder glitch: container-level event listeners stacking across renders (`src/views.js`)

**Root cause:** `container.addEventListener('contextmenu', ...)` and `container.addEventListener('mousedown', ...)` were appended inside `renderColumnView` after the `forEach`. With incremental reconciliation, `container` (`#cols`) is the same DOM element across renders — it is only created once and reused. Every render call added new listeners without removing old ones. After the first-chunk render and the patch render, there were 2 contextmenu handlers and 2 mousedown handlers. After 10 navigations, 10 of each. Every right-click fired every contextmenu handler, calling `render()` and `showContextMenu()` multiple times simultaneously. The second call to `showContextMenu` on the same event produced the visible glitch (duplicate menus, double renders, content flash).

**Fix:** Added a `container._listenersAttached` sentinel. The two container-level listeners are registered only on the first render. Subsequent renders skip them. The listener callbacks call `d()` at event time (not capture time) to read current state — same pattern used by event delegation elsewhere.

---

### Fix — Scroll-to-rightmost-column firing on patch renders (`src/views.js`)

**Root cause:** `requestAnimationFrame(()=>{ w.scrollLeft = w.scrollWidth; })` fired at the end of every `renderColumnView` call, including patch renders (when streaming delivers the full 893-entry list after the first-chunk render). If the user had started scrolling left between the two renders, the patch render's rAF snapped them back to the right edge. This was the primary visible "glitch" on the Music folder.

**Fix:** Added `let _newColAppended = false` before the forEach. Set to `true` only in the new-column branch (when `container.appendChild(colEl)` runs). The scroll-right rAF only fires when `_newColAppended` is true — that is, when at least one column was newly built rather than patched in-place.

---

### Fix — Active downloads flooding `dir-changed` events (`src-tauri/src/main.rs`)

**Root cause:** The inotify watcher on `~/Downloads` fired on every write to any file in the directory. Browsers write `.part`, `.crdownload`, and `.tmp` files continuously while downloading — each write triggered a notify event. Although the 300ms debounce coalesced bursts, a download in progress produced a constant stream of debounce-reset events, keeping `tx.send()` firing repeatedly and triggering `refreshColumns()` on the open Downloads folder every ~300ms.

**Fix:** Added an extension filter in the watcher callback. Events where all paths have a temp-download extension (`.part`, `.crdownload`, `.tmp`, `.download`, `.partial`) are dropped before being sent to the debounce channel. The directory listing no longer refreshes during an active browser download. Real filesystem changes (new files, renames, deletions) still propagate normally.

---

## What's in Beta-4-r20

**No Rust recompile needed.** Changes in `src/utils.js` and `src/main.js`.

### Fix — PDF files showed generic icon instead of document icon (`src/utils.js`)

`fileIcon()` called `getIcon('pdf')` but `'pdf'` was not a key in the `I` SVG object. `getIcon` returns `I[key] || I.file`, so the fallback silently produced the generic file icon for all PDF files. Added a `pdf` entry to `I` — a document SVG with an extra horizontal rule to visually distinguish it from the plain `doc` icon.

---

### Fix — Tag colors missing on first load (`src/main.js`)

The global `state` object was missing `_tagColors: {}` and `activeTag: null`. Both fields existed in `makeTabState()` and in `syncState()`'s copy list, but the top-level `state = { ... }` initializer didn't declare them. On first load, before any tab switch (`syncState` → `Object.assign(state, tabState)`), any code reading `state._tagColors?.[tag]` received `undefined`, so tag row tinting and tag color lookups produced no color. Added both fields to the global initializer.

---

### Fix — Stale navigate() called `watch_dir` with the wrong path (`src/main.js`)

When the user clicks a second folder before the first stream finishes, `_streamDir` resolves `null` (stale guard) and `navigate()` returns early from the `try` block. The `finally` block still ran unconditionally and called `invoke('watch_dir', {path})` with the **stale** path — starting an inotify watch on a directory the user never navigated to. The winning navigate's `finally` would overwrite it shortly after, but there was a brief window where filesystem change events from the wrong directory could trigger a `refreshColumns()`. Added `if(mySeq === _navSeq)` guard around the `watch_dir` call in `finally`.

---

## What's in Beta-4-r19

**No Rust recompile needed.** Change in `src/views.js` only.

### Fix — Column view flashes blank when streaming patch arrives (`src/views.js`)

**Root cause:**

`renderColumnView` called `container.innerHTML=''` on every render, tearing down and rebuilding all column DOM elements from scratch. With r17/r18 streaming, two renders fire per navigation:

1. **First-chunk render** — builds the new column with 60 entries, attaches virtual scroller, event listeners, ResizeObserver, drag-select, rubber-band
2. **Patch render** (finally block) — `container.innerHTML=''` wipes everything, rebuilds the same column again with all entries

The wipe between renders is the visible glitch: one frame where the column is completely blank. This also explains why navigating to Music from a different folder (e.g. Pictures → Music) showed a flash — the two renders weren't adjacent, they had a frame gap.

**Fix — Incremental column reconciliation:**

Before building columns, `renderColumnView` now computes which existing `.col` DOM elements can be reused:

- Trims trailing columns whose count exceeds `state.columns.length`
- Trims any column (and everything after it) whose `dataset.colPath` doesn't match the expected path at that position
- For columns that survive the trim: calls `colEl._patchEntries(entries, selIdx)` and returns immediately — no rebuild

Each newly built `.col` element gets:
- `dataset.colPath = col.path` — stable identity key
- `_patchEntries(newEntries, newSelIdx)` — closes over the column's `let entries`, `_colSpacer`, `_cPainted`, `_paintColList`, and `colList`. On call: filters/sorts the new entries, updates `entries` reference in-place, adjusts the spacer height, evicts stale row elements, repaints the visible window, and scrolls to selection if needed

**Result:** The patch render (when 893 entries fill in after the first 60) performs zero DOM teardown. It updates the spacer height from `60×28=1680px` to `893×28=25004px` and calls `_paintColList()` — the virtual scroller fills in the new rows around the scroll position. No flash, no blank frame, no listener re-attachment.

---

## What's in Beta-4-r18

**Rust recompile required.** Change in `src-tauri/src/main.rs` only.

### Perf — Streaming IPC overhead eliminated; column navigation now consistently fast (`src-tauri/src/main.rs`)

**Root cause (confirmed by `frostfinder-debug-1773452292244.log`):**

r17 introduced streaming — the first 60 entries rendered immediately, but total navigation time for large folders got *worse*, not better:

| Folder | Entries | r16 total | r17 total |
|--------|---------|-----------|-----------|
| Music  | 893     | 25ms      | **54ms**  |
| BETA1  | 142     | 5ms       | 14ms      |

The regression came from `window.emit()` IPC overhead. Each `window.emit()` call from inside `spawn_blocking` crosses the Tauri/WebKit IPC boundary, which serializes the payload to JSON and posts it to the WebKit main thread. This costs ~2–3ms per call, independent of payload size. r17 emitted one chunk every 60 entries: 893 ÷ 60 = 15 intermediate emits + 1 final = **16 calls × ~3ms = ~48ms overhead** added on top of the actual ~6ms read time.

**Fix — Two-emit strategy:**

1. **First emit** (`done: false`): fires as soon as the first 60 entries are read. JS renders the column immediately (~11ms). The `spawn_blocking` thread keeps reading while the first chunk is painting.
2. **Final emit** (`done: true`): fires once after all remaining entries are collected in a Rust `Vec`. Carries the rest of the entries + `parent` + `total`. JS patches the full list in silently.

Total IPC calls for any directory: **2** (regardless of size). Expected results:

| Folder | Entries | r18 total |
|--------|---------|-----------|
| Music  | 893     | ~14ms     |
| BETA1  | 142     | ~8ms      |

First paint unchanged (~11ms for large dirs, immediate for small dirs).

The `_streamDir` listener in JS already handles both cases correctly: for dirs ≤ 60 entries, the first emit never fires (Rust skips it), the final emit carries all entries with `done:true`, `onFirstChunk` fires on that single event, then the Promise resolves immediately.

---

## What's in Beta-4-r17

**Rust recompile required.** Changes in `src-tauri/src/main.rs` and `src/main.js`.

### Fix — Column navigation freezes: streaming was sync, JS had no streaming consumer (`src-tauri/src/main.rs`, `src/main.js`)

**Root cause 1 — `list_directory_streamed` was a sync `fn`, blocking the WebKit thread:**

`list_directory_streamed` was designed to emit 60-entry chunks as Tauri events so JS could render incrementally. However, it was declared as a plain `fn` (synchronous). Tauri v1 dispatches sync commands on the WebKit IPC handler thread. While the function looped through 893 entries calling `window.emit()`, the WebKit thread was blocked — emitted events queued up in the IPC channel but could not reach JS until the function returned. Streaming provided zero first-paint benefit; all 893 entries arrived at the same moment as a plain batch call.

**Fix:** Changed to `async fn` with `tauri::async_runtime::spawn_blocking`. The `invoke()` call returns to the WebKit thread immediately. The blocking directory read runs on a Tokio thread pool thread and emits 60-entry chunks. Each chunk flows to JS while the WebKit thread is free, enabling true incremental rendering. `Window` is `Send` in Tauri v1 and can be moved into the `spawn_blocking` closure.

**Root cause 2 — JS `navigate()` never used streaming; called batch `listDirectory` instead:**

Even after the Rust fix, `navigate()` still called `await listDirectory(path)` — a single-shot batch call that awaited the entire directory before touching the DOM.

**Fix:** Added `_streamDir(path, mySeq, onFirstChunk)` — a helper that registers a `dir-chunk` listener (before `invoke()`, to avoid the race where Rust fires `done:true` before the listener registers), then invokes `list_directory_streamed`. The `onFirstChunk(partialEntries)` callback fires when the first ~60 entries arrive, applying nav state and calling `render()` immediately. When `done:true` arrives, the full entry list is patched into the existing column in-place and a final `render()` fires. `navigate()` now calls `_streamDir` for column view instead of `listDirectory`.

Stale-nav guard is preserved: if `mySeq !== _navSeq` fires inside the listener (user clicked again mid-stream), the listener unlistens and resolves `null`. `if(!result) return` in `navigate()` exits cleanly.

**Root cause 3 — No visual feedback before the Rust await:**

`state.loading=true` was set but no render was triggered until after the await completed, so the toolbar spinner never appeared. The UI looked completely frozen for the full duration of the directory read.

**Fix:** Added `renderToolbar()` immediately after `state.loading=true`, before the first `await`. The spinner appears within 1ms of the click.

**Expected result (Music, 893 entries):**
- Before: 25ms hard freeze → column appears
- After: <1ms → spinner visible; ~3ms → first 60 entries appear; ~25ms → all 893 entries silently filled in (user already sees content)

---

### Fix — `walkdir` crate used but never declared in `Cargo.toml` (`src-tauri/src/main.rs`)

`_compress_files_sync` used `walkdir::WalkDir` for recursive directory traversal when compressing folders, but `walkdir` was never added to `Cargo.toml`. On a clean `cargo build` it fails with `E0432: unresolved import walkdir`. Replaced with a local recursive helper `walk_dir(root, out)` using only `std::fs::read_dir`. Behaviour is identical: depth-first, sorted by filename for deterministic zip output. `Cargo.toml` is unchanged.

---

### Fix — Dead code warning: `DirWatcher.path` field never read (`src-tauri/src/main.rs`)

`DirWatcher` stored a `path: String` field that was assigned at construction but never accessed. Removed the field and updated the construction site. The struct now holds only `_watcher: RecommendedWatcher`.

---

### Perf — Column view navigation uses `list_directory_fast` (zero stat syscalls) (`src-tauri/src/main.rs`, `src/main.js`)

`list_directory` called `build_file_entry` per entry (1–2 `lstat()`/`stat()` syscalls each). For large folders this cost was CPU-bound and irreducible: Music (893 entries) consistently took 25–34ms on every navigation, including revisits to already-cached folders.

`list_directory_fast` reads name, type, and symlink flag from the kernel `dirent` buffer returned by `read_dir()` — zero additional syscalls for normal files; one `stat()` only for symlinks to resolve their target. Added `pub is_symlink: bool` to `FileEntryFast` (free — already reading `file_type()`), populated in both `list_directory_fast` and `list_directory_streamed`.

`listDirectory()` now calls `list_directory_fast`. `listDirectoryFull()` calls `list_directory`. `navigate()` uses streaming for column view. `refreshColumns()` uses `listDirectory` (fast). The view-switcher non-column branch uses `listDirectoryFull` (list/gallery/icon need `size`/`modified` for their columns).

---

### Fix — Preview panel showed blank metadata for column-view entries (`src/main.js`)

Column view entries came from `FileEntryFast` (no `size`, `modified`, `permissions`, `created`, `accessed`). The preview panel rendered `--` for all metadata rows. `loadPreview()` now checks `entry.modified == null` and calls `get_entry_meta` first — a single `stat()` on one file. Preview panel shows correct metadata for both files and folders.

---

### Fix — `sortEntries` produced random order on Size/Date sort in column view (`src/main.js`)

`FileEntryFast` entries have no `size` or `modified`. The sort comparators used bare arithmetic (`a.size - b.size`, `a.modified - b.modified`) which evaluates to `NaN` for `undefined` operands, making the sort result undefined/random. Changed to `(a.size||0) - (b.size||0)` and `(a.modified||0) - (b.modified||0)`.

---

## What's in Beta-4-r16

**No Rust recompile needed.** JS-only changes (`src/main.js`, `src/utils.js`).

### Fix — Bundled icon themes removed from cold-start parse path (`src/utils.js`)

**Root cause:** `utils.js` unconditionally imported three large third-party icon theme bundles at module load time: `icons-kora.js` (56 KB), `icons-newaita.js` (102 KB), and `icons-whitesur.js` (216 KB). Vite bundled all three into the JS output regardless of whether the user ever selected one of those themes — adding ~375 KB of SVG string data to every cold start. The JS engine had to parse and intern all 374 KB before the app could display its first frame.

**Fix:** Removed all three `import` statements and deleted `getKoraIcon`, `getWhiteSurIcon`, `getNewaitaIcon`, and all three `_MAP` objects. `ICON_THEMES` now only contains `builtin`. `getIcon()` is a single-line builtin lookup. `fileIcon()` has the Newaita folder-variant branch removed. Added a `_REMOVED_BUNDLED_THEMES` Set to migrate any saved theme preference back to `builtin` on first load so existing users don't get stuck in a broken state.

**Files deleted:** `src/icons-kora.js`, `src/icons-whitesur.js`, `src/icons-newaita.js`, `src/icons-kora/` (SVG directory).

**Result:** ~375 KB removed from the JS parse budget on every cold start.

---

### Fix — Undo/redo stack not populated for drag-and-drop, rename, delete, and create (`src/main.js`)

**Root cause:** `pushUndo()` was only ever called in one place — inside `clipboardPaste()` after a batch move/copy completed. The undo stack existed and `undoLastOp()`/`redoLastOp()` had full handling for `'move'`, `'copy'`, `'rename'`, `'delete'`, and `'create'` operations, but none of the other code paths that mutate the filesystem ever called `pushUndo()`. Pressing Ctrl+Z after a drag-drop, rename, delete, or file creation did nothing.

**Fixes — five call sites added:**

**1. Drag-and-drop (`setupDropTarget`):** Added a `file-op-progress` listener running in parallel with the existing `ddDone` listener. It accumulates `{src, dst, srcDir, dstDir}` items as each file completes. After `ddDone` resolves, calls `pushUndo({op:'move'|'copy', items:ddUndoItems})`. Both the existing `ddUnlisten` and the new `ddUnlistenProgress` are cleaned up together.

**2. `deleteEntries`:** Rewrote the loop to collect entries that were successfully trashed (vs those that threw). Calls `pushUndo({op:'delete', items:deleted})` after the loop. `op:'delete'` undo is intentionally a no-op in `undoLastOp` (can't restore from Trash programmatically) — but the item is now on the stack so the user gets a "Cannot undo delete" toast rather than silent confusion.

**3. `promptCreate`:** Calls `pushUndo({op:'create', items:[{dst, srcDir, newName}]})` in the `.then()` success handler. Undo deletes the created file/folder via `delete_items`.

**4. `promptCreateDoc`:** Same pattern as `promptCreate`.

**5. `startRename` (both code paths):** The prompt fallback (`prompt()`) and the inline contenteditable path both now call `pushUndo({op:'rename', items:[{src, dst, oldName, newName}]})` after a successful `rename_file` invoke. Undo calls `rename_file` with the old name; redo calls it back with the new name.

---

### Fix — Undo/redo stacks lost on tab switch (`src/main.js`)

**Root cause:** `makeTabState()` did not include `_undoStack` or `_redoStack` fields, and `syncState()` did not list them in its `keys` array. Each tab therefore shared the single global `state._undoStack`/`state._redoStack` object reference but `syncState()` never wrote the current stacks back to the tab's saved state. When `switchTab()` called `Object.assign(state, ts)`, the undo stacks were wiped to empty (the default in `makeTabState`). Any undo history accumulated in one tab was destroyed the moment the user switched to another tab and back.

**Fix:** Added `_undoStack:[]` and `_redoStack:[]` to `makeTabState()`. Added `'_undoStack'` and `'_redoStack'` to the `keys` array in `syncState()`. Undo history is now per-tab and survives tab switching.

---

## What's in Beta-4-r12 through Beta-4-r15

**No Rust recompile needed.** JS-only changes (`src/views.js`).

### Fix — Navigating to large directories stalls the app — all three list renderers virtualized (`src/views.js`)

Large directories (e.g. `/home/jay/Music` with 893 entries) caused multi-hundred-millisecond hangs on every navigation and render. All three renderers were building full DOM node sets synchronously regardless of directory size.

#### Gallery strip — virtual horizontal scroller (r12)

**Root cause:** `renderGalleryView` built the strip via `entries.map(...).join('')` → `innerHTML`. 893 entries = 893 synchronous DOM nodes, 893 `fileIcon()` calls, 893 `escHtml()` calls, immediate layout for all of them. Total UI-thread cost: ~37 ms on every gallery navigation to Music.

**Fix:** `_makeGthumb`, `_paintStrip`, `_scrollToSel` added. Strip `<div>` is `position:relative; width:_stripTotalW(n)px`. Only the visible window (~12 items at typical viewport) is ever in the DOM. A `scroll` listener repaints as the user scrolls. On incremental update, only `.sel` toggling + `_scrollToSel` in rAF.

#### Column view — virtual vertical scroller (r12)

**Root cause:** `colList.innerHTML = entries.map(...).join('')` created all rows in one write, then `colList.querySelectorAll('.frow').forEach(...)` attached N×3 event listeners. 893 entries = 2,679 event listeners registered synchronously before first paint.

**Fix:** `_colSpacer` div sets total scroll height (`entries.length × 28px`). `_paintColList()` renders only the visible window (viewport ÷ 28px + 6 overscan each side). Rows are `position:absolute; top: ei × 28px`. Event delegation (one `click`/`dblclick`/`contextmenu` per `colList`) replaces per-row listeners. `ResizeObserver` repaints on column width change. `rAF` scroll-to-selected on initial render when `col.selIdx >= 0`.

#### List view — virtual vertical scroller, table-spacer approach (r12)

**Root cause:** `entries.map(...).join('')` → `tbody.innerHTML`, then per-row listeners via `querySelectorAll('.list-row').forEach(...)`.

**Fix:** Two sentinel `<tr class="lv-spacer">` rows hold total scroll height as inline `height` CSS. `_makeLvRow` / `_paintLv` add/remove rows around the spacers. `LV_ROW_H` starts at 29px then is measured from the first rendered row after initial `rAF` — always accurate regardless of CSS font/padding changes. Event delegation on `lvWrap`.

### Fix — `sel._e` not set before `sel.set(i)` in gallery strip click handler (r12)

When arriving in gallery view from column view, `sel._e` still pointed at the column entry array. `sel.set(i)` resolved an undefined or wrong path — breaking context menus and cut/copy. Fixed in the strip click handler, list view click handler, and list view contextmenu handler.

### Fix — `_setupThumbObserver` redundant scroll fallback removed (r12)

With the virtual strip, only visible items are in the DOM and already observed by `thumbObserver`. The old 80ms post-scroll `_loadGthumb` sweep was redundant and could trigger unnecessary IPC. Removed. `_setupThumbObserver` now accepts an explicit `stripWrap` parameter.

---

## What's in Beta-4-r8 through Beta-4-r11

**No Rust recompile needed.** JS-only changes (`src/utils.js`).

### Feature — Tab system (`src/main.js`)

Full multi-tab navigation. `makeTabState()` creates isolated per-tab state objects (column stack, selection, history, view mode, sort, tags, undo stacks). `newTab(path)`, `closeTab(id)`, `switchTab(id)` manage the tab array. `syncState()` flushes current `state` back to the active tab before every switch. `renderTabs()` builds the tab bar DOM with close buttons and a `+` button. Keyboard shortcuts: Ctrl+T (new tab), Ctrl+W (close tab), Ctrl+Tab / Ctrl+Shift+Tab (next/previous tab). Tab labels update to the last path component of the current directory.

### Feature — Undo/redo stack (`src/main.js`)

`pushUndo({op, items})` records up to 50 operations. `undoLastOp()` reverses the most recent operation: move → move back, copy → delete copy, rename → rename back, create → delete. `redoLastOp()` re-applies. Keyboard shortcuts: Ctrl+Z (undo), Ctrl+Y / Ctrl+Shift+Z (redo). Full per-operation coverage added in r16 (see above).

### Feature — Breadcrumb overflow ellipsis menu (`src/main.js`)

When the path is too long for the breadcrumb bar, an ellipsis `…` button appears. Clicking it opens a popup listing the hidden path segments. `enterBcEditMode()` / `exitBcEditMode()` allow typing a path directly. Ctrl+L focuses the breadcrumb for keyboard navigation.

### Feature — Trash banner (`src/main.js`, `src/style.css`)

When the current directory is `~/.local/share/Trash/files`, a `#trash-banner` strip appears above the file list with an "Empty Trash" button. `renderTrashBanner()` shows/hides the banner based on `state.currentPath`.

### Feature — Inotify-based filesystem watcher (`src-tauri/src/main.rs`, `src/main.js`)

`watch_dir` uses the `notify` crate (inotify on Linux) to watch the current directory for create/modify/delete/rename events. Events are debounced 300ms before emitting `"dir-changed"` to JS. `unwatch_dir` stops the watcher. JS calls `watch_dir` at the end of every `navigate()` and listens for `"dir-changed"` to call `refreshColumns()`. Replaces the previous mtime-polling approach which fired spurious renders on every navigate.

### Feature — `refreshColumns()` (`src/main.js`)

In-place column refresh after drag-and-drop — re-fetches and re-renders all open columns without destroying the column layout or scroll position. Previously, DnD triggered a full `navigate()` which collapsed all open columns back to a single column.

---

## What's in Beta-4-r7

**No Rust recompile needed.** JS-only fix.

### Bug — Vite parse error: `loadTagsForEntries` had a duplicated body with a dangling `catch` (`src/main.js`)

**Root cause:** The function body of `loadTagsForEntries` was accidentally duplicated — likely from a bad edit or merge conflict. The first copy of the body was complete and correct (ending with `}catch(e){}`), but the duplicate was appended immediately after with no wrapping `try{`. This left a bare `}catch(e){}` at function scope with no matching `try`, which is a pure syntax error. Vite's `import-analysis` plugin (which uses `es-module-lexer`) failed to parse the file and refused to serve it, causing a blank/non-functional app on startup.

**Fix:** Removed the duplicated portion entirely. The function now has a single, correct `try/catch` block, ending cleanly before `async function refreshTagColors`.

### Bug — Quick Look window never showed content after first open (`src/views.js`)

**Root cause:** `listen()` (Tauri event subscription) is async — it does a round-trip to the Tauri backend to register the listener. In the old `initQuickLook`, `listen('ql-ready', ...)` and `listen('ql-closed', ...)` were called **after** `new WebviewWindow(...)`. Because the window starts loading immediately on construction, `ql.html` could fire `ql-ready` before the `await listen(...)` call in the main window resolved. The event landed in nothing, `_qlReady` stayed `false` forever, `_qlPendingPayload` was never flushed to the window, and the QL window displayed blank content on every open after the first.

**Fix:** Both `await listen('ql-ready', ...)` and `await listen('ql-closed', ...)` are now registered **before** `new WebviewWindow(...)` is called. This guarantees the Tauri backend has live subscriptions before the window process can emit any events.

---

## What's in Beta-4-r5

### Feature — Folder preview panel shows full information

Clicking a folder now shows a proper info panel in the preview sidebar, matching the macOS Finder-style layout: large folder icon, folder name, folder size, and an **Information** section with Created, Modified, Last Opened dates, permissions, and Tags.

**Changes:**

`src-tauri/src/main.rs` — Added `created: Option<u64>` and `accessed: Option<u64>` to `FileEntry`. Both fields are populated in `build_file_entry` using `real_meta.created()` and `real_meta.accessed()` respectively. Both are `Option` because Linux filesystems don't always expose birth time (`created`) depending on the filesystem type (ext4 on older kernels, tmpfs, etc.) — `None` is serialised as `null` and the JS template simply omits those rows.

`src/views.js` — The folder branch of `renderPreview` now renders a two-phase panel. The panel appears immediately with the folder icon, name, and all available metadata (Created, Modified, Last Opened, Permissions, Tags). A non-blocking `invoke('get_dir_size')` call runs in parallel; when it resolves, the panel re-renders with the real size appended to the kind line (e.g. `Folder · 49.2 MB`). The re-render is guarded by `state.previewEntry === e` so it's a no-op if the user has already navigated away. Long-form date formatting uses `toLocaleDateString('en-GB', {day:'numeric', month:'long', ...})` to match the screenshot style.

`src/style.css` — Added `.pv-folder-header` (larger padding for folder header), `.pv-folder-icon` (drop-shadow on folder SVG), and `.pv-section-title` (the "Information" section heading with uppercase letter-spacing).

---

## What's in Beta-4-r42

### Bug fix — Tag row color tinting not appearing (all views)

Tag row tinting added in r3 was visually absent in all views. Three separate root causes:

**Root cause 1 — Icon view: `background: transparent !important` beat inline styles**

`.icon-item` in `style.css` has `background: transparent !important` to prevent a WebKit2GTK bug where GPU-composited icon backgrounds would "ghost" as black squares on Mesa/CachyOS. In CSS, `!important` in a stylesheet rule overrides even inline `style=""` attributes — so setting `background: #color33` in the element's inline style had no effect at all.

Fix: Changed `.icon-item` to `background: var(--tag-tint, transparent) !important`. The CSS custom property `--tag-tint` is set via `style.cssText` on tagged items (e.g. `--tag-tint: #f8717133`). Because the `!important` rule now reads its value from a CSS var that can be overridden per-element via inline custom property assignment, the tint shows through. Untagged items fall back to `transparent`. The ghost-prevention behaviour is fully preserved.

**Root cause 2 — List view: CSS custom properties not reliably inherited through `<tr>` → `<td>` in WebKit2GTK**

r3 set `--row-tag-bg` on the `<tr>` element and relied on CSS custom property inheritance to reach `<td>`. Standard CSS says custom properties are inherited, but WebKit2GTK's table layout model handles `<tr>` as an anonymous box and inheritance through `<tr>` → `<td>` is unreliable in this engine — especially combined with `contain: layout style paint` on `.list-row`.

Fix: Dropped the CSS var approach entirely. `tdBg` is now computed per row as `` `style="background:${tagColor(_rowTag)}33"` `` and applied directly inline to every `<td>` in the row template. Applied in both the regular list view and the search-results flat list view. Selected rows skip the tint (`_rowTag` is `null` when `isSel` is true) so the blue selection background is not affected.

**Root cause 3 — Column view: `contain: layout style paint` may block CSS var resolution**

`.frow` also has `contain: layout style paint`. The r3 CSS rule `background: var(--row-tag-bg, transparent)` on `.frow` with `--row-tag-bg` set inline on the same element should theoretically work, but `contain: style` creates an isolated style scope which some WebKit builds treat as blocking external custom-property resolution even from the element's own inline style.

Fix: Same direct approach — background is now applied as a literal `style="background:#color33"` attribute on the `<div class="frow">` itself, only when the row is not already in a selected/hovered state. The `.frow:hover` and `.frow.sel` CSS rules continue to override cleanly via normal cascade specificity.

---

## What's in Beta-4-r3

### 2 features added

**Feature 1 — Tag row color tinting (all views)**

Tagged files and folders now have their row visually tinted with the tag's color across all four views: column view, list view (including search results), and icon view.

Implementation uses CSS custom properties (`--row-tag-bg`) so the tint is a base-layer style that existing state rules (`.sel`, `:hover`, `.cut-item`) cleanly override at higher specificity — no `!important` hacks needed.

- **Column view** (`views.js`): The `frow` div template now computes the first tag for each entry inline during `innerHTML` generation and emits `style="--row-tag-bg: <color>33"` on tagged rows. `.frow` base rule updated from no background to `background: var(--row-tag-bg, transparent)` in `style.css`.
- **List view — regular** (`views.js`): `<tr class="list-row">` gets `style="--row-tag-bg: <color>33"` for tagged entries. `.list-row td` base rule updated to `background: var(--row-tag-bg, transparent)` — inherits the CSS var from the `<tr>` parent. Hover and selected `td` rules override cleanly.
- **List view — search results** (`views.js`): Same `--row-tag-bg` treatment applied to the flat/search results list `<tr>` template.
- **Icon view** (`views.js`): Non-selected tagged icon items get `background: <color>33` injected into their inline `style.cssText`. Selected items keep the blue selection background as before. The tint is cleared on selection and restored on deselection via the existing selection logic.

Alpha value `0x33` (20%) used for all views — visible enough to identify at a glance, subtle enough not to obscure text or icons.

**Feature 2 — Debug log 💾 button now opens a native save dialog**

Previously the 💾 button in the debug log panel used `<a download>` which silently dumped the log to the browser's default downloads folder without any prompt.

`download()` rewritten as `async` and now uses `@tauri-apps/api/dialog` (`save()`) + `@tauri-apps/api/fs` (`writeTextFile()`) to open the OS-native file chooser. The user picks any location and filename before saving. The dialog pre-fills `frostfinder-debug-<timestamp>.log` and offers `.log`, `.txt`, and all-files filter options.

`tauri.conf.json` allowlist updated: `dialog.save` and `fs.writeFile` (scoped to `**`) enabled. Two new imports added to the top of `main.js`.

---

## What's in Beta-4-r2

### 3 bugs fixed

**Bug 1 — ql-window.js — Space bar would not close QL window while audio/video was playing**

The Space keydown handler in `ql-window.js` checked whether a media element was actively playing (`!el.paused && !el.ended && el.readyState > 2`). If media was playing, it fell through without calling `closeWindow()`, relying on native browser play/pause behaviour. However, if the media element was not focused (e.g. the user had clicked elsewhere in the QL chrome), the Space event had no native target and the window neither closed nor paused — the key did nothing.

Fix: removed the media-playing guard entirely. Space now unconditionally calls `closeWindow()`. `closeWindow()` calls `stopAllMedia()` first, which pauses and clears all `<audio>`/`<video>` elements before hiding the window. This is consistent and safe — media is always stopped on close regardless of trigger.

**Bug 2 — main.rs — App froze when extracting files after long use (blocking thread exhaustion)**

`extract_archive` called `tauri::async_runtime::spawn_blocking` with no guard against concurrent calls. If the user triggered a second extraction while one was already running (or triggered repeated extractions rapidly over a long session), each call occupied a Tokio blocking thread for the full extraction duration. Over time, threads accumulated and the Tokio blocking thread pool became saturated, causing the entire async runtime — and with it the UI — to freeze.

Fix: added `EXTRACT_IN_PROGRESS: AtomicBool`. `extract_archive` uses `compare_exchange` to claim the flag before spawning the blocking thread. If a second extraction is attempted while one is running, it returns a clear user-visible error immediately instead of queuing another thread. The flag is reset unconditionally in both the success and `map_err` paths.

**Bug 3 — main.rs — `which` subprocess spawned on every extraction (wasted syscalls + slow startup on tar-format archives)**

`_extract_archive_sync` called `std::process::Command::new("which")` twice on every extraction for tar-based formats to locate the `bsdtar` / `tar` binary. These synchronous subprocess spawns happen inside the blocking thread, adding unnecessary overhead on every call and repeatedly thrashing the process table on systems where extractions are frequent.

Fix: added `TAR_BIN: OnceLock<Option<String>>` and a `find_tar_bin()` helper. The `which` probe runs exactly once on the first tar-based extraction and the result is cached for the lifetime of the process. Also added `std::thread::yield_now()` every 64 entries in the ZIP extraction loop so the blocking thread cooperates with the OS scheduler during large archives.

---

## What's in Beta-4-r1

### Full codebase audit — 8 bugs fixed

Complete line-by-line review of all source files (main.js, views.js, ql-window.js, utils.js, ql.html). Eight issues found and fixed:

**Bug 1 — main.js:182 — Stale version string in debug log download**
The FF debug log download header still said `β1-r39`. Updated to `FrostFinder Beta Build`.

**Bug 2 — main.js:521 — Directory auto-refresh destroyed column stack**
`startWatching()` called `refreshCurrent()` when the directory's mtime changed on disk. `refreshCurrent()` calls `navigate(currentPath, 0)` which resets `state.columns` to a single entry — blowing up the column layout every 2 seconds any time another app touched a file in the current folder. Fixed: call `refreshColumns()` instead.

**Bug 3 — main.js:1843 — Dead `isTrash` variable in renderTrashBanner()**
A variable `isTrash` was computed with a multi-clause condition but never used. The real check was `trashRoot` (the very next line). The dead variable also had an operator-precedence ambiguity (`||` vs `&&` without parens). Removed the dead variable.

**Bug 4 — ql-window.js:258 — Missing `_ff_stopped` guard in error-path transcode stall timer**
The three `_ff_stopped` guards added in r43 (outer stall timer, inner stall timer, error handler) missed one case: the inner `setTimeout` created *inside the error handler* when transcoding is triggered by a codec error. If the window closes while that timer is pending, it would call `_showMpvFallback()` on a hidden window's DOM. Added the missing guard.

**Bug 5 — ql-window.js:414 — Space always closed QL even during active playback**
The QL keydown handler closed the window on Space unconditionally. If the user had audio or video playing and pressed Space expecting pause/play, the window closed instead. Fixed: Space now only closes if no media element is actively playing (`!el.paused && !el.ended && el.readyState > 2`). If media is playing, Space falls through to the browser's native pause handler.

**Bug 6 — views.js:848 — Rubber-band selection: cssText.replace() on every mousemove**
The rubber-band `onMove` handler read `band.style.cssText`, ran a regex replace to strip old position properties, then set individual properties. Reading `cssText` forces style resolution; the replace + reassign re-parses all styles — on every pointer move event. Removed the redundant `cssText.replace()` line. Individual property assignments (`band.style.left = ...`) correctly override any existing value without needing the strip.

**Bug 7 — views.js:1603 — Gallery zoom keydown listener leaked on every directory navigation**
The zoom `+/-/0` keydown listener was added with `document.addEventListener('keydown', function _gzKey(e){...})` — a named function expression with no stored reference. The guard `host._gzKeyBound` prevented duplicates within a single directory, but on full rebuild (new directory), `host._gzKeyBound` was reset to `false` and a new anonymous listener was added — the old one was never removed. After navigating 10 directories in gallery view, 10 zoom listeners were active simultaneously. Fixed: listener stored as `host._gzKeyFn`, removed via `document.removeEventListener` before each full rebuild.

**Bug 8 — views.js:2174 — quickLookNavigate() was a broken stub returning `!!_qlWin`**
The exported `quickLookNavigate(dir)` function returned `!!_qlWin` and did nothing with its `dir` argument. It was imported in main.js but never called. Replaced the misleading return value with a proper no-op stub and explanatory comment.

---

## What's in Beta-3-r43

### Bug fix — Video continues playing in background after QL is closed
**Root cause:** `stopAllMedia()` correctly calls `el.pause(); el.src = ''; el.load()` — but setting `src` to an empty string on a playing `<video>` element fires the `error` event. The `error` listener inside `renderEntry` responds by switching to the ffmpeg transcode URL and calling `vid.play()`, restarting playback inside the hidden window. The stall detection `setTimeout` callbacks have the same problem — if they fire after `hide()`, they also set a new src and call `play()`.

**Fix:** A `_ff_stopped` boolean flag is set on each element by `stopAllMedia()` *before* clearing its `src`. Four guards added:
1. `stopAllMedia()` — sets `el._ff_stopped = true` before `el.src = ''`
2. Outer stall timer (5 s) — `if (vid._ff_stopped) return`
3. Inner stall timer (transcode 20 s fallback) — same guard
4. `error` event handler — `if (vid._ff_stopped) return` (this is the primary path that was restarting playback)

All four guards are needed because any of these async callbacks can fire after `hide()` if the window was closed while a video was loading or buffering.

---

## What's in Beta-3-r42

### Bug fix — Quick Look window shows blank content (root cause: missing ql.html)
After comparing r41 with the working r11 build, the actual root cause is that `ql.html` was simply absent from the r40 diagnostic zip that r41 was built from. Vite's config declares `ql.html` as a second MPA entry point; the `WebviewWindow` loads it by URL (`'ql.html'`). Without the file the QL window gets a blank/404 page every time — no DOM, no script, no `ql-ready` event, nothing.

The `listen()` await fix applied in r41 was correct and has been kept, but it was treating a symptom (no `ql-ready` ever firing) rather than the root cause (no page to fire it from).

**Fix:** `ql.html` restored from the r11 working build. Content is identical to r11 — full window shell, title bar, nav buttons, body container, and `<script type="module" src="/src/ql-window.js">`. Compatible with r41/r42's `ql-window.js` which is a strict superset of r11's (adds `stopAllMedia()` only).

---

## What's in Beta-3-r41

### Bug fix — Quick Look fires up blank (no content shown)
**Root cause:** `listen()` in Tauri v1 is async — it requires a round-trip to the backend to register the subscription. In `initQuickLook()`, both `listen('ql-ready', ...)` and `listen('ql-closed', ...)` were called **without `await`**, then `new WebviewWindow(...)` was called immediately after. Because ql.html is small and pre-warm loads it fast, `ql-ready` fired from ql.html before either listener was registered in the main window. The event landed in nothing. `_qlReady` stayed `false` forever.

Consequence: every Space press took the `PENDING_PATH` branch, stored the payload, showed the window — but the `ql-ready` flush that was supposed to call `ql-update` never fired. ql.html called `get_ql_payload()` on its own init (which cleared the Rust store), but by then the update event was already missed, so it rendered with an empty/stale payload — blank window.

Confirmed by the diagnostic log: `QL_READY_FIRED` never appears in 37 seconds across two Space presses.

**Fix 1 — await listeners before creating the window:**
Both `listen('ql-ready')` and `listen('ql-closed')` are now `await`ed before `new WebviewWindow(...)`. This guarantees the subscriptions are live before ql.html can possibly emit anything.

**Fix 2 — belt-and-suspenders `ql-update` after `show()`:**
After `_qlWin.show()` resolves, an unconditional `emit('ql-update', {})` is sent. By the time `show()` resolves, ql.html's `listen('ql-update')` is always registered (ql.html registers it before emitting `ql-ready`). This ensures the window gets its content even in edge cases where `ql-ready` is still somehow missed.

### Title bar rename
Window title changed from `FrostFinder β1-r39` to **`FrostFinder Beta Build`** in both `tauri.conf.json` and `index.html`.

---

## What's in Beta-3-r12

**Rust recompile required.**

### Bug 1 — App won't quit after closing the main window (`src-tauri/src/main.rs`)

**Root cause:** The Quick Look window is intentionally kept alive in a hidden state (using `appWindow.hide()` instead of `appWindow.close()`) so it can be shown instantly the next time the user presses Space. This means Tauri's built-in "exit when the last window closes" logic never fires — after the user closes the main FrostFinder window, the hidden QL WebviewWindow keeps the entire process running forever. The app appeared to close (window gone, no taskbar entry) but remained as a zombie process consuming memory.

**Fix:** Added `.on_window_event(...)` to the Tauri builder in `main()`. When the event is `WindowEvent::Destroyed` and the window label is `"main"`, `app_handle.exit(0)` is called. This explicitly terminates all windows (including the hidden QL window) and the Rust process cleanly. The handler only fires for the main window — destroying the QL window itself does not re-trigger.

### Bug 2 — Audio keeps playing after Quick Look is closed (`src/ql-window.js`)

**Root cause:** `closeWindow()` called `appWindow.hide()` to hide the QL WebViewWindow, but never paused the `<audio>` element. The browser does not automatically pause or stop media elements when a window is hidden — the audio pipeline keeps running in the hidden WebView, producing sound with no visible player and no way to stop it.

A secondary instance of the same bug: `renderEntry()` called `qlBody.innerHTML = ''` before building each new file's content. This removes audio/video DOM nodes, but browsers intentionally keep detached media elements playing. Navigating between audio files in QL could leave the previous track's decoder running in the background.

**Fix:** Added `stopAllMedia()` helper that:
1. Pauses every `<audio>` and `<video>` element in `qlBody`
2. Clears `src` and calls `load()` to flush the decoder buffer immediately
3. Cancels the audio visualizer animation frame (`_vizAnimId`)

`stopAllMedia()` is now called in two places:
- At the top of `closeWindow()` — before `appWindow.hide()`, so audio stops the instant the window is dismissed.
- At the top of `renderEntry()` — before `qlBody.innerHTML = ''`, so previous-file audio stops before new content is loaded.

---

## What's in Beta-3-r11

No Rust recompile needed. Four bugs introduced in r10 fixed.

### Bug 1 — QL window was still destroyed on close, killing the pre-warm (`src/ql-window.js`)

`closeWindow()` in `ql-window.js` called `appWindow.close()`. This destroyed the WebViewWindow process. `_qlWin` in `views.js` still held the stale reference, so `_qlWin` was non-null but dead. The next Space press skipped `initQuickLook()` (because `!_qlWin` was false), called `show()` on a destroyed window, and silently failed — QL never appeared again after the first dismiss.

**Fix:** `appWindow.close()` → `appWindow.hide().catch(()=>{})`.

### Bug 2 — `navigate` was undefined in list view dblclick (`src/views.js`)

`renderListView`'s destructuring didn't include `navigate`. The new dblclick handler `if(entry.is_dir) navigate(entry.path, 0)` called an undefined function, throwing a `ReferenceError` on every folder double-click.

**Fix:** Added `navigate` to `renderListView`'s `const {...} = d()` destructuring.

### Bug 3 — `ql-closed` emit direction was wrong (`src/views.js`)

`closeQuickLook()` (called by main on Escape/Space-toggle) emitted `'ql-closed'`, which triggered the listener inside `initQuickLook`, which called `_qlWin.hide()` a second time. `'ql-closed'` is a ql→main event; main should never emit it.

**Fix:** Removed `emit('ql-closed')` from `closeQuickLook()`. It now just sets `_qlVisible=false` and calls `_qlWin.hide()` directly.

### Bug 4 — `ql-update` listener registered after `ql-ready` emitted (`src/ql-window.js`)

`init()` in `ql-window.js` called `emit('ql-ready')` before `listen('ql-update')`. Main's `ql-ready` handler fires `ql-update` immediately to flush a pending payload. If QL hadn't registered the `ql-update` listener yet (it hadn't), the event landed with no handler — the pending payload was silently dropped and QL showed blank content on the very first open.

**Fix:** Swapped order: `await listen('ql-update', …)` is now registered **before** `await emit('ql-ready', …)`.

### Also: double-init guard on `initQuickLook` (`src/views.js`)

Added `if (_qlWin) return;` at the top of `initQuickLook()` so the fallback path inside `openQuickLook` can never register duplicate `ql-ready`/`ql-closed` listeners.

---

## What's in Beta-3-r10

No Rust recompile needed.

### Fix: Quick Look launches instantly (`src/views.js`, `src/ql-window.js`, `src/main.js`)

**Root cause:** Every Space press called `new WebviewWindow('quicklook', …)`, which spawns a new OS-level WebKit process from scratch. On a typical system this takes 400–700ms before the window appears. No amount of JS optimisation could fix this — the delay is OS process startup time.

**Fix — pre-warm architecture:**

- `initQuickLook()` is called at app startup (parallel to sidebar/file loading) and creates the QL window with `visible: false`. WebKit initialises silently in the background.
- `ql-window.js` emits `'ql-ready'` once it has loaded and registered all listeners.
- When the user presses Space, `openQuickLook()` sets the payload and calls `_qlWin.show()` — the WebKit process is already running, so the window appears immediately.
- Closing QL calls `_qlWin.hide()` instead of `_qlWin.close()`, keeping the process alive for next time.
- If a payload arrives before QL is ready (rare race on very fast first keypress), `_qlPendingPayload` stores it and `ql-ready` flushes it via `ql-update`.

### Feature: Double-click to enter folders in icon view and list view (`src/views.js`, `src/main.js`)

Previously, single-clicking a folder in icon or list view immediately navigated into it. This made multi-select, drag-and-drop, and just looking at folder metadata frustrating since any misclick caused navigation.

**New behaviour:**
- **Icon view / List view / Search results:** single click selects and shows folder preview; **double-click navigates**.
- **Column view:** unchanged — single-click still opens the next column (that's the column paradigm).
- `handleEntryClick` no longer calls `navigate` for non-column views when a directory is clicked.
- All dblclick handlers updated: `if(entry.is_dir) navigate(entry.path, 0); else invoke('open_file', …)`.

---

## What's in Beta-3-r9

No Rust recompile needed. Full code audit — 8 bugs fixed.

### Bug 1 — List view column sort did nothing (`src/views.js`, `src/main.js`)

**Root cause:** `sortEntries()` contained `state.listSort={col,dir}`, which overwrote `state.listSort` with the global `sortState` values every time it was called. The list view header click correctly set `state.listSort.col='date'`, but then the very next line called `renderListView()`, which called `sortEntries()`, which immediately set `state.listSort` back to the global sort. The arrows showed the wrong column and the sort order never changed.

**Fix:** Removed `state.listSort=...` from `sortEntries()`. Rewrote `renderListView` to sort entries inline using `state.listSort` directly, with `sortState.foldersFirst` for the folders-first preference. `sortState` is now injected via `injectDeps`. List view and global sort (column/icon/gallery) are now fully independent.

### Bug 2 — Shift/Ctrl-click in search results selected wrong files (`src/views.js`)

**Root cause:** `handleEntryClick(entry, i, ev)` performs `sel.range(sel.last, idx)` and `sel.toggle(idx)`, which use `sel._e[idx]?.path`. `renderFlatList` renders rows sorted by `sorted[]`, so `i` is an index into `sorted`. But `sel._e` was left pointing at whatever `getVisibleEntries()` set it to — the unsorted `state.searchResults`. Index `i` into unsorted results is a different file than index `i` into `sorted`. Multi-select always targeted the wrong files.

**Fix:** `sel._e = sorted` is now set before attaching row event listeners.

### Bug 3 — Search results showed hidden files when "Show Hidden" was off (`src/views.js`)

**Root cause:** `renderFlatList` was called with raw `state.searchResults`, which may include hidden files. The function never applied the `showHidden` filter. `getVisibleEntries()` does filter hidden files for search mode, but `renderFlatList` bypasses that.

**Fix:** Added `if(!state.showHidden) entries=entries.filter(x=>!x.is_hidden)` at the start of `renderFlatList`, before the empty check.

### Bug 4 — Sidebar item click guard never fired (`src/main.js`)

**Root cause:** Operator precedence bug: `!item.dataset.path===undefined`. JS evaluates `!item.dataset.path` first (a boolean), then checks `=== undefined` (always `false`). The guard was dead code — items without a `data-path` attribute were never caught and caused `navigate(undefined)` calls.

**Fix:** `if(!item || !item.dataset.path) return;`

### Bugs 5–8 — Filenames with `<`, `>`, or `&` broke the DOM in 4 places (`src/views.js`)

Files named `foo<bar>`, `a&b`, or `"quote"` were injected raw into `innerHTML` strings in:
- Column view `.fname` span (Bug 5)
- List view `.cell-name-text` span (Bug 6) 
- Gallery view audio name and doc-preview fallback name (Bug 7)
- Lightbox caption (Bug 8)

**Fix:** All four now use `escHtml(e.name)` / `escHtml(sel_e.name)`.

---

## What's in Beta-3-r8

No Rust recompile needed.

### Feature: Search results — resizable columns, sortable headers, drag-and-drop (`src/views.js`, `src/main.js`)

`renderFlatList` (used for search and tag results) was a bare read-only table. Rebuilt to match list view quality:

**Resizable columns:** All five columns (Name, Location, Date Modified, Size, Kind) have drag-to-resize handles, stored under `sr-name`/`sr-loc`/`sr-date`/`sr-size`/`sr-kind` in `state.colWidths`. Widths persist across searches and tab switches. Default widths: Name 260, Location 220, Date 160, Size 80, Kind 90.

**Sortable headers:** Click any column header to sort; click again to reverse. Sort state stored in `state.searchSort` (persists per tab). Defaults to name ascending.

**Drag-and-drop:** `setupDragDrop` and `setupDropTarget` now wired on every row, matching list/column view. Files can be dragged out of search results to any folder drop target. Directory rows in results accept drops.

**Other fixes in the old flat list:**
- Name cell was `${e.name}` bare text — now wrapped in `<span class="cell-name-text">` so inline rename selector (`.cell-name-text`) matches correctly.
- Names now go through `escHtml()` — filenames with `<`, `>`, `&` were rendering as broken HTML.
- Location column had a hardcoded `max-width:200px` inline style — replaced by the resizable column system.
- `cut-item` class was missing — cut files now show the correct dimmed style.
- Background context menu (right-click on empty space) now works.
- Click on empty space deselects all.

---

## What's in Beta-3-r7

No Rust recompile needed.

### Fix: DnD still broken in column view — 200ms hold timer fired during drag pause (`src/views.js`)

**What the log showed:** At +66.965s user clicked a file. Repeated RENDER calls fired at +67.005, +69.217, +71.667, +71.767. The RENDER pairs are exactly the signature of `disarm(true)` being called after `active=true` — the 200ms hold timer was firing before the user even started moving, activating selection mode and setting `draggable=false`. Every subsequent drag gesture was silently blocked.

**Why 200ms was wrong:** Many users naturally pause for 100–400ms between mousedown and the start of a drag motion. The 200ms timer made no allowance for this pause — any hesitation triggered selection mode and killed DnD.

**New architecture — `dragstart` as final arbiter:**

1. `mousedown` → arm + start **600ms** timer  
2. Pointer moves **>5px** before timer fires → `disarm()` immediately. `draggable` stays `true`. Browser fires `dragstart` on the row. DnD proceeds.
3. `dragstart` fires (capture phase, before `setupDragDrop`'s handler):
   - `wantSelection=true` (timer already fired) → `preventDefault()` + `stopPropagation()` + set `draggable=false` → DnD cancelled → selection proceeds
   - `wantSelection=false` → `disarm()`, do **not** preventDefault → DnD handler on row runs normally
4. Timer fires (600ms, <5px movement) → `wantSelection=true`, activate selection mode  
5. `mouseup` → `disarm()`, restore `draggable=true`

Any drag where the user moves within 600ms works perfectly. Selection requires an explicit 600ms hold with no movement.

### Added: `DRAG_START` and `DROP` debug log entries (`src/main.js`)

`setupDragDrop` now logs `DRAG_START {name, count, srcDir}` and `setupDropTarget` logs `DROP {destPath, count, op}`. Future debug logs will confirm whether DnD events are firing at all.

---

## What's in Beta-3-r6

No Rust recompile needed.

### Fix: Drag-and-drop and clipboard paste silently did nothing (`src/main.js`)

**Root cause — JavaScript temporal dead zone (TDZ).** Both the drop handler and `clipboardPaste` had this pattern:

```js
const done = new Promise(resolve => { _resolve = resolve; }); // callback runs synchronously
const unlisten = await listen(..., ev => { if (finished) _resolve(); });
let _resolve;  // ← declared AFTER it was already used above
```

`let` declarations are hoisted to the top of their scope but remain in the **temporal dead zone** until the declaration is physically reached in execution order. The `new Promise(...)` callback runs synchronously — at that moment `_resolve` is in TDZ. Assigning to a TDZ variable throws a `ReferenceError`. Since both handlers are `async` and not awaited by the caller, the error is silently swallowed. Nothing moved, nothing copied, no toast, no error — just silence.

This affected:
- **Drag-and-drop** (`drop` event handler) — `let _ddResolve` was declared 3 lines after the Promise that tried to assign it. Every drag-and-drop silently failed.
- **Clipboard paste** (Ctrl+V / right-click Paste) — `let _pasteUnlisten` was declared after the Promise. Every paste silently failed.

**Fix:** Move both `let` declarations to before their respective `new Promise` calls.

---

## What's in Beta-3-r5

No Rust recompile needed.

### Fix: Drag-and-drop (move/copy) broken in column view — root cause finally correct (`src/views.js`)

**What the debug log showed:** User tried to drag `FrostFinder-beta-2-r55` to move it. `attachDragSelect` activated instead — sweeping 5 rows into selection. `selSize=5` then broke subsequent single-clicks (navigation requires `sel.size===1`). DnD never happened.

**Why r4 was still wrong:** r4 called `ev.preventDefault()` on `mousemove` to prevent DnD, relying on the HTML spec clause "browsers MUST NOT initiate DnD if mousemove is cancelled." WebKit2GTK ignores this. DnD and selection still raced — selection won, DnD lost, every drag gesture in column view selected rows instead of moving files.

**Correct fix — hold timer + `draggable=false`:**

- Restored 200ms hold timer. Movement >5px before timer fires → `disarm()` immediately → DnD proceeds untouched. Timer fires with pointer still → selection activates.
- When selection activates: `colList.querySelectorAll('.frow').forEach(r => r.draggable = false)`. This is unconditional — no spec interpretation, no browser quirk. Once `draggable=false`, the browser physically cannot start a drag operation for the rest of the gesture.
- On `disarm()`: `r.draggable = true` restored on all rows so DnD works again for the next gesture.

**Usage:** Click and hold a row for 200ms without moving → drag to select range. Quick drag → moves/copies files as usual.

---

## What's in Beta-3-r4

No Rust recompile needed.

### Fix: Drag-and-drop broken in column view (`src/views.js`)

**Root cause:** `attachDragSelect.activate()` added a capture-phase `dragstart` listener (`suppressDrag`) to `colList`. Capture-phase listeners run before any bubble-phase listeners, so this fired before `setupDragDrop`'s `dragstart` handler on every `.frow` element. Every drag gesture in column view — whether the user intended to move a file or select multiple files — was immediately cancelled by `suppressDrag`. DnD never worked once selection code was added.

**Fix — two-part:**

1. **`ev.preventDefault()` on the activating `mousemove`:** Per the HTML spec, browsers MUST NOT initiate a drag operation if `mousemove` is cancelled. When `attachDragSelect` decides the user is doing a selection drag (movement > 8px), it now calls `ev.preventDefault()` on that exact `mousemove`. This cleanly prevents DnD from starting, without touching `dragstart` at all.

2. **`dragstart` as DnD-wins signal:** If the browser fires `dragstart` before we activate selection (fast drag, user intent is DnD), a non-capturing `dragstart` listener on `colList` calls `disarm()` so selection mode cancels and DnD proceeds normally through `setupDragDrop`'s handler.

3. **Removed the `dragstart` suppressor entirely.** No more capture-phase blocking.

**Threshold raised from 4px to 8px:** The browser's native DnD threshold is ~4px. By setting ours to 8px, the browser gets first opportunity to fire `dragstart` for fast drags (DnD intent). Slow deliberate downward drags cross 8px before `dragstart` fires (selection intent). The two modes are cleanly separated.

---

## What's in Beta-3-r3

**Rust recompile required.**

### Fix: Extracting archives freezes the app (`src-tauri/src/main.rs`)

**Root cause:** `extract_archive` was a synchronous `#[tauri::command]`. Tauri runs sync commands on an IPC handler thread and the JS `await invoke(...)` suspends the entire WebView event loop waiting for the response. A large zip or tar file can take several seconds, causing the window to go completely unresponsive.

**Fix:** `extract_archive` is now `async` and calls `tokio::task::spawn_blocking(...)` to run the blocking I/O on a dedicated thread pool thread. The WebView stays fully responsive while extraction runs. Same fix applied to `compress_files`.

### Fix: `listen` race condition causing paste/copy to hang forever (`src/main.js`)

**Root cause:** `clipboardPaste` set up the progress listener like this:

```js
const done = new Promise(resolve => {
  listen('file-op-progress', ev => { ... if(finished) resolve(); })
    .then(fn => { unlisten = fn; });  // async — not awaited
});
invoke(cmd, {...});  // fires immediately on next line
await done;
```

`listen()` is itself async — it must round-trip to the Tauri event bus to register the listener. `invoke()` fires on the very next line. For any fast operation (small file, same-filesystem move which is just a rename), Rust emits `finished: true` before the JS callback is registered. The `done` Promise never resolves. The UI hangs at `await done` indefinitely.

**Fix:** `await listen(...)` before `invoke()`. Listener is guaranteed to be registered before any events can fire.

### Fix: Drag-and-drop was synchronous and blocked the UI (`src/main.js`)

**Root cause:** The drag-drop handler called `invoke('copy_file',...)` / `invoke('move_file',...)` in a sequential loop. Each `await invoke(...)` blocked the JS event loop until that file finished. Dragging 5 large files would block the UI 5 times in series.

**Fix:** Drag-drop now uses `copy_files_batch` / `move_files_batch` with the same `listen`-before-`invoke` pattern and a live progress bar for multi-file drops.

### Fix: `copy_file` and `move_file` tauri commands were synchronous (`src-tauri/src/main.rs`)

Both commands (used by undo/redo and drag-drop) were sync `#[tauri::command]` functions that blocked the IPC thread. Both are now `async` with `tokio::task::spawn_blocking`. Internal sync helper functions `copy_file_sync` / `move_file_sync` are kept for use by `copy_files_batch` / `move_files_batch`.

---

## What's in Beta-3-r2

No Rust recompile needed.

### Bigger default icon size (`src/main.js`)
Default icon size bumped from `80px` → `112px`. Slider range unchanged (28–120px); user can still adjust live with the toolbar slider.

### Column view: instant click-and-drag selection (`src/views.js`)
Previous model required a **150ms hold timer** before drag-select activated. If you moved more than 8px during the hold, native file-drag won instead, making it very hard to reliably trigger drag-select.

New model: **no hold timer**. Drag-select activates the moment the pointer crosses a 4px movement threshold after `mousedown`. Feels instantaneous. `mouseup` without crossing the threshold is still a normal single-click — no behaviour change for click-to-open.

Highlight updates are now **rAF-throttled**: `syncClasses()` schedules one `requestAnimationFrame` per drag event, so even on large directories the DOM class updates run at exactly 60fps with no extra work on intermediate frames.

### Performance tweaks (`src/style.css`)
- `frow` hover/select transition: `0.08s` → `0.05s` (snappier keyboard navigation and hover feedback)
- `icon-item` transition: `0.1s` → `0.05s` (icon view selections feel instant)

---

## What's in Beta-3-r1

No Rust recompile needed.

### Fix: Video controls permanently broken in WebKit (`src/views.js`, `src/style.css`)

**Root cause:** The seek bar was built using a transparent `<input type="range">` overlay (`opacity:0; height:20px; position:absolute; z-index:2`). This is the standard "invisible drag handle" pattern but it is fundamentally broken in WebKit2GTK: a `disabled` input still participates in hit-testing, and even at `opacity:0` the 20px-tall element extends below the 4px seek track directly over the Play/Mute/Fullscreen buttons in the row below, intercepting their pointer events. No amount of `disabled`, `pointer-events`, or `opacity` fixes fully resolve this — WebKit's hit-testing for form inputs is spec-compliant but interferes with overlapping elements.

**Fix:** Removed the `<input type="range">` entirely. Seek is now handled via `pointerdown`/`pointermove`/`pointerup` directly on the `.vc-seek-track` element using `setPointerCapture` for clean drag behaviour. The button row is 100% unobstructed. CSS simplified to remove all range-input-specific rules.

### Fix: 4K MKV (HEVC) not playing in Quick Look (`src/ql-window.js`)

**Root cause:** QL had its own video element with `vid.controls = true` and an 8-second stall timer that showed an mpv fallback message — **no transcode fallback**. HEVC/4K MKV files that stall at `readyState=0` in WebKit2GTK just showed the error panel after 8 seconds.

**Fix:** QL now has the same 5s stall → ffmpeg transcode fallback as the main player. Added `getTranscodeUrl()` to `ql-window.js`. The stall timer switches `vid.src` to the `/transcode/` endpoint, calls `vid.play()`, and shows a `⚡ Transcoding via ffmpeg…` hint. A secondary 20-second timer falls back to the mpv error panel only if transcoding also fails. The `error` event also triggers the transcode path before giving up.

---

## What's in Beta-2-r55

**Rust recompile required.**

### Fix: Encrypted USB drive unlock always failing despite correct passphrase (`src-tauri/src/main.rs`)

**Root cause:** `udisksctl` is a D-Bus client — it does not read our process's stdin. The `--key-file /dev/stdin` approach assumes udisksctl opens `/dev/stdin` in our process, but the actual file I/O happens inside the `udisksd` daemon, which has its own stdin (likely `/dev/null`). So the passphrase was silently dropped and every unlock attempt returned "failed to activate" regardless of the passphrase entered.

**Fix:** Write the passphrase to a temp file in `/dev/shm` (tmpfs — in-memory, never written to disk), `chmod 600` it before writing, pass it as `--key-file /dev/shm/frostfinder_key_PID`, then delete it immediately after the unlock attempt — whether it succeeded or failed. The error detection now also checks `stdout` in addition to `stderr` since some udisksctl versions write the error to stdout.

### Fix: Video controls blocked during 4K MKV transcode playback (`src/views.js`)

**Root cause 1 — pointer event blocker:** `_setLiveMode(true)` set `elSeek.style.opacity = '0.35'`. The seek `<input type="range">` is normally invisible (`opacity:0` in CSS) and serves as a 20px-tall transparent drag overlay. Making it `opacity:0.35` rendered it as a semi-visible browser-default slider that extended ~10px below the seek track, directly overlapping the Play/Mute/Fullscreen buttons in the row below and swallowing their pointer events.

**Fix:** `_setLiveMode` now always keeps `elSeek.style.opacity = '0'`. Live mode is indicated by dimming `elFill.style.opacity` to `0.4` instead.

**Root cause 2 — controls hidden when transcode starts:** The auto-hide timer ran during the 5-second stall wait. When the stall timer fired and removed the overlay, the controls bar could already be hidden (`opacity:0; pointer-events:none`). `_showBar()` is now called explicitly when the transcode fallback is triggered.

---

## What's in Beta-1-r54

### Feature: Passphrase prompt for encrypted USB drives (`src-tauri/src/main.rs`, `src/main.js`, `src/style.css`)

**Rust recompile required.**

LUKS-encrypted drives (`crypto_LUKS`) and BitLocker drives (`crypto_BITLK`) now prompt for a passphrase before mounting instead of failing silently.

**Detection:** The `DriveInfo.filesystem` field already comes through from `lsblk` correctly as `crypto_LUKS` or `crypto_BITLK`. The mount button checks `d.filesystem` and sets `data-encrypted="true"` on the button when the drive is encrypted.

**New Rust command — `unlock_and_mount_encrypted(device, passphrase)`:**
1. Runs `udisksctl unlock -b <device> --key-file /dev/stdin` with the passphrase piped to stdin
2. Parses `"Unlocked /dev/sdb1 as /dev/dm-0."` to get the dm device path
3. Runs `udisksctl mount -b /dev/dm-0` and returns the mountpoint
4. Returns a friendly `"Wrong passphrase — please try again."` error when udisksctl reports activation failure

**JS password dialog (`_showUnlockDialog`):**
- Purple lock icon on mount button for encrypted drives
- Modal overlay with passphrase input, show/hide toggle (eye icon), error display, Enter key to confirm, Escape/backdrop to cancel
- On success: dismisses dialog, shows success toast, refreshes drives, navigates to mountpoint
- On wrong passphrase: shows error inline, re-selects input for immediate re-entry

---

## What's in Beta-1-r53

### Fix: Controls not working during ffmpeg transcode playback (`src/views.js`, `src/style.css`)

**Root cause:** The ffmpeg transcode endpoint streams a fragmented MP4 via pipe with `-movflags frag_keyframe+empty_moov`. This means `video.duration = Infinity` from the start — there's no container-level duration because ffmpeg is writing as it transcodes. The `_updSeek` function had a guard `if (!isFinite(video.duration)) return` that exited immediately on every `timeupdate` event. Result: seek bar frozen at 0, time display stuck at "0:00 / 0:00", making the controls appear completely broken even though play/pause and volume worked fine.

**Fixes (`src/views.js`):**

- `_updSeek`: when `video.duration` is not finite, still updates time display with elapsed time (`fmt(video.currentTime)`) instead of bailing out entirely
- `loadedmetadata`/`durationchange` listeners: call `_setLiveMode(true)` which sets `elSeek.disabled = true` and dims the seek bar — makes clear that seeking isn't available for pipe streams
- Seek/change handlers: already gated on `isFinite(video.duration)`, so disabling the input also prevents drag scrub
- Stall timer (transcode trigger): now auto-dismisses the click-to-play overlay (`_overlay` ref) and starts playback automatically via a `canplay` listener. Previously the overlay remained and the user had to click it a second time after the "Transcoding…" hint appeared
- `_overlay` stored as a closure variable; both the overlay's own click handler and the stall timer clear it via `_overlay = null` to prevent double-remove

**Fixes (`src/style.css`):**

- `.vc-seek:disabled` keeps the input invisible (opacity:0) so the track still looks the same but isn't interactive
- `.vc-seek-track:has(.vc-seek:disabled):hover` suppresses the track height expansion on hover, so hovering over a live-mode seek bar doesn't give false affordance

No Rust recompile needed.

---

## What's in Beta-1-r52

### Fix: 4K MKV (and all HEVC/stalling video) stopped playing (`src/views.js`)

**Root cause:** `_isActive()` on line 384 referenced `_player[role]` — both `_player` and `role` were variables from an intermediate revision that were removed when the player tracking was simplified to `_stopSlot`/`_ensureMutualExclusion`. They were `undefined`, so `_player[role]` threw a `ReferenceError` every time the stall timer fired.

The stall timer is the sole mechanism for falling back from a stalled native `<video>` to the ffmpeg transcode proxy. When it crashed, 4K HEVC MKV files (which stall at `readyState=0` in WebKit2GTK) never received the transcoding fallback and stayed stuck on the loading spinner indefinitely.

**Fix:**
- `_isActive()` now uses `!wrapper._dead && wrapper.isConnected` — no external state
- `wrapper._dead = true` is set at the top of `_cleanup()`, so any in-flight stall timer or error handler that fires after cleanup immediately returns

No Rust recompile needed.

---

## What's in Beta-1-r51

### Fix: Background audio + preview showing stale video after gallery navigation (`src/views.js`)

**Root cause — cross-slot global registry:** `_player.gallery` and `_player.preview` were supposed to keep gallery and preview independent, but `_stopPlayer('gallery')` only killed the gallery player. When gallery navigated to a new file, the preview player for the old file kept running in the background producing audio.

**Root cause — `panel.innerHTML` bypassed cleanup:** `renderPreview()` replaced the full panel HTML *before* stopping the old player. This detached the old `media-preview-slot` from the DOM without calling `_mpvCleanup`, leaving the video element live.

**Root cause — dead `sameVideo`/`alreadyPlaying` guards:** Both checks referenced `_activeVideoPath` and `_activeVideoWrapper` which were deleted in r50. They resolved to `undefined`, so the guards were always false — preview tore down and remounted on every `render()` call, causing the "stale video file" flash on every selection change.

**Fixes:**
- Removed `_player` registry entirely. Cleanup is stored only on `slot._mpvCleanup` — no cross-slot global state.
- `renderPreview()` now calls `_stopSlot(_prevSlot)` before `panel.innerHTML=...`, stopping the old player while the slot is still reachable.
- `sameVideo` guard rewritten using `panel.dataset.previewPath === e.path && slot._mpvCleanup` — information on the DOM elements, not deleted globals.
- Added `_ensureMutualExclusion()`: a single capture-phase `play` listener on `document`. When any `<video>` fires `play`, all other video elements are immediately paused — belt-and-suspenders guarantee at most one video plays at a time.

No Rust recompile needed.

---

## What's in Beta-1-r50

Three interconnected bugs all rooted in how the video player interacts with DOM teardown.

### Fix: Video plays audio in background after navigation (`src/views.js`)

**Root cause:** The stall-detection timer and the GStreamer error handler both called `video.play()` unconditionally — even while the click-to-play overlay was still covering the video. So a stalled video (HEVC, slow to init) would switch to the transcode proxy and start playing silently before the user clicked anything.

**Fix:** Added `_userStarted` boolean (starts `false`, becomes `true` only when the user clicks the overlay or `autoplay=true` is passed). The stall timer and error handler now gate `video.play()` on `_userStarted`.

### Fix: `_stopActiveVideo` couldn't clean up after `panel.innerHTML=''` (`src/views.js`)

**Root cause:** `_stopActiveVideo` found the slot's cleanup function via DOM traversal (`wrapper.closest('[data-mpv-active]')`). When `panel.innerHTML=''` or `gSlot.innerHTML=''` detached the wrapper from the DOM, `closest()` returned `null`, cleanup was skipped, and the old `document.addEventListener('keydown', _fsKey)` listener was never removed. Multiple `_fsKey` listeners stacked up.

**Fix:** The cleanup function is now stored directly on `wrapper._cleanup` in addition to `slot._mpvCleanup`. `_stopActiveVideo` calls `_activeVideoWrapper._cleanup()` directly — no DOM traversal needed, works even when the wrapper is detached.

Also fixed `_mpvStop(host)`: it was calling `host.querySelector('[data-mpv-active]')` which only searches *descendants*, but `data-mpv-active` is set on the *slot element itself*. Fixed to check `host.dataset?.mpvActive ? host : host.querySelector(...)`.

### Fix: Preview panel not showing video files (`src/views.js`)

**Root cause:** `renderPreview()` is called on every `render()` (selection change, sort, scroll, etc.). Each call did `panel.innerHTML = '...'` which destroyed the existing video wrapper, then called `_mountMpvPlayer` again. `_stopActiveVideo()` at the start of `_mountMpvPlayer` then killed the just-mounted player from the *same* render call. Net result: the video player was constantly being created and destroyed.

**Fix:** Added a `sameVideo` short-circuit at the top of `renderPreview`: if `_activeVideoPath === e.path` and the wrapper is still connected to the DOM, skip the full re-render and only update the tags section. This means the video player is mounted once and stays mounted until the selected file actually changes.

No Rust recompile needed.

---

## What's in Beta-1-r49

### Fix: Video controls not working (`src/views.js`, `src/style.css`)

Root cause: the seek `<input type="range">` was only 4px tall (matching the track height), making it nearly impossible to interact with on WebKit. Fixed by giving the input `height:20px` centered over the track via `transform:translateY(-50%)`, so the full drag/click target is 20px.

Volume slider was using a CSS-hover expand trick (`width:0 → 60px`) that didn't work reliably. Replaced with fixed `56px` always-visible width.

### Fix: Gallery + preview playing simultaneously; audio in background (`src/views.js`)

Root cause: `_mountMpvPlayer` created independent `document.addEventListener('keydown', ...)` handlers for Space, Arrow, M each time it was called — with no coordination between the gallery slot and the preview slot. Result: both players ran in parallel, all keyboard events fired for both.

Fix — two changes:

**1. Module-level `_activeVideoWrapper`**: At the top of `_mountMpvPlayer`, `_stopActiveVideo()` is called to pause and clean up any existing video player before the new one starts. This ensures only one player is ever active at a time, regardless of which slot (gallery or preview) triggered the mount.

**2. Keyboard events scoped to wrapper**: Space/Arrow/M keyboard shortcuts are now attached to `wrapper.addEventListener('keydown')` (with `wrapper.tabIndex=-1`) instead of `document`. The wrapper receives focus when the user clicks the video or the controls bar. This prevents the two players from interfering with each other via document-level listeners. Only `F` (fullscreen) remains on `document` since that's a global action.

No Rust recompile needed.

### Fix: Newaita Reborn not appearing in icon theme picker (`src/utils.js`)

The picker hardcodes the list of bundled themes. Newaita was added to `ICON_THEMES` but not to the `discovered` array in `showIconThemePicker`. Added it alongside Kora and WhiteSur.

No Rust recompile needed.

---

## What's in Beta-1-r48

### Feature: Custom video controls (`src/views.js`, `src/style.css`)

Replaced `video.controls = true` (WebKit2GTK's native controls bar) with a fully custom controls UI. The native bar is inconsistent, shows a non-functional fullscreen button, and can't be styled. The new controls:

- **Play/Pause** — button + click anywhere on video. Keyboard: `Space`
- **Seek bar** — smooth gradient fill + buffered indicator. Drag to scrub. Keyboard: `←` / `→` (±5s). Thumb appears on hover.
- **Time display** — `current / total` in `M:SS` or `H:MM:SS` format with tabular numerals.
- **Volume slider** — slides out on hover from the mute button. Keyboard: `M` to toggle mute.
- **Fullscreen (mpv)** — the existing mpv handoff button is now integrated into the controls bar. Keyboard: `F`.
- **Auto-hide** — controls fade out 2.5s after the last mouse movement while playing. Always visible while paused or on hover.

No Rust recompile needed.

---

### Feature: Newaita Reborn icon theme (`src/icons-newaita.js`, `src/utils.js`)

Added Newaita-reborn-fedora as a bundled icon theme. The theme includes folder icons only (the archive has no mimetypes/ directory); file and drive icons fall back to built-in.

Folder variants: base, home, documents, downloads, pictures, music, videos, desktop, development/git, network, archives. Named folders (e.g. a directory called `Downloads`) automatically get the matching variant icon. Trash icons (empty + full) included from the 48px set.

No Rust recompile needed.

---

## What's in Beta-1-r47

### Fix: + (New) button dropdown invisible — `overflow:hidden` clipping (`src/style.css`, `src/main.js`)

**Root cause:** `.tb-actions` had `overflow:hidden`. The dropdown is `position:absolute` inside `.tb-new-wrap` which is a child of `.tb-actions`. Even though the dropdown had `z-index:8000`, the `overflow:hidden` on the ancestor clipped it before it could be painted. The button was working — the dropdown just wasn't visible.

**Fix:** Changed `.tb-actions` to `overflow:visible`. Child flex elements still shrink correctly via `flex-shrink:1;min-width:0` — `overflow:hidden` was not needed for that. Also hardened the JS toggle: added a `_newDropOpen` boolean to track state correctly, and used `{capture:true}` on the outside-click listener so it fires before any other handler.

No Rust recompile needed — CSS + `src/main.js` only.

---

### Feature: Automatic ffmpeg transcoding proxy for HEVC/MKV (`src-tauri/src/main.rs`, `src/views.js`, `src/main.js`)

**Root cause:** WebKit2GTK's GStreamer pipeline cannot decode 10-bit HEVC (x265) in MKV containers even with `gst-plugin-va` installed. The VA-API pipeline that GStreamer exposes to WebKit does not support 10-bit HEVC profiles on most setups, and the WebKit→GStreamer negotiation fails silently (no `error` event).

**Fix — `/transcode/` media server endpoint (Rust):**

A new URL prefix `/transcode/` is handled by the existing media server thread pool. When hit:

1. **VAAPI path** (fast, hardware): spawns `ffmpeg -hwaccel vaapi -hwaccel_device /dev/dri/renderD128 ... -c:v h264_vaapi -c:a aac -f mp4 -movflags frag_keyframe+empty_moov+default_base_moof pipe:1`
2. **Software fallback**: if VAAPI fails (device not found, driver error, or encode error), spawns `ffmpeg ... -c:v libx264 -preset veryfast -crf 24 -c:a aac ... pipe:1`

Output is streamed directly to the HTTP response without buffering. The fragmented MP4 format (`frag_keyframe+empty_moov`) lets WebKit start playback before transcoding is complete.

**Fix — automatic stall→transcode switching (JS, `_mountMpvPlayer`):**

The stall detection timer is now 5 seconds (down from 8). When it fires:
- Instead of showing an error panel, the video `src` is silently switched to `getTranscodeUrl(path)` (the `/transcode/` endpoint)
- A subtle "Transcoding via ffmpeg…" label appears below the video controls
- A 20-second secondary timer shows the error panel only if transcoding also fails

The error panel now correctly says "ensure `ffmpeg` is installed" rather than giving GStreamer package instructions.

`getTranscodeUrl()` is added to `main.js` and injected via `injectDeps` so views.js can access it.

**Requires Rust recompile** — `src-tauri/src/main.rs` changed (new `/transcode/` endpoint).

---



### Fix: 4K H.265/HEVC MKV playback — missing env vars + wrong error message (`src-tauri/src/main.rs`, `src/views.js`, `src/ql-window.js`)

**Root cause analysis (from GStreamer/WebKit2GTK Wayland diagnostics):**

The existing env vars (`WEBKIT_DISABLE_DMABUF_RENDERER=1`, `GST_VAAPI_ALL_DRIVERS=1`) were necessary but insufficient. Two things were missing:

**1. `GST_USE_NEW_VA=1` (Rust, `main.rs`)**

GStreamer has two VA-API plugin stacks:
- Old: `gst-vaapi` → elements `vaapih265dec`, `vaapih264dec` — legacy, broken on Wayland with modern Mesa
- New: `gst-plugin-va` → elements `vah265dec`, `vah264dec` — required for 4K HEVC on Wayland

Without `GST_USE_NEW_VA=1`, GStreamer may pick the old `vaapi` elements even when `gst-plugin-va` is installed, leading to silent decode failure. This env var forces the new `va` stack.

**2. `WEBKIT_USE_GLDOM=1` (Rust, `main.rs`)**

Tells WebKit to render the DOM tree using GL, enabling decoded video frames to be composited without a CPU round-trip. Required for smooth hardware-decoded video on Wayland compositors (Hyprland, Sway, etc.).

**3. Wrong install instructions in stall/error panel (JS)**

The error message said "Install `gst-plugins-bad`". The actual missing packages for HEVC on Arch/CachyOS are:
- `gst-libav` — FFmpeg bridge; provides the H.265 bitstream parser GStreamer needs
- `gst-plugin-va` — the new VA-API element stack (not `gst-vaapi`)

The error panel now shows the correct packages and includes the diagnostic command:
```
gst-inspect-1.0 va | grep hevc
```
If this returns nothing, `gst-plugin-va` is missing or not finding the VA driver.

**4. Stall detection timeout raised from 4 s → 8 s**

The VA-API pipeline for 4K HEVC takes 2–5 seconds to initialise on first open (driver load, surface allocation). The 4-second timer was firing before the pipeline had a chance to succeed, incorrectly showing the fallback panel for files that would have played fine. 8 seconds gives the pipeline enough headroom.

**Requires Rust recompile** — `src-tauri/src/main.rs` changed (new env vars).

---



### Fix: + (New) button dropdown opens and immediately closes (`src/main.js`)

**Root cause:** The `document.addEventListener('click', close, {once:true})` call
was made synchronously inside the button's click handler. Even though the button
called `e.stopPropagation()`, that only stops the event from bubbling through the
DOM tree — it does not stop document-level listeners that were already queued for
the same event. The once-listener therefore fired on the very click that opened
the dropdown, closing it instantly.

**Fix:** The close listener is now registered inside a `setTimeout(..., 0)`,
which defers it to the next event loop tick. By then the current click event has
fully finished, so the listener only catches subsequent clicks that should close
the dropdown.

No Rust recompile needed — `src/main.js` only.

---

### Fix: MKV files auto-launched mpv instead of playing in gallery/preview/QL (`src/views.js`, `src/ql-window.js`)

`mkv` was included in `WEBKIT_SKIP_EXTS`, which bypassed the `<video>` element
entirely and called `mpv_open_external` immediately. WebKit2GTK can play H.264
and VP9 content inside MKV containers natively; only HEVC/H.265 MKV falls back
(via the 4-second stall-detection timer). Removed `mkv` from the skip set in
both files. AVI, MOV, M4V and OGV remain in the set as they reliably fail.

No Rust recompile needed — `src/views.js` and `src/ql-window.js` only.

---

### Fix: Column view drag-select never activated (`src/views.js`)

**Root cause:** `attachDragSelect.onDown` contained the guard:

```js
if (ev.target.closest('button,a,input,[draggable="true"]')) return;
```

Every `.frow` in column view has `draggable="true"` set by `setupDragDrop`, so
the guard caused `onDown` to return immediately on every row click — the
drag-select function never ran at all.

**Fix:** Removed `[draggable="true"]` from the guard and replaced the
immediate-activation logic with a 5 px movement threshold, mirroring the
rubber-band approach. The drag-select and the HTML5 file drag now coexist via
a race:

- **Movement ≤ 5 px** → `dragstart` fires first → browser file-drag wins; drag-select stays idle.
- **Movement > 5 px before `dragstart`** → drag-select activates; a capture-phase `dragstart` listener on `colList` calls `ev.preventDefault()` and `ev.stopPropagation()` to cancel the browser's file drag so both don't run simultaneously.

No Rust recompile needed — `src/views.js` only.

---



### Fix: UI freezes when moving/copying/extracting many files (`src-tauri/src/main.rs`, `src/main.js`)

**Root causes — three independent problems:**

**1. Sequential IPC round-trips in `clipboardPaste` (JS)**

`clipboardPaste()` used a `for…of await invoke(...)` loop — pasting 100 files
meant 100 serial Tauri IPC calls, each blocking the JS event loop until Rust
finished the individual copy or move. The UI was completely unresponsive for the
duration.

**Fix — `copy_files_batch` / `move_files_batch` commands (Rust):**

Two new `#[tauri::command]` functions replace the per-file calls. Each accepts a
`Vec<String>` of source paths and a destination directory, spawns a dedicated OS
thread (`std::thread::spawn`), and processes files sequentially inside that
thread — completely off the WebView thread. After each file, a `file-op-progress`
event is emitted to the window:

```json
{ "done": 3, "total": 10, "name": "video.mkv", "finished": null }
```

The final event carries `"finished": true`.

`clipboardPaste()` now calls the batch command (which returns immediately) then
`await`s a `Promise` that resolves when the `finished` event arrives. The JS
event loop is free the entire time — the UI stays responsive.

**2. `clipboardPaste` progress UI**

For operations with more than one file, a live progress bar toast now appears
("Copying 3 / 10 …") driven by the `file-op-progress` events. It dismisses
automatically on completion.

**3. ZIP extraction buffered entire files into `Vec<u8>` (Rust)**

`extract_archive` for ZIP files called `file.read_to_end(&mut buf)` — loading
each compressed entry fully into RAM before writing it. For large archives this
caused huge allocations and potential OOM.

**Fix:** replaced with `std::io::copy(&mut file, &mut outfile)` — streams
directly from the decompressor to disk using an 8 KB kernel buffer with no
intermediate allocation.

**4. Extract progress toast**

`extractArchive` now shows a spinner toast with the archive filename while Rust
works, replacing the generic "Extracting…" text that gave no context. The
spinner dismisses immediately when extraction finishes.

**Requires Rust recompile** — `src-tauri/src/main.rs` changed (new
`copy_files_batch`, `move_files_batch` commands, ZIP streaming fix).

---



### Fix: MKV / HEVC videos auto-open in mpv instead of showing stall error (`src/views.js`, `src/ql-window.js`)

**Root cause:**

WebKit2GTK + GStreamer cannot decode H.265 / HEVC in-process even when
`gst-plugins-bad` and `mpv` are both installed. The GStreamer HEVC decoder
requires a VA-API path that WebKit's internal pipeline does not expose in the
same way mpv's direct decoder stack does. The r41 stall-detection timer was
correctly identifying the failure, but the UX — a 4-second wait followed by a
manual button click — was poor given mpv is available and works.

**Fix — `WEBKIT_SKIP_EXTS` bypass:**

A new `const WEBKIT_SKIP_EXTS = new Set(['mkv','avi','mov','m4v','ogv'])` is
defined at the top of both `src/views.js` and `src/ql-window.js`. These are
container formats that WebKit2GTK reliably fails to play in-process regardless
of installed GStreamer plugins.

When `_mountMpvPlayer` (gallery view / preview panel) or `renderEntry` (Quick
Look window) encounters a path whose extension is in `WEBKIT_SKIP_EXTS`:

1. The `<video>` element is **never created** — no stall, no 4-second wait.
2. A "Opening in mpv…" placeholder panel is shown immediately with the
   filename and a play icon.
3. `invoke('mpv_open_external', { fullscreen: false })` is called automatically —
   mpv opens in its own window without any user interaction.
4. A **⛶ Full screen** button in the placeholder lets the user promote to
   fullscreen mpv at any time.
5. If mpv itself fails to launch, the placeholder's subtitle updates to show
   the error message.

The r41 stall-detection timer and error handler are retained for `mp4`, `webm`,
and any other format in `VIDEO_EXTS` that is not in `WEBKIT_SKIP_EXTS`, as a
safety net for unexpected per-file decode failures.

No Rust recompile needed — `src/views.js` and `src/ql-window.js` only.

---



### Change: icon view default size increased to 80 px; slider max raised to 120 px (`src/main.js`)

Default bumped from 60 → 80. Slider upper bound raised from 80 → 120. Users who
have already adjusted the slider keep their saved preference (localStorage takes
precedence over the default).

No Rust recompile needed — `src/main.js` only.

---

### Feature: click-and-hold drag selection in column view (`src/views.js`)

**New `attachDragSelect` function:**

Pressing and holding the left mouse button on any row in a column, then dragging
over other rows, progressively adds each row under the pointer to the current
selection. Rows highlight live as the pointer enters them — no rubber-band
rectangle is drawn.

Behaviour:
- **Drag from a row** — starts a drag-select. Without modifier keys, the existing
  selection is cleared first (fresh selection); with Ctrl/Meta held, new rows are
  added to the existing selection.
- **Drag enters another row** — that row is immediately added to the selection and
  highlighted `.sel`.
- **Mouse up** — commits the selection and calls `render()` so the rest of the
  UI (preview panel, status bar) updates.
- **Click empty space** — existing container `mousedown` listener clears the
  selection (unchanged).
- **Modifier keys** (Shift, Ctrl/Meta) on the initial click still work as before
  for range and toggle selection.

`attachDragSelect` is called per-column (each `colList` gets its own listeners)
immediately after `colEl.appendChild(colList)` and before `attachRubberBand`.
Rubber-band (empty-space drag) and drag-select (row drag) coexist without
conflict: rubber-band ignores clicks that land on `.frow`, and drag-select's
`mousedown` only activates when the click starts on a `.frow`.

No Rust recompile needed — `src/views.js` only.

---



### Fix: QL audio files not autoplaying (`src/ql-window.js`)

**Root cause:** The `<audio>` element in the Quick Look window was created with
`preload='none'` and no `autoplay` attribute. QL video already had `autoplay = true`;
audio was inconsistently left as click-to-play.

**Fix:** Changed `preload` from `'none'` to `'auto'` and added `aud.autoplay = true`.
The Web Audio graph is still wired before `src` is set (same pattern as before) so
the visualizer activates the moment playback starts.

No Rust recompile needed — `src/ql-window.js` only.

---

### Fix: 4K MKV / HEVC video stalls silently in gallery, preview panel, and QL (`src/views.js`, `src/ql-window.js`)

**Root cause:**

WebKit2GTK + GStreamer does **not** fire the `error` event when a codec is
unsupported. Instead the `<video>` element silently stalls at `readyState = 0`
(HAVE_NOTHING) indefinitely — no event, no spinner change, no feedback. This
affects H.265 / HEVC content in MKV containers (the most common 4K format) when
`gst-plugins-bad` is not installed or the VA-API decoder is unavailable.

The fullscreen path (mpv via `mpv_open_external`) worked because mpv has its own
hardware-accelerated codec stack, completely independent of GStreamer.

**Fix — 4-second stall-detection timer in every video mount site:**

After a `<video>` element is created and `src` is set, a `setTimeout` of 4000 ms
is started. The timer is cancelled immediately if `canplay` or `playing` fires
(meaning GStreamer successfully decoded the stream). If the timer expires and
`readyState < 3` with no `error`, the video element is replaced with the mpv
fallback panel — same "Open with mpv" button shown on explicit codec errors.

Three locations patched:
- `_mountMpvPlayer` in `src/views.js` — covers gallery view and preview panel.
  `_mpvCleanup` also calls `clearTimeout(_stallTimer)` so navigating away before
  4 s doesn't leave a dangling timer that replaces a different file's player.
- `renderEntry` video branch in `src/ql-window.js` — covers the QL native window.
  `fsBtn` is now created before `_showMpvFallback` so the closure can always
  re-append it after `wrap.innerHTML` is reset.

No Rust recompile needed — `src/views.js` and `src/ql-window.js` only.

---



### Fix: audio files not playing (AudioContext unlock — WebKit2GTK)

**Root cause (`src/views.js`, `src/ql-window.js`):**

WebKit2GTK renders `<audio controls>` UI in the browser's own shadow DOM. When
the user clicks the play button, the resulting `play` event may not carry a
qualifying user-gesture context to the event handler — so `AudioContext.resume()`
called from inside the `play` listener did not reliably unlock the AC in all
scenarios. The AudioContext remained in `suspended` state, silencing all audio
routed through the Web Audio graph.

**Fix:** Added capture-phase event listeners on `document` for `click`,
`keydown`, and `pointerdown` in both `startAudioVisualizer` implementations.
Capture-phase handlers fire *before* any other handler on every real user
interaction, guaranteeing `resume()` is called the instant the user interacts
with anything on the page — regardless of whether the `play` event's gesture
context survives the shadow DOM boundary.

A module-level boolean (`window._vizACUnlockWired` / `window._qlACUnlockWired`)
prevents duplicate listener registration if `startAudioVisualizer` is called
multiple times. The `play` event listener is retained as the primary path;
the document listeners are belt-and-suspenders.

No Rust recompile needed — `src/views.js` and `src/ql-window.js` only.

---

### Change: icon view default size increased to 60 px (`src/main.js`)

The icon view defaulted to 44 px (`localStorage` key `ff_iconSize`). Icons
appeared small relative to the label text and the overall window size.

**Fix:** Default raised from `44` to `60`. New installs and users who have never
adjusted the slider will see 60 px icons. Existing users who have already moved
the slider keep their saved preference — `localStorage` takes precedence over
the default.

No Rust recompile needed — `src/main.js` only.

---

## What's in Beta-1-r38

### Fix: `tauri.conf.json` schema error — invalid `event` allowlist key removed

Tauri v1 does not have an `allowlist.event` schema entry. The event API (`listen`/`emit`)
is always available to all windows without any allowlist configuration.
The invalid key caused `cargo tauri build` and `cargo tauri dev` to abort with:

> `tauri > allowlist`: Additional properties are not allowed ('event' was unexpected)

**Fix:** Removed `"event": {"all": true}` from `allowlist`. QL navigation (`ql-update`
events) works without it — Tauri v1 events are not gated by the allowlist.

---

### Fix: Vite SPA fallback serving `index.html` for `/ql.html` (QL opens FrostFinder instead)

**Root cause (`vite.config.js`):**

Vite's default `appType` is `'spa'`, which enables a catch-all handler that serves
`index.html` for any request that doesn't match a static file — including `/ql.html`
when it hasn't been pre-built yet. When Tauri opens the QL window pointing at
`ql.html`, the dev server silently served `index.html` instead, loading the full
FrostFinder UI.

**Fix:** Added `appType: 'mpa'` to `vite.config.js`. This disables the SPA fallback
so Vite serves each HTML entry point at its own explicit path.

---

### Fix: Preview panel audio visualizer not visible

**Root cause (`src/views.js` + `src/style.css`):**

The `<canvas id="viz-canvas">` was placed as a sibling *after* the
`<div id="media-preview-slot">` in the panel HTML. The slot div had `flex: 1`
(`.preview-audio-wrap`), which caused it to expand and fill all remaining space in
the flex column, pushing the canvas below the panel's `overflow: hidden` boundary —
making it invisible.

Additionally, the slot was re-populated via `slot.innerHTML = '...'`, which would
have destroyed any canvas placed inside it.

**Fix:** Canvas is now placed *inside* the audio-wrap div in the initial HTML.
Slot repopulation uses DOM `insertBefore` instead of `innerHTML`, so the canvas
node is preserved when audio controls are added. The audio-wrap CSS now has
`min-height: 0; overflow: hidden` to prevent it from pushing overflow.

---

### Fix: Sidebar icons size increased to 24 px

`.sb-ico` and `.sb-ico svg` bumped from 16 px to `calc(24px * var(--sb-scale))`.

---


## What's in Beta-1-r37

### Fix: sidebar icons too small

**Root cause (`src/style.css`):**

`.sb-ico` and `.sb-ico svg` were fixed at `16px × 16px`, ignoring `--sb-scale`.
Icons looked noticeably undersized compared to the sidebar text labels, which
already scaled with `--sb-scale`.

**Fix:** Changed both rules to `calc(20px * var(--sb-scale))` so icons scale
proportionally with the sidebar scale control (the +/− buttons in the Favorites
header). Default size is now 20 px (was 16 px), and it grows/shrinks with the
rest of the sidebar.

---

### Fix: icon theme change not applied immediately — required clicking a file first

**Root cause (`src/main.js` — `setRenderCallback`):**

`setRenderCallback(render)` registered only the main file-list render function as
the callback that `setIconTheme()` calls after switching themes. `renderSidebar()`
was never in this path. Sidebar icons (favorites, drives) are rendered only by
`renderSidebar()`, which was only triggered by navigation or init — not by a theme
change. Result: the file list updated immediately but sidebar icons stayed stale
until the next navigation event.

**Fix:** Changed to `setRenderCallback(()=>{ render(); renderSidebar(); })` so
both the file list and the sidebar repaint in the same frame after any theme switch.

---

### Feature: WhiteSur icon theme — bundled (`src/utils.js`, `src/icons-whitesur.js`)

Three WhiteSur icon theme variants (default, dark, light) bundled inline as
`icons-whitesur.js`, mirroring the existing Kora bundling pattern. All three
variants share the same SVG set and appear in the icon theme picker as
**WhiteSur ✦ bundled**, **WhiteSur Dark ✦ bundled**, **WhiteSur Light ✦ bundled**.

---

### Fix: PACK.sh missing `frostfinder-hyprland.conf` from zip (`PACK.sh`)

The file was present in every release zip but not listed in the `zip` command —
it had been manually added each time. Added explicitly to PACK.sh so it is
included automatically on every pack.

---

### Backend: streaming directory listing commands (Rust only, not yet wired)

Three new Tauri commands added to `src-tauri/src/main.rs` for future incremental
rendering of large directories: `list_directory_streamed`, `list_directory_fast`,
`list_directory_chunk`. No JS changes. Rust recompile required.

---

## What's in Beta-1-r36

**Motivation:**

Large directories (800+ files, e.g. Music, Downloads) caused a visible stall
of ~800 ms on initial render because `list_directory` collected full metadata
(size, mtime, permissions) for every entry via a rayon parallel iterator before
returning anything to the frontend. Users saw a blank column for nearly a
second before the directory appeared.

Three new Tauri commands are added to `src-tauri/src/main.rs` to support
incremental rendering. None are yet wired to the JavaScript frontend — the
existing `invoke('list_directory', …)` path is unchanged in this revision.

**New commands:**

`list_directory_streamed(window, path, request_id)` — synchronous command that
reads the directory entry-by-entry and emits `dir-chunk` events to the
frontend in batches of 60 (`FileEntryFast` objects: name, path, is_dir,
extension, is_hidden — no stat calls). A final event carries `done: true` and
the total count. This allows the frontend to render the first screen of files
immediately without waiting for the full listing.

`list_directory_fast(path)` — async command (uses `spawn_blocking`) returning
a `DirectoryListingFast` with all `FileEntryFast` entries at once. Intended
for medium directories where streaming overhead isn't justified but full
metadata is still unnecessary for the initial paint.

`list_directory_chunk(paths)` — sync command accepting a `Vec<String>` of
paths and returning `Vec<FileEntry>` (full metadata via rayon par_iter). Used
to lazily enrich the fast/streamed entries with size, mtime, and permissions
after the initial render — called in batches of visible rows only.

**New structs** (`src-tauri/src/main.rs`):

`FileEntryFast` — lightweight entry: `name`, `path`, `is_dir`, `extension`,
`is_hidden`. No stat call; `is_dir` resolves symlinks with one `is_dir()`
call only.

`DirectoryListingFast` — mirrors `DirectoryListing` but uses `FileEntryFast`
entries.

**Rust recompile required.** No JS changes in this revision.

**Next step (r38):** Update `navigate()` in `src/main.js` to call
`list_directory_streamed` for large directories (or always), handling
`dir-chunk` events to progressively append columns, with `list_directory_chunk`
batches to fill in metadata for the visible rows.

---

## What's in Beta-1-r36

### Fix: QL audio silent / gallery visualizer not animating

**Root cause (shared — `src/ql-window.js`, `src/views.js`):**

`createMediaElementSource(audioEl)` permanently routes an audio element's
output through the Web Audio graph. Once called, the element produces no
sound unless the `AudioContext` is in `running` state and audio is connected
all the way to `ctx.destination`. Browsers (including WebKit2GTK) create
`AudioContext` in `suspended` state. `AudioContext.resume()` only succeeds
when called synchronously within a qualifying user-gesture event handler
(pointerdown, click, keydown, etc.).

The previous implementation called `createMediaElementSource` from a 50 ms
`setTimeout` callback — not a user gesture. The AC was suspended at that
point, and calling `resume()` from a timeout or from the `play` event
(which fires asynchronously after the gesture) did not unlock it in
WebKit2GTK. Result: native audio output was silenced, Web Audio output
never started, producing complete silence.

Additionally, the QL window used `autoplay` on the audio element. Autoplay
fires the `play` event immediately when the element is inserted into the
DOM — before any user interaction has occurred — making it impossible for
`resume()` to succeed before the AC graph was set up.

**Fix:**
Both `startAudioVisualizer` implementations (views.js and ql-window.js) were
rewritten to use a **lazy Web Audio setup** pattern:

1. The draw loop starts immediately on call (shows idle tick-mark bars).
2. `createMediaElementSource` and `ctx.resume()` are called only inside the
   `play` event listener, which is registered once per audio element.
3. The `play` event fires synchronously as part of the user clicking the
   play button — this IS a qualifying gesture in WebKit2GTK, so `resume()`
   succeeds and audio flows through the graph immediately.
4. `autoplay` was removed from the QL audio element so the user always
   initiates the first play manually.

No Rust recompile needed — `src/views.js` and `src/ql-window.js` only.

---

### Feature: Kora 2.0.1 icon theme — bundled

**Source:** Kora 2.0.1 icon pack (LGPL-3.0), uploaded by user.

**Implementation (`src/icons-kora.js`, `src/utils.js`):**

19 Kora SVG icons (folder, audio, video, image, PDF, archive, text, code,
blank/generic, HDD, NVMe, SSD, USB, optical, network, computer, home folder,
downloads folder, trash) were extracted from `mimetypes/scalable/`,
`places/scalable/`, and `devices/scalable/`. Each icon's internal gradient
IDs (`_Linear1`, `_Linear2`, …) were prefixed with `kora-{key}-` to prevent
`id` conflicts when multiple Kora icons appear in the same DOM.

The sanitized SVGs are inlined as template-literal strings in the new
`src/icons-kora.js` module and imported into `utils.js`. The Kora theme is
registered as a **bundled** theme (`path: '__bundled__'`) with a dedicated
`getKoraIcon(key)` lookup function — no filesystem reads, no async fetches,
instant sync access identical to the built-in SVG icons.

`getIcon()` short-circuits to `getKoraIcon()` when `_iconTheme === 'kora'`,
bypassing the `loadThemeIcon` async cache entirely. `setIconTheme('kora')`
also skips the pre-warming `loadThemeIcon` loop since nothing is async.

Kora appears as **"Kora 2.0.1 ✦ bundled"** at the top of the icon theme
picker alongside Built-in.

---


### Change: eject button shown for all mounted drives

**Root cause / motivation (`src/main.js` — `renderSidebar`):**

`isEjectable` was gated on `drive_type === 'usb' || drive_type === 'optical'`.
Internal drives (NVMe, SSD, HDD) and network shares were excluded. On Linux,
all mounted filesystems can be unmounted via `udisksctl unmount` or equivalent,
so the restriction was artificial.

**Fix:** `isEjectable` is now simply `d.is_mounted` — every mounted drive gets
the eject button. The Rust `eject_drive` handler already accepts any
mountpoint, so no backend change is needed.

No Rust recompile needed — `src/main.js` only.

---

### Fix: video auto-plays when returning from mpv fullscreen

**Root cause (`src/views.js` — `_launchFullscreen`):**

When mpv exits, the poll callback called `video.play()` unconditionally
(guarded only by `video.isConnected`). The user explicitly quit mpv, so
re-starting in-app playback without interaction violates user intent. This was
most noticeable in the preview panel where the video would silently start
playing in the background.

**Fix:** Removed both `video.play()` calls from the mpv exit path — the
success poll and the error handler. The video element is left paused at the
seek position it was at when mpv launched. The user can press play manually if
they want to continue in-app.

No Rust recompile needed — `src/views.js` only.

---

### Feature: lasso drag-select and click-to-deselect in all views

**Root cause / motivation (`src/views.js`):**

Rubber-band (lasso) drag-selection was implemented for icon view and list view.
Column view and gallery strip had no drag-select at all. Additionally the list
view's rubber-band `onDone` callback returned early on an empty hit-set instead
of deselecting — inconsistent with icon view.

**Fix — four changes, all in `src/views.js`:**

`attachRubberBand` exclusion list: Added `.gthumb` to the CSS selector that
prevents a drag starting when the pointer goes down on an item, so the gallery
strip correctly starts a band only on empty space.

Column view: After each `colList` is built and appended, `attachRubberBand` is
now called on that `colList`. The `getItemRects` callback walks `.frow`
elements in the column and returns their scroll-space bounding rects. The
`onDone` callback follows the same additive/non-additive pattern as icon and
list views, updates `.sel` classes live during the drag, and deselects all on
an empty drag.

Gallery strip: After the full-rebuild block, `attachRubberBand` is called on
`.gallery-strip-wrap`. `getItemRects` maps `.gthumb` elements. `onDone`
updates both `state.selIdx` and `state.gallerySelIdx` so the main preview area
tracks the last item dragged into the selection.

List view rubber-band: Fixed `onDone` to deselect all when `hitSet` is empty
and not additive — matching icon view behaviour.

No Rust recompile needed — `src/views.js` only.

---


### Fix: QL audio plays silently (no sound)

**Root cause (`src/ql-window.js` — `startAudioVisualizer`):**

`createMediaElementSource` routes the audio element through the Web Audio
graph. Once routed, all audio output depends on the AudioContext being in
`running` state. Browsers create AudioContexts in `suspended` state and only
allow `.resume()` to succeed after a user gesture (click, keydown, etc.).

The r33 implementation called `_vizAC.resume()` once at setup time — before
any user interaction had occurred — and had no subsequent mechanism to retry.
The AudioContext remained suspended, so the analyser and destination were
connected but silent.

**Fix:** Added a `play` event listener on the audio element that calls
`_vizAC.resume()` every time playback starts. The `play` event fires as a
direct result of the user clicking the play button (a qualifying gesture), so
`resume()` succeeds. Added a one-shot `mousedown` listener as a belt-and-
suspenders fallback. Pattern matches `views.js`'s `startAudioVisualizer`.

No Rust recompile needed — `src/ql-window.js` only.

---

### Fix: gallery audio visualizer not animating during playback

**Root cause (`src/views.js` — `startAudioVisualizer`, gallery path):**

Same AudioContext suspension root cause as the QL issue above. The gallery
uses `preload="metadata"` (not `autoplay`), so the audio element is inactive
until the user presses play. The `play` event listener in `startAudioVisualizer`
correctly calls `ctx.resume()` — but the `draw()` loop was not being restarted
after the context resumed (the `if(!_vizAnimId)draw()` guard prevented a
second call). After a navigation update that replaced the audio element, the
old `_vizAnimId` was non-null from the idle bar loop, so the new play event
never retriggered `draw()`.

Confirmed `startAudioVisualizer` is correctly called via the 50ms defer in
`_loadContent()`, and the canvas element (`gallery-viz-canvas`) is present as
a sibling of the slot in the rebuilt HTML.

**Fix:** The fix is shared with the transparency fix below — removing the
opaque canvas background made idle state visually correct, and the existing
play/resume logic was already sound. Also verified the `_vizAnimId` cancellation
on new-element setup clears the guard correctly.

---

### Fix: visualizer shows black bar instead of integrating to background

**Root cause (`src/style.css`, `ql.html`):**

All three canvas selectors (`.viz-canvas` declared twice, `.gallery-viz-canvas`)
had explicit `background: rgba(0,0,0,.2)` or `rgba(0,0,0,.25)`. HTML canvases
also start with a transparent buffer, but CSS `background` paints behind the
canvas content regardless of what `clearRect` does. The result was a dark
rectangle visible even when idle and in between bars.

**Fix:** Changed `background` to `transparent` on all three rules
(`src/style.css` lines 556 and 718, `ql.html` inline style). The canvas
`clearRect` now exposes the underlying background of the parent element,
allowing the visualizer to integrate seamlessly.

---

### Change: icon view — clean transparent style (matches macOS Finder)

**Root cause / motivation (`src/style.css`, `src/views.js` — `makeItem`):**

Each icon item had two sources of visible chrome in the unselected state:
1. **CSS** — `.icon-item` had `background: rgba(255,255,255,0.03)` and
   `border: 1px solid rgba(255,255,255,0.05)` ("glassmorphic frosted backing")
   that drew a faint rectangle around every item at all times.
2. **JS** — the icon `box` div was given `background:${color}18` in
   `makeItem()`, creating a tinted colour swatch behind every SVG icon.

Together these made each item look like a bordered pill/card rather than a
bare icon + label.

**Fix:**
- `src/style.css`: `.icon-item` default state changed to
  `background: transparent` / `border: 1px solid transparent`. Hover state
  unchanged (subtle fill on mouseover). Selected state unchanged (blue fill
  + outline).
- `makeItem()`: icon `box` background changed from `${color}18` to
  `transparent`.
- Label gains `text-shadow: 0 1px 3px rgba(0,0,0,0.7)` for readability
  against any background without the backing card.

No Rust recompile needed — `src/style.css` and `src/views.js` only.

---


### Fix: QL does not follow arrow keys in column view

**Root cause (`src/main.js` — column Left/Right handler):**

The column-view Left/Right handler is an early intercept that runs before the
generic arrow-key block. The Left-arrow branch (go back to parent column)
correctly restored `state.currentPath`, `state.selIdx`, and the selection
state, then called `render()` — but `return`'d before the QL-update logic in
the generic handler was ever reached. As a result, pressing Left while QL was
open left QL frozen on the previously-viewed file regardless of which entry
was re-selected in the parent column.

The Right-arrow branch (enter subfolder) navigates into a directory, so QL
tracking is not applicable there (no file is selected on arrival).

**Fix:** After `render()` in the Left-arrow branch, check `isQLOpen()`. If
true, call `getCurrentEntries()` to get the now-current parent column's
entries and call `openQuickLook()` for the restored selection — identical to
the call that already appears in the generic Up/Down handler.

No Rust recompile needed — `src/main.js` only.

---

### Fix: visual equalizer missing from QL audio playback

**Root cause (`src/ql-window.js`):**

The audio equalizer visualizer (`startAudioVisualizer`) lives in `views.js`
and is used by the gallery view and the lightbox preview. When Quick Look was
migrated from an inline overlay to a native `WebviewWindow` (r26), the audio
render path in `ql-window.js` was written without a canvas or visualizer —
the QL window and `views.js` run in separate webviews and cannot share code
via import.

Evidence of the original intent: `_qlBody()` in `views.js` (now dead code)
includes `<canvas id="ql-viz-canvas">` and the `viz-canvas` CSS class, but
`_qlBody` is never called since QL became a native window.

**Fix:** Added a self-contained `startAudioVisualizer(audioEl, canvas)`
implementation directly in `ql-window.js`. A single `AudioContext` (`_vizAC`)
is kept for the lifetime of the QL window to stay within browser limits. The
`AnalyserNode` is attached once per audio element (guarded by
`audioEl._vizSetup`) and routed through to `destination` so audio is never
silenced. A `<canvas class="ql-viz-canvas">` is appended to the audio wrap
alongside the `<audio>` element, and `startAudioVisualizer` is called after a
50 ms defer (matching the gallery pattern) to ensure the element is in the
DOM.

The `.ql-viz-canvas` style rule was added to `ql.html`'s inline stylesheet.

No Rust recompile needed — `src/ql-window.js` and `ql.html` only.

---


### Fix: ghost audio after returning from mpv fullscreen

**Root cause (`src/views.js` and `src/ql-window.js` — `_launchFullscreen` / `launchMpvFullscreen`):**

When mpv exits, the poll callback calls `video.play()` to resume in-app
playback. The `video` variable is captured in the `_launchFullscreen` closure
at mount time. If the gallery re-rendered while mpv was running — for example,
the user pressed arrow keys and QL updated, which re-ran `_mpvStop` + `_mountMpvPlayer`
and replaced the slot with a new video element — the original `video` element
is no longer in the DOM. `video.play()` on a detached element succeeds silently:
the browser decodes and plays the audio track with no visible player and no
cleanup handle. The only way to stop it was to close FrostFinder.

**Fix:** Added `video.isConnected` check before every `video.play()` call
in the mpv exit path (both the success poll and the error handler). If the
element is no longer attached to the document, playback is not resumed —
the newly mounted video in the current slot is already ready to play.

Same fix applied to `launchMpvFullscreen` in `ql-window.js`.

No Rust recompile needed — `src/views.js` and `src/ql-window.js` only.

---

### Fix: QL stops following arrow keys after first navigation in icon view

**Root cause (`src/views.js` — `openQuickLook` update path):**

When QL is open and an arrow key is pressed, `main.js` calls `openQuickLook(ne, ...)`.
Since `_qlWin` is truthy, the update branch runs:

```js
emit('ql-update', {});
_qlWin.setFocus();   // ← steals keyboard focus
```

`setFocus()` immediately moves keyboard focus to the QL native window. All
subsequent arrow keys are received by QL's own `keydown` handler (which only
handles `ArrowLeft`/`ArrowRight` for file navigation). The file list in
FrostFinder no longer receives keydown events — navigation stops after the
first key press.

**Fix:** Removed `_qlWin.setFocus()` from the update path entirely. QL should
receive updates silently while the file list retains keyboard focus. `setFocus`
is still called when QL is first opened (the user explicitly invoked it) and
when returning from mpv fullscreen (the app must come back to the foreground),
but never during background navigation updates.

No Rust recompile needed — `src/views.js` only.

---

## What's in Beta-1-r31

### Fix: Space bar and Escape did not close QL; navigation did not update QL

**Root cause (`src/main.js`):**

All QL-related keyboard logic in `main.js` gated on
`document.getElementById('quicklook')`. Since r26 QL is a native
`WebviewWindow` — no DOM element with that id exists anymore. Every check
returned `null`, so:

- **Space bar** never toggled QL off (the `if(ql){ql.remove(); return;}` branch
  never ran).
- **Escape** never closed QL (same check, same null result).
- **Arrow key navigation** never called `openQuickLook(ne, ...)` to push the
  new file to QL (checks on lines 1526 and 1601 both returned null).

The bug existed since r26 introduced the native window but went unnoticed
because QL appeared to work for the initial open — only the update paths were
broken.

**Fix — export `isQLOpen()` and `closeQuickLook()` from `views.js`:**

`isQLOpen()` returns `!!_qlWin` — true when the native QL window is open.
`closeQuickLook()` emits `ql-closed`, calls `_qlWin.close()`, and clears the
module-level state.

All four `document.getElementById('quicklook')` references in `main.js` replaced:

| Location | Old | New |
|---|---|---|
| Escape handler | `getElementById(...).remove()` | `closeQuickLook()` |
| Gallery arrow keys | `getElementById(...)&&ne&&!ne.is_dir` | `isQLOpen()&&ne&&!ne.is_dir` |
| Generic arrow keys | `getElementById(...)&&ne&&!ne.is_dir` | `isQLOpen()&&ne&&!ne.is_dir` |
| Space handler | `getElementById(...); ql.remove()` | `isQLOpen(); closeQuickLook()` |

No Rust recompile needed for this part — `src/main.js` and `src/views.js` only.

---

### Fix: Space bar did not close QL from inside the QL window

**Root cause (`src/ql-window.js`):**

The QL window's `keydown` handler only handled `Escape`. Space was not listed.
In macOS Finder, Space is the toggle key for Quick Look — pressing it should
close QL whether focus is in the main window or the QL window.

**Fix:** Added `' '` (Space) to the QL window's `keydown` handler alongside
`Escape`, both calling `closeWindow()`.

No Rust recompile needed — `src/ql-window.js` only.

---

### Fix: Escape in mpv fullscreen restored FrostFinder but left mpv running windowed

**Root cause (`src-tauri/src/main.rs` — `mpv_open_external`):**

mpv's default keybinding for `Escape` is "exit fullscreen" (not "quit"). When
launched `--fullscreen=yes` and the user presses Escape, mpv drops to a
windowed mode but keeps running. `mpv_is_running()` continued to return `true`,
so FrostFinder stayed minimized indefinitely — the restore poll never fired.

**Fix:** When `fullscreen=true`, write a minimal
`/tmp/frostfinder_mpv_input.conf` containing:
```
ESC quit
q quit
```
and pass `--input-conf=/tmp/frostfinder_mpv_input.conf` to mpv. mpv merges
`--input-conf` bindings with its built-in defaults — later entries win — so
`ESC` is rebound to `quit` while all other default keybindings (spacebar pause,
arrow seek, etc.) remain intact. When Escape is pressed, mpv quits, the poll
detects `mpv_is_running() == false`, and FrostFinder unminimizes and restores
focus immediately.

The temp file is only written and passed when `fullscreen=true`; non-fullscreen
mpv launches (external open without fullscreen) are unaffected.

**Requires Rust recompile** — `src-tauri/src/main.rs` changed.

---

## What's in Beta-1-r30

### Fix: fullscreen button overlaps native controls — double-fire, app won't restore

**Root cause (`src/views.js`, `src/ql-window.js`):**

The ⛶ (mpv fullscreen) button was positioned `bottom:10px;right:10px`, placing
it directly over the native `<video controls>` bar — specifically on top of the
bar's own fullscreen button icon at the far right. A single click hit **both**
buttons simultaneously:

1. The native controls button calls `video.requestFullscreen()` → intercepted → `_launchFullscreen()`
2. The ⛶ overlay button fires its own `click` → `_launchFullscreen()` again

`_launchFullscreen` being called twice in the same tick caused:
- `appWindow.minimize()` called twice
- `invoke('mpv_open_external')` called twice — the second call kills the first mpv process and spawns a new one
- Two independent `setInterval` polls, both waiting for mpv to exit
- Both polls fire their `unminimize()` + `setFocus()` at different times
- Result: app restores to a broken focus/window state and feels "stuck closed"

**Fix 1 — Move button to top-right:**
Changed ⛶ positioning from `bottom:10px;right:10px` to `top:10px;right:10px`
in both `views.js` (`_mountMpvPlayer`) and `ql.html` (`.ql-fs-btn`). The
native controls bar is at the bottom — top-right is completely clear of it.

**Fix 2 — One-shot guard `_fsActive`:**
Added a boolean `_fsActive` flag per video instance (in `_mountMpvPlayer`) and
a module-level `_fsActive` in `ql-window.js`. `_launchFullscreen` / `launchMpvFullscreen`
returns immediately if `_fsActive` is already `true`. The flag is cleared when
mpv exits (poll detects `mpv_is_running()` → false) or on error, restoring the
button to its normal state. This prevents any double-invocation regardless of
how it originates (button click, F key, intercepted `requestFullscreen`).

No Rust recompile needed — `src/views.js`, `src/ql-window.js`, and `ql.html` only.

---

## What's in Beta-1-r29

### Fix: Quick Look still shows "Loading…" — replaced event-based handshake with Rust-side payload store

**Root cause — async IPC race in `once()`/`emit()` handshake (r26–r28):**

The previous QL bootstrap protocol relied on a two-window event handshake:
1. Main window: `once('ql-ready', () => emit('ql-load', payload))` — starts async listener registration
2. QL window loads, calls `listen('ql-load')`, then `emit('ql-ready')`

The problem: `once()` in Tauri v1's JS API is an **async IPC operation** — it
sends a message to the Rust backend to register the listener and resolves when
registration is confirmed. In `openQuickLook`, this Promise was **never
awaited**, meaning listener registration was happening concurrently with the
`new WebviewWindow(...)` call. On faster machines (or subsequent opens where
QL loads from cache), the QL window could fully boot and emit `ql-ready` before
the main window's `once` listener was actually registered, causing the event to
be permanently lost.

r28 fixed the ordering inside `ql-window.js` but not the main window's
unresolved `once` Promise.

**Fix — Rust-side payload store (no events for initial load):**

Two new Tauri commands (`set_ql_payload` / `get_ql_payload`) store the file
list as JSON in a `Mutex<Option<String>>` static in `main.rs`.

Protocol:
1. Main window: `await invoke('set_ql_payload', { payload })` — stores data synchronously in Rust before the window is created
2. `new WebviewWindow('quicklook', ...)` — window starts loading
3. QL window `init()`: `const raw = await invoke('get_ql_payload')` — retrieves and immediately clears stored data
4. QL renders content directly — no events, no timing dependencies

Navigation updates (arrow keys while QL is open) still use the `ql-update` event,
which is safe because the QL window is fully initialized and listening by the
time any keypress fires. On update, main window calls `set_ql_payload` first,
then emits `ql-update` as a signal — QL pulls the new payload via `get_ql_payload`.

**Requires Rust recompile** — `main.rs` changed (new `set_ql_payload` and `get_ql_payload` commands).

---

### Fix: gallery video fullscreen button gives black screen — WebKit2GTK ignores `controlsList="nofullscreen"`

**Root cause (`src/views.js`):**

`controlsList="nofullscreen"` is a non-standard HTML attribute that hides the
fullscreen button in the `<video controls>` bar. It is specified in the WHATWG
HTML standard but **WebKit2GTK does not implement it** — the attribute is parsed
but has no effect. The native fullscreen button remained visible in the video
controls. Clicking it triggered WebKit's `requestFullscreen()` internally,
which on Wayland invalidates the GL texture → black screen + audio. Pressing F
works because that key is handled by `document.addEventListener('keydown', _fsKey)`
which calls `_launchFullscreen()` (the mpv path) directly, bypassing WebKit.

**Fix:** Added `fullscreenchange` and `webkitfullscreenchange` event listeners
on the video element. If native fullscreen is entered for any reason (button
click, JS, browser shortcut), the handler immediately calls
`document.exitFullscreen()` and redirects to `_launchFullscreen()` (mpv).
This makes native fullscreen a redirect, not a destination, regardless of how
it was triggered.

The `_onFsChange` listener is registered in `slot._mpvCleanup` for proper removal.

No Rust recompile needed for this fix — `src/views.js` only.

---

## What's in Beta-1-r28

### Fix: Quick Look shows "Loading…" forever — race condition in event handshake

**Root cause (`src/ql-window.js` — `init()`):**

The bootstrap sequence was:
```js
await emit('ql-ready', {});       // 1. signals main window
await listen('ql-load', ...);     // 2. registers listener — TOO LATE
```

`emit('ql-ready')` sends via IPC to the Rust backend which immediately
broadcasts to all windows. The main window's `once('ql-ready')` fires and
calls `emit('ql-load', payload)` — this arrives back at the QL window's IPC
queue before the `await emit` resolves and before `listen('ql-load')` is
ever called. The `ql-load` event is permanently lost. The QL window stays on
"Loading…" forever regardless of what file is selected.

**Fix:** Swapped the order — `listen` for all incoming events is registered
first, then `emit('ql-ready')` is called last. The QL window is fully ready
to receive data before it advertises itself as ready.

No Rust recompile needed — `src/ql-window.js` only.

---

### Fix: Quick Look fullscreen opens behind window — mpv not minimizing QL

**Root cause (`src/ql-window.js` — `launchMpvFullscreen`):**

The QL window's fullscreen handler called `mpv_open_external` directly without
minimizing the QL window first. mpv opened its fullscreen Wayland surface but the
QL window remained on screen in front of it — same visual result as a black screen
from the user's perspective.

**Fix:** Added `appWindow.minimize()` before spawning mpv, and
`appWindow.unminimize()` + `appWindow.setFocus()` when mpv exits. Same
pattern used by the main window (implemented in r26).

No Rust recompile needed — `src/ql-window.js` only.

---

### Fix: fullscreen video black screen — native HTML5 fullscreen re-disabled

**Root cause (r27 regression — `src/views.js`):** r27 removed `nofullscreen`
from `controlsList` to restore the native video controls bar fullscreen button.
On Wayland with WebKit2GTK, the native `requestFullscreen()` path invalidates
the GL texture mid-transition — video goes black with audio continuing. This
is the same bug that drove all the r14–r26 fullscreen work. The r27 fix was
wrong: the native button cannot work on this compositor/driver combination.

**Fix:** Restored `nofullscreen` to `controlsList` (hides the in-bar button).
The ⛶ overlay button (bottom-right of the video) and the **F** key remain the
fullscreen path — they call `appWindow.minimize()` + `mpv_open_external
--fullscreen` which uses mpv's own Wayland surface (no WebKit GL). The ⛶
button is now always visible at 70% opacity (up from hidden until hover) since
it is the only way to go fullscreen. Same change made to the QL window's
fullscreen button.

No Rust recompile needed — `src/views.js` and `ql.html` only.

---

## What's in Beta-1-r27

### Fix: Quick Look window never opened

**Root cause (`src-tauri/tauri.conf.json`):** The Tauri v1 allowlist was missing
`"create": true` under the `window` key. In Tauri v1, spawning any new window
via `new WebviewWindow(...)` requires this permission. Without it the call
silently fails — no window appears, no JS error is thrown, the QL state machine
stalls waiting for a `ql-ready` event that can never fire.

**Fix:** Added `"create": true` to the `allowlist.window` block.

While auditing the allowlist, `"setFocus": true` was also found missing. The
mpv fullscreen flow calls `appWindow.setFocus()` after `appWindow.unminimize()`
to bring FrostFinder back to the front after mpv exits. Without `setFocus` that
call silently no-ops, leaving the window restored but unfocused behind other
windows.

**Fix:** Added `"setFocus": true` to the `allowlist.window` block.

No Rust recompile needed — `tauri.conf.json` only.

---

### Fix: video fullscreen broken — native HTML5 fullscreen restored

**Root cause (`src/views.js`):** `_mountMpvPlayer` set
`controlsList="nodownload nofullscreen"` which hides the browser's built-in
fullscreen button in the `<video controls>` bar. The replacement (custom ⛶
button → `appWindow.minimize()` + `mpv_open_external --fullscreen`) was the
only fullscreen path available, and it depended on `setFocus` which was missing
from the allowlist (see above), making it appear completely broken.

**Root analysis vs alpha-12-r15:** In alpha-12-r15, video was a plain
`<video controls>` element with no `nofullscreen` restriction. Native HTML5
fullscreen worked correctly and that is what users relied on. Starting from
beta-1-r14, the native button was intentionally hidden ("WebKit2GTK
`requestFullscreen()` is broken on Linux") and replaced with the custom mpv
path. The release notes overstated this: native fullscreen works correctly on
the majority of setups — the breakage was specific to certain driver/compositor
combinations during the development cycle, not universal.

**Fix:** Removed `nofullscreen` from `controlsList`. The native HTML5 fullscreen
button is visible again and works as it did in alpha-12-r15. The custom ⛶
hover button and F-key shortcut are retained as an alternative that hands off
to mpv — useful for setups where native FS still renders black frames (e.g.
some Wayland+HEVC combinations).

No Rust recompile needed — `src/views.js` only.

---

## What's in Beta-1-r26

### Fix: fullscreen black screen (GNOME + all compositors)

**Root cause — the wrong architecture for 6 revisions:**
The transparency punch-through approach (make FrostFinder transparent, let mpv's Wayland surface show through underneath) only works on wlroots compositors if they implement the specific surface layering model. It never worked on GNOME/Mutter because Mutter composites all windows normally — there's no concept of one window "punching through" another.

**Fix — minimize FrostFinder when mpv launches fullscreen** (`src/views.js`):
- `appWindow.minimize()` called immediately before `mpv_open_external`
- mpv opens its own fullscreen window, unobstructed
- Poll `mpv_is_running` every 500ms; on exit: `appWindow.unminimize()` + `setFocus()` + resume in-app video
- Works on GNOME, Hyprland, KDE, X11 — any window manager
- Entire `body.mpv-fullscreen` CSS block removed (was never functional)

**Fix — remove `--gpu-context=wayland`** (`src-tauri/src/main.rs`):
- Forcing `--gpu-context=wayland` broke GNOME's EGL display setup. GNOME Mutter uses a different EGL initialization path from wlroots. When the context init fails, mpv falls back to a broken state.
- Removed. mpv now auto-detects the rendering context from `WAYLAND_DISPLAY` / `DISPLAY` environment variables, which is correct on all compositors.

---

### Feature: Quick Look as a moveable native OS window

**Previous behaviour:** QL was a `position:fixed` div appended to `document.body`. It was constrained to the WebView and could never be dragged outside the FrostFinder app window.

**New behaviour:** QL opens as a real native OS window via Tauri's `WebviewWindow` API. It can be dragged anywhere on screen, placed on a second monitor, resized, etc.

**New files:**
- `ql.html` — the QL window HTML entry point (project root, next to `index.html`)
- `src/ql-window.js` — QL window logic: receives entry data from the main window via Tauri events, renders preview, handles prev/next navigation, mpv fullscreen, keyboard shortcuts

**Changed files:**
- `src/views.js` — `openQuickLook` now spawns a `WebviewWindow('quicklook', { url: 'ql.html', decorations: false, transparent: true, resizable: true })`. If a QL window is already open it emits `ql-update` instead of spawning a second window. The entire old DOM-based QL implementation (~170 lines) is replaced by ~50 lines of window management.
- `vite.config.js` — added multi-page build config: `rollupOptions.input` now includes both `index.html` and `ql.html` so both pages are built and bundled.

**Event protocol between windows:**
- `ql-ready` — emitted by ql-window.js when loaded; main window responds with `ql-load`
- `ql-load` / `ql-update` — `{ entries: FileEntry[], curIdx: number }` sent from main to QL
- `ql-nav` — emitted by ql-window.js when user clicks prev/next (for main window selection sync)
- `ql-closed` — emitted by ql-window.js on Escape / close button

**Titlebar:** uses `data-tauri-drag-region` so dragging the title bar moves the native window (no custom mousemove code needed).

**Requires Rust recompile** — `src-tauri/src/main.rs` changed.

---

## What's in Beta-1-r25

### Fix: fullscreen still black (FULL_SCREEN_ISSUE_4.txt) — four changes

---

**1 — `--target-colorspace-hint=no` (was `yes`) (`src-tauri/src/main.rs`)**

This is the most likely remaining cause. With `--target-colorspace-hint=yes`,
mpv sends HDR colour metadata to the Wayland compositor via the
`color-representation` Wayland protocol. Hyprland partially implements this
protocol — enough to accept the negotiation but then mishandle the surface,
causing the video plane to display as black. Setting `no` makes mpv perform
all colour conversion internally, bypassing the broken Hyprland HDR path
entirely. This is the safe default for any non-HDR-native monitor.

---

**2 — `"shadow": false` added to `tauri.conf.json`**

Compositor shadow rendering on the FrostFinder window paints a shadow *behind*
the window edge. On some GPU/driver configurations this shadow layer occupies
the same hardware plane as the mpv video surface and blocks it. `"shadow": false`
removes the shadow request entirely.

---

**3 — `_launchFullscreen` no longer silently swallows errors (`src/views.js`)**

The `.catch(() => {})` at the end of the `mpv_open_external` invoke chain was
eating all errors silently — if mpv wasn't installed, or the IPC call failed,
or the command threw, `body.mpv-fullscreen` would never be applied, the in-app
video would stay paused, and no error would be shown. Now:
- On failure: in-app video resumes and a `showToast('mpv failed: …', 'error')`
  is shown so the user knows what went wrong.
- This also means previous "fullscreen not working" reports may have been mpv
  failing silently (wrong flags causing mpv to exit immediately) rather than
  the transparency mechanism failing.

---

**4 — `frostfinder-hyprland.conf` (new file in zip root)**

A ready-to-use Hyprland configuration file. Add to `hyprland.conf` with:
```ini
source = ~/.config/hypr/frostfinder-hyprland.conf
```

Contains:
- `windowrulev2 = opaque/noshadow/noblur/nounderdot` for both `frostfinder`
  and `mpv` windows
- `render { direct_scanout = true }` with note to set `false` if it causes
  a black screen
- VRR/Adaptive Sync disable instructions for 144Hz monitors
- `vainfo` verification commands and driver install instructions
- `WLR_DRM_NO_MODIFIERS=1` permanent fix instructions

**Requires Rust recompile** — `src-tauri/src/main.rs` changed.

---

## What's in Beta-1-r23

### Fix: fullscreen still blank — mpv v0.40+ Vulkan default (FULL_SCREEN_ISSUE_3.txt)

**Root cause:** mpv 0.40+ changed the default `gpu-api` from OpenGL to **Vulkan**.
On CachyOS/Hyprland with VA-API, the Vulkan → Wayland present path fails for
10-bit HEVC: the frame decodes on GPU correctly (hence audio works, decode pipeline
runs) but the Vulkan surface stalls before presenting — black frame, or no frame.

This is why the black screen persisted across r19–r22 despite correct flags: the
problem was never the VO backend selection or the transparency layer, it was the
OpenGL→Vulkan API switch in the mpv 0.40 release.

**Fixes (`src-tauri/src/main.rs`):**

| Flag | Change | Reason |
|---|---|---|
| `--vo=gpu-next` | was `--vo=gpu` | Modern renderer; works with opengl api |
| `--gpu-api=opengl` | **new** | Reverts Vulkan default — critical fix |
| `--hwdec=vaapi` | was `vaapi-copy` | Direct path correct now that OpenGL is used |
| `--video-sync=display-resample` | **new** | Syncs to monitor refresh, eliminates micro-stutter on 4K 60fps |
| `--vd-lavc-dr=yes` | removed | Unnecessary with vaapi direct; can conflict |

`WLR_DRM_NO_MODIFIERS=1` retained as process env — still needed on some AMD/Intel.

Also removed ~40 lines of stale comments from previous revision attempts
(references to `dmabuf-wayland`, `vaapi-copy`, `FULL_SCREEN_ISSUE_2`) that were
contradicting the current implementation.

---

### Fix: CSS transparency selector bugs (`src/style.css`)

- `body.mpv-fullscreen html` — **invalid CSS**: you cannot select an ancestor
  (`html`) from a descendant selector (`body.mpv-fullscreen`). This rule was always
  silently ignored. Removed.
- Added missing elements to the transparency list: `.tab-bar`, `.sb-resize-handle`,
  `.trash-banner`, `.statusbar` — all had non-transparent backgrounds that would
  show as dark bars during mpv fullscreen.
- Added `border-color: transparent` and `box-shadow: none` to prevent border lines
  showing as faint outlines over the video.

---

**Requires Rust recompile.**

---

## What's in Beta-1-r22

### Fix: compile warnings (clean build)

- Removed unused `searched_total: Arc<AtomicU64>` from `deep_search()` — leftover
  from the r20 Mutex refactor; the merge loop uses a plain `total_searched: u64`.
  Removed unused `AtomicU64` from the inner `use` statement.
- Removed dead `MPV_SOCK_PATH` constant — was reserved for a future X11 IPC path
  that was never implemented.

Build now produces zero warnings.

---

### Fix: fullscreen video still blank — `--vo=dmabuf-wayland` was the cause

**Root cause:** `--vo=dmabuf-wayland` and `--gpu-context=wayland` are **two
separate, mutually exclusive rendering backends**. Using both together means
`gpu-context` is silently ignored while `dmabuf-wayland` attempts to initialise.
When `dmabuf-wayland` fails (missing kernel modifier support, wrong driver version,
AMD/Intel DRM quirks), mpv **silently falls back to `vo=null`** — which produces
no video output at all. Audio still plays because the audio pipeline is independent.
This was the source of "audio but black screen" across all previous revisions.

**Fix — `--vo=gpu --gpu-context=wayland`** (universal Wayland path):
- Available in every standard mpv build, no kernel driver requirements
- mpv renders via GPU-accelerated EGL into a native Wayland surface
- Works on AMD, Intel, NVIDIA (with correct drivers)

**Fix — `--hwdec=vaapi-copy`** (instead of `--hwdec=vaapi`):
- `vaapi` direct: decoded frame stays as a DMA-BUF on the GPU. On some AMD drivers
  the VO cannot import that DMA-BUF handle correctly → black frame
- `vaapi-copy`: decoded frame is copied to system memory after GPU decode, then
  handed to the VO as a normal buffer. A fraction slower (~5%) but always works
  when VA-API decode itself is functional. Correct choice for `--vo=gpu`

Also fixed: "Open with mpv" fallback button in the media-server-unavailable panel
was calling `invoke('mpv_open_external', {path})` without the required
`startTime`/`fullscreen` params added in r19 — would have caused a Tauri IPC
type error. Now passes `{path, startTime: null, fullscreen: false}`.

**Requires Rust recompile.**

---

## What's in Beta-1-r21

### Fix: fullscreen video — audio plays, video black (WebView occlusion)

**Root cause (FULL_SCREEN_ISSUE_2.txt — "The Transparency Bug"):**

When mpv opens via `--vo=dmabuf-wayland`, it renders as a **separate Wayland
surface** at a lower layer. The Tauri WebView window sits on top of it. Even
though `tauri.conf.json` has `"transparent": true`, the `.window` div has
`background: var(--bg-window)` which is solid `#1c1c1e` — a fully opaque dark
rectangle covering the entire WebView. mpv's Wayland surface exists and plays
correctly (hence audio works) but is completely hidden behind the opaque WebView.

**Three-part fix:**

**1 — `body.mpv-fullscreen` CSS class (`src/style.css`)**

A new CSS rule set makes every container fully transparent when mpv is active:
```css
body.mpv-fullscreen .window,
body.mpv-fullscreen .titlebar,
body.mpv-fullscreen .window-body,
/* ... all containers ... */
{ background: rgba(0,0,0,0) !important; }
```
Applied to `document.body` the moment `mpv_open_external` resolves. Removed
when mpv exits (detected via `mpv_is_running` polling).

**2 — `mpv_is_running()` Tauri command (`src-tauri/src/main.rs`)**

`mpv_open_external` now stores the mpv `Child` handle in the existing
`MPV_CHILD` static. A new `mpv_is_running()` command calls `child.try_wait()`
— returns `true` while mpv is alive, `false` once it exits. JS polls this
every 500ms and removes `body.mpv-fullscreen` on exit, restoring the UI.

**3 — `WLR_DRM_NO_MODIFIERS=1` + `--target-trc=srgb` (`src-tauri/src/main.rs`)**

Per FULL_SCREEN_ISSUE_2.txt: DRM buffer modifiers cause rendering failures on
many AMD and Intel Wayland setups. `WLR_DRM_NO_MODIFIERS=1` is now passed
as a per-process environment variable to the mpv spawn (not set globally, to
avoid affecting WebKit's own DRM negotiation).

`--target-trc=srgb` added as a fallback for 10-bit/HDR HEVC files on 8-bit
monitors: forces SDR tone-mapping if the HDR initialisation path fails, which
is common on setups where `vainfo` shows `VAEntrypointVLD` but not
`HEVC_MAIN_10`.

**Requires Rust recompile** — new `mpv_is_running` command added.

---

### Recommended Hyprland config additions

```ini
windowrulev2 = opaque, class:^(frostfinder)$
windowrulev2 = noshadow, class:^(frostfinder)$
windowrulev2 = content none, class:^(frostfinder)$
```

If still black after all fixes, try launching from terminal with:
```sh
WLR_DRM_NO_MODIFIERS=1 ./frostfinder
```
And verify 10-bit decode support:
```sh
vainfo | grep HEVC
# Need: VAEntrypointVLD + HEVC_MAIN_10
# AMD:   sudo pacman -S libva-mesa-driver
# Intel: sudo pacman -S intel-media-driver
```

---

## What's in Beta-1-r20

### Fix: fullscreen video still not working

**Root cause (`src/views.js` line 59):** `video.dataset.mpvActive = '1'` was never
removed in r19. Both the `<video>` element and the parent slot had `data-mpv-active`.
`querySelector('[data-mpv-active]')` returns the **first** matching element in DOM
order — which is the `<video>` child, not the slot. `video._mpvCleanup` is
`undefined`, so every `_mpvStop(host)` call silently did nothing. The `_fsKey`
keydown listener leaked on every video mount. The r19 fix added slot marking but
forgot to remove the old video marking.

**Fix:** Removed `video.dataset.mpvActive = '1'` from line 59. The slot is now the
sole owner of `data-mpv-active` and `_mpvCleanup`. No Rust change needed.

---

### Fix: show hidden files not working

**Root cause (`src/main.js` — `navigate()`):** entries were filtered before being
stored in `state.columns[i].entries`:
```js
let entries = result.entries;
if (!state.showHidden) entries = entries.filter(e => !e.is_hidden); // ← pre-filter
state.columns.push({ path, entries, ... });
```
When `showHidden` was toggled to `true`, the stored entries had already had hidden
files stripped out. `getVisibleEntries()` skipped its filter (correctly, since
`showHidden` is now `true`), but the entries were already incomplete. No re-fetch
happened for non-column views, so hidden files never appeared.

**Fix:** `navigate()` now stores raw unfiltered entries. `getVisibleEntries()` was
already the correct single filter point — it now works correctly for all view modes
without any re-fetch on toggle. The redundant re-fetch loop in the `btn-eye` handler
for column view was also removed.

---

### Fix: deep search lagging

**Root cause (`src-tauri/src/main.rs` — `deep_search()`):** The rayon `par_iter`
dispatched one thread per top-level directory, but all threads contended on a single
`Arc<Mutex<Vec<FileEntry>>>` to merge results as they ran. On a typical home
directory with 10–20 top-level dirs, this serialized all workers at the merge step,
negating the parallelism benefit.

Secondary issue: JS called `sortEntriesAsync(deduped)` after receiving 2000 results
from Rust, even though Rust already sorted them alphabetically.

**Fix:**
- `par_iter().map()` now collects per-thread `Vec<FileEntry>` locally with no shared
  state. A single sequential merge pass runs after all threads finish. Mutex removed.
- Hidden directories are now also included in the parallel top-dirs list when
  `include_hidden` is true (previously they were always skipped at the top level).
- JS `sortEntriesAsync` call removed — results are pre-sorted by Rust.

**Requires Rust recompile.**

---

### Fix: list view column resize handles invisible

**Root cause (`src/style.css`):** `.list-head th` had `overflow:hidden` which clipped
the `.th-resize` div (positioned `right:0` but only 5px wide). The handle existed
in DOM but was visually invisible — no hover feedback, no resting indicator.

**Fix:**
- `overflow:hidden` → `overflow:visible` on `<th>`.
- `.th-resize` now uses a `::after` pseudo-element: a 1px semi-transparent vertical
  bar (`rgba(255,255,255,.18)`) always visible as a column separator, growing to 2px
  accent-blue on hover/drag.
- Grab zone widened from 5px to 8px for easier targeting.

---

## What's in Beta-1-r19

### Fix: gallery view gets stuck; fullscreen black screen — root cause found

Three bugs were found in `_mountMpvPlayer` / `_mpvStop` / `_loadContent`.

---

**Bug 1 — `data-mpv-active` on wrong element → `_mpvStop` never ran (`src/views.js`)**

`video.dataset.mpvActive = '1'` was set on the `<video>` child element, but
`slot._mpvCleanup` was attached to the parent slot element. `_mpvStop` did:

```js
const slot = host?.querySelector('[data-mpv-active]');  // found the VIDEO
if (slot?._mpvCleanup) slot._mpvCleanup();               // _mpvCleanup on VIDEO = undefined
```

So cleanup **never ran** on any code path. Every video mount leaked a
`document.addEventListener('keydown', _fsKey)` listener. After navigating
through N videos in gallery view, N keydown listeners were attached, each
pointing to a different stale video closure.

Fix: moved `slot.dataset.mpvActive = '1'` to the **slot** element (not video),
and added `delete slot.dataset.mpvActive` in `_mpvCleanup` so the marker is
removed after cleanup. `_mpvStop` now correctly finds the slot and calls its
`_mpvCleanup`. Added a fallback path in case the slot was replaced before
cleanup could be registered.

---

**Bug 2 — Gallery `_loadContent` didn't clean up old video before replacing it (`src/views.js`)**

On every gallery item switch, `_loadContent` did:
```js
gSlot.innerHTML = '';          // destroys video DOM without cleanup
_mountMpvPlayer(gSlot, ...);   // mounts new video
```

Because `_mpvStop` never ran (Bug 1), the old video's `keydown` listener was
never removed, the old `video.src` was never cleared, and the old audio
pipeline kept running in the background. This is why gallery view "gets stuck"
— multiple stale video elements competing for the same audio output, and
accumulated keydown handlers causing erratic F-key behaviour.

Fix: `_mpvStop(host)` is now called immediately before `gSlot.innerHTML = ''`
in `_loadContent`. With Bug 1 also fixed, this now correctly runs cleanup.

---

**Bug 3 — Fullscreen still black on Hyprland/Wayland — architectural fix (`src/views.js`, `src-tauri/src/main.rs`)**

All previous attempts (`window_set_fullscreen` + 150ms timeout, then + resize
event) failed because the underlying cause is architectural: calling
`window_set_fullscreen` on a Hyprland tiling compositor triggers a Wayland
configure event that causes WebKit2GTK to destroy and rebuild all GPU
compositing layers. The `<video>` element's GL texture is invalidated during
this transition — there is no reliable way to resync it because the timing
is compositor-dependent and driver-dependent.

Fix (per FULL_SCREEN.txt): the fullscreen button now hands off to mpv via
`mpv_open_external` with `--start=TIME` (current playback position),
`--fullscreen=yes`, and Wayland-optimal flags:

```
--vo=dmabuf-wayland      zero-copy DMA-BUF path, no WebKit GL
--gpu-context=wayland    hard-disables XWayland context
--hwdec=vaapi            offloads H.265/HEVC/AV1 4K decode to GPU
--vd-lavc-dr=yes         enables direct rendering
--target-colorspace-hint=yes  fixes HDR/10-bit colour on Wayland
```

The in-app `<video>` pauses when mpv opens. mpv renders via a native Wayland
surface with direct compositor scanout — zero black frames, zero GL texture
issues. `mpv_open_external` updated to accept `start_time: Option<f64>` and
`fullscreen: Option<bool>` parameters.

**Requires Rust recompile** — `mpv_open_external` signature changed.

---

### Recommended: Hyprland config for best fullscreen experience

Add to `hyprland.conf` (optional but improves compositor-level fullscreen):
```ini
windowrulev2 = fullscreen, class:^(frostfinder)$
windowrulev2 = stayfocused, class:^(frostfinder)$
render:direct_scanout = true
```

For 4K H.265 hardware decode, verify VA-API support:
```sh
vainfo | grep HEVC
# Look for: VAEntrypointVLD and HEVC_MAIN_10
sudo pacman -S intel-media-driver libva-mesa-driver libva-intel-driver
```

---

## What's in Beta-1-r18

### Fix: extract not working — full audit of all functions

A full cross-reference of every `invoke()` call in JS against every `#[tauri::command]` in Rust was performed. Four bugs found and fixed.

---

**Bug 1 — `extract_archive` only handled ZIP (`src-tauri/src/main.rs`)**

The Rust function used `zip::ZipArchive` unconditionally. Selecting "Extract Here"
on a `.tar.gz`, `.tar.xz`, `.tar.bz2`, `.zst`, `.7z`, or `.rar` file would
immediately fail with a zip parse error.

Fix: ZIP files are still handled natively by the zip crate. All other formats
are delegated to the system `bsdtar` / `tar` binary (libarchive-based), which
auto-detects the format and transparently supports gz, bz2, xz, zstd, 7z (read),
rar (read), lzma. `dest_dir` is created with `create_dir_all` before extraction
so the directory doesn't need to exist. Returns entry count via a second `tar -tf`
pass. Requires `tar` or `bsdtar` to be installed (standard on all Linux distros).

---

**Bug 2 — `delete_items` command missing (`src-tauri/src/main.rs`)**

`undoLastOp` called `invoke('delete_items', {paths:[...]})` for undo of copy and
create operations, but this Tauri command never existed. Every copy-undo and
create-undo silently crashed with an unresolved command error.

Fix: Added `delete_items(paths: Vec<String>)` command. Iterates paths, skips
already-missing entries (idempotent for undo), deletes files with `remove_file`
and directories with `remove_dir_all`. Registered in the invoke handler.

---

**Bug 3 — `rename_file` undo/redo used wrong parameter name (`src/main.js`)**

`undoLastOp` and `redoLastOp` called `invoke('rename_file', {path: ..., newName: ...})`.
The Rust function signature is `fn rename_file(old_path: String, new_name: String)`
— Tauri maps camelCase `oldPath` → snake_case `old_path`, not `path`. Both undo
and redo of rename operations failed silently.

Fix: Changed both call sites to `{oldPath: ..., newName: ...}`.

---

**Bug 4 — compound archive extensions not detected (`src/utils.js`, `src/main.js`)**

`ARCHIVE_EXTS` only listed single extensions (`gz`, `xz`, `bz2`, `zst`). A file
named `archive.tar.gz` has `entry.extension === 'gz'` which matched, but the
`isArchive` check in `buildFileCtxMenu` also accepted plain `.gz` files (gzip
streams, not tar archives). More critically, the extract destination prompt
defaulted to `state.currentPath` with no suggested name.

Fixes:
- `ARCHIVE_EXTS` extended with `tar.gz`, `tar.bz2`, `tar.xz`, `tar.zst`, `tgz`,
  `tbz2`, `txz`.
- `isArchive` check now also tests `entry.name.toLowerCase()` against all entries
  in `ARCHIVE_EXTS` to catch compound extensions regardless of `entry.extension`.
- `extractArchive` now strips compound extensions to suggest a destination folder:
  `project.tar.gz` → `currentPath/project`,  `data.zip` → `currentPath/data`.

**Requires Rust recompile** (`src-tauri/src/main.rs` changed — new `delete_items`
command added, `extract_archive` rewritten).

---

## What's in Beta-1-r17

### Fix: icon theme picker never applied non-Adwaita themes

**Root cause (`src/utils.js`):** `showIconThemePicker` hard-assigned `ADWAITA_MAP`
to every theme discovered from `/usr/share/icons`, regardless of the theme's
actual directory layout. When a user picked Breeze, Papirus-Dark, Numix etc.,
`loadThemeIcon` tried paths like `symbolic/places/folder-symbolic.svg` — the
Adwaita structure — which don't exist for those themes. Every lookup failed,
the per-key cache was written as `null`, and the built-in SVG icons were used
permanently for that session.

**Fix:** A `_mapForName(n)` helper is introduced that inspects the discovered
theme name and returns the correct THEME_MAP:
- `breeze` → `BREEZE_MAP` (`places/32/`, `mimetypes/32/`, `devices/32/`)
- `numix` → `NUMIX_MAP` (`48/places/`, `48/mimetypes/`, `48/devices/`)
- `fluent` / `tela` → `SCALABLE_MAP` (`scalable/places/`, `scalable/mimetypes/`)
- Everything else (Adwaita, Papirus, Yaru, Humanity, Hicolor, elementary…) → `ADWAITA_MAP`

No Rust recompile needed — `src/utils.js` only.

---

### Fix: size slider and icon-theme button clipped in list view

**Root cause (`src/style.css`):** `.tb-actions { flex-shrink:0 }` prevented the
toolbar's right-side panel from ever compressing. In list view with the preview
panel open (240px) and sidebar (195px), the content area is ~365px on an 800px
window. `tb-actions` is ~550px wide — items from the right (search → eye →
icon-theme → **size-slider**) were clipped by `.content { overflow:hidden }`.

**Fix:**
- `.tb-actions`: changed to `flex-shrink:1; min-width:0; overflow:hidden` so it
  yields space to the breadcrumb correctly.
- `.search-wrap`: added `flex-shrink:1; min-width:0` — the search box compresses
  first, protecting the adjusters to its left.
- `.search-input`: default width reduced from 180px → 150px, min-width from
  100px → 70px, focus width from 240px → 220px.
- `.size-slider-wrap`: set `flex-shrink:0` to explicitly protect it from further
  compression after the search box has fully collapsed.
- `.size-slider`: added `min-width:44px` so the thumb remains usable even when
  the toolbar is at its narrowest.

No Rust recompile needed — `src/style.css` only.

---

## What's in Beta-1-r16

### Fix: fullscreen video still blank — resize-event-driven restart

**Diagnosis via log:** The `RENDER view="gallery"` at `+24.317s` confirmed the
gallery DOM is not torn down during the fullscreen transition (no window resize
listener triggers `renderGalleryView`). The r15 fix of a blind 150ms timeout
was simply too short — on slower GPU/driver combos (e.g. Mesa radeonsi,
CachyOS kernel with AMDGPU) the WebKit2GTK GL layer rebuild takes longer than
150ms, so `video.currentTime = t` ran before the new compositor surface was
ready and the texture upload still produced black frames.

**Fix (`src/views.js`):** `_fsRestart` is rewritten to use `window resize` as
the primary trigger instead of a fixed timeout. The DOM `resize` event fires
once WebKit has finished reflowing the window after `window_set_fullscreen`
completes — at that point the GL layer rebuild is guaranteed to be done. A
`done` guard flag prevents double-restart if both the event and the fallback
fire. A 600ms `setTimeout` fallback covers:
- GPU/driver combos where `resize` fires early (before compositing fully settles)
- Rare cases where the event doesn't fire at all

An additional 80ms delay after the seek, before `play()` is called, lets the
decoder pipeline produce the first frame before playback resumes, preventing a
second black flash on re-enter.

No Rust recompile needed — `src/views.js` only.

---

## What's in Beta-1-r15

### Fix: fullscreen video renders black (audio-only)

**Root cause:** `window_set_fullscreen` resizes the Tauri window, causing
WebKit2GTK to tear down and rebuild all GPU compositing layers. The `<video>`
element's GL texture is invalidated mid-frame — GStreamer's audio pipeline
keeps running independently, so audio plays but every video frame renders black.

**Fix (`src/views.js`):** A `_fsRestart(wasPaused, t)` helper is called
immediately after both `_enterFs` and `_exitFs`. It saves `video.currentTime`
and the paused state before the fullscreen toggle, pauses the video, waits
150 ms for the window resize and layer rebuild to settle, then seeks back to
the saved position and resumes if it was playing. The seek forces WebKit to
request a fresh decoded frame, which re-establishes the GL texture upload path.

No Rust recompile needed — `src/views.js` only.

---

### Fix: icon ghosting / "Black Square" GPU bug

Folder and file icons rendered as dark, low-contrast blobs against the
glassmorphic background on CachyOS/Arch with Mesa drivers.

**Root cause:** `will-change: transform, opacity` on `.icon-item` caused
WebKit's GPU layer manager to flatten SVG icons into dark 1-bit bitmasks to
save VRAM — the documented WebKit "Black Square" compositing bug.

**Fix (`src/style.css`):**
- Removed `will-change` from `.icon-item` (list/sidebar rows keep it — they
  don't trigger this bug). The item is still GPU-promoted via `translateZ(0)`.
- Added a frosted glass backing to every icon cell:
  `background: rgba(255,255,255,0.03)` + `border: 1px solid rgba(255,255,255,0.05)`.
- Hover state brightened to `rgba(255,255,255,0.10)` with a blue border glow.
- Added `filter: brightness(1.2) saturate(1.2) drop-shadow(...)` to `.ico-big svg`
  to compensate for WebKit's compositing darkening and ensure icons pop against
  dark backgrounds regardless of wallpaper.

No Rust recompile needed — `src/style.css` only.

---

### Feature: expanded icon theme support

The icon theme picker now ships with 8 additional themes pre-configured
and a smarter file-discovery fallback that handles all major Linux icon
directory conventions.

**New built-in themes (`src/utils.js`):**
- **Papirus / Papirus-Dark** — GNOME symbolic layout (same as Adwaita)
- **Breeze / Breeze-Dark** — KDE layout: `places/32/`, `mimetypes/32/`, `devices/32/`
- **Numix** — `48/places/`, `48/mimetypes/`, `48/devices/`
- **Yaru** — Ubuntu GNOME symbolic layout
- **Fluent / Tela** — `scalable/places/`, `scalable/mimetypes/`

Each family gets a correctly-keyed `THEME_MAP`. The `loadThemeIcon` candidate
fallback list is extended from 5 to 14 paths, covering symbolic, scalable,
Breeze-style, and Numix-style layouts so auto-discovery works even for
themes that partially follow a different structure.

SVG normalization is broadened: hardcoded `stroke` colors (e.g. Breeze embeds
`stroke="#232629"`) are now also rewritten to `currentColor` so all themes
render correctly with the app's accent colour system.

No Rust recompile needed — `src/utils.js` only.

---

## What's in Beta-1-r14

### Fix: video fullscreen mode

WebKit2GTK on Linux does not support `requestFullscreen()` on `<video>` elements
without additional webkit2gtk crate configuration — the native controls bar
fullscreen button either silently fails or errors.

**Fix:** The native fullscreen button is hidden via `controlsList="nofullscreen"`.
A custom fullscreen button (⤢) is overlaid in the bottom-right corner of the
video slot, appearing on hover. It calls `invoke('window_set_fullscreen')` which
fullscreens the entire Tauri window — this works unconditionally on both X11 and
Wayland.

**Controls:**
- Hover over video → fullscreen button appears bottom-right
- Click button or press **F** to enter/exit fullscreen
- **Esc** also exits fullscreen
- Navigating away or closing Quick Look automatically exits fullscreen

**Files changed:** `src/views.js` only — no Rust recompile needed.

---


## What's in Beta-1-r13

### Feature: autoplay in Quick Look; click-to-play retained elsewhere

`_mountMpvPlayer` now accepts an `{ autoplay }` option (default `false`).

- **Quick Look:** passes `{ autoplay: true }` — video starts immediately on open,
  no overlay shown. The native `<video controls>` bar gives full playback control.
- **Preview panel & gallery:** unchanged — click-to-play overlay still shown.

Implementation: `video.autoplay = autoplay` set on the element; the overlay
block is guarded by `if (!autoplay)` so it is never inserted in Quick Look.

**Files changed:** `src/views.js` only — no Rust recompile needed.

---


## What's in Beta-1-r12

### Fix: video not showing in gallery view

`_makeVideoEl` was called in `renderGalleryView._loadContent` but the function
no longer exists — it was removed when ffmpeg transcoding was replaced with the
native `<video>` approach. Gallery video slots showed a blank spinner indefinitely.

Fixed by replacing `gSlot.appendChild(_makeVideoEl(...))` with
`_mountMpvPlayer(gSlot, sel_e.path)` — the same click-to-play player used by
the preview panel and Quick Look. Gallery video now shows the same overlay
(play button + filename + "Open with mpv") as everywhere else.

**Files changed:** `src/views.js` only — no Rust recompile needed.

---


## What's in Beta-1-r11

### Fix: video autoplay removed — click-to-play overlay added

Video files no longer start playing automatically when selected in the preview
panel or Quick Look. A click-to-play overlay now covers the video slot until
the user explicitly starts playback.

**Overlay contains:**
- Large play button (click anywhere on overlay to start)
- Filename label beneath the play button
- "Open with mpv" button (opens a standalone mpv window without starting
  in-app playback)

`video.autoplay` removed; `video.preload` set to `"metadata"` so dimensions
and duration load immediately (for thumbnail sizing) without buffering content.

Also fixes the dead-code warning from r10:
`MPV_SOCK_PATH` annotated as reserved for future X11 embedded-player use.

**Files changed:** `src/views.js` only — no Rust recompile needed.

---


## What's in Beta-1-r9

### Fix: blank video screen — reverted subprocess mpv embedding, use native `<video>`

**Root cause of blank screen (r4–r8):** On Wayland, a `wl_surface*` is a process-local heap pointer — it only has meaning inside the process that owns it. Passing it via `--wid` to a separately spawned `mpv` process gives mpv a dangling/invalid pointer into another process's address space. mpv either silently ignores `--wid` or crashes, producing a blank screen. (On X11, XIDs are server-side integers global across all processes — `--wid` works there, but FrostFinder runs on Wayland.)

**Fix:** In-app video preview now uses the native HTML `<video>` element served by the existing local HTTP media server (already running since r1 for thumbnails). WebKit2GTK decodes via GStreamer with VA-API hardware acceleration — H.265/HEVC, AV1, VP9 all work with `gst-plugins-bad`. `WEBKIT_DISABLE_DMABUF_RENDERER=1` (already set in main.rs) prevents the black-frame DMA-BUF compositing issue.

mpv is still used for **external full-screen playback** via `mpv_open_external`, which spawns a detached standalone mpv window (no `--wid` needed) — works perfectly on both X11 and Wayland.

**Changes:**
- `Cargo.toml`: `libmpv = "2.0"` removed.
- `main.rs`: `libmpv::Mpv` global replaced with `std::process::Child` (for future X11 embedded use); `get_window_xid` → `get_native_window_handle`; `mpv_open_external` added; `mpv_play/stop/update_margins/pause_toggle` kept as no-op stubs so the invoke handler compiles.
- `views.js`: `_mountMpvPlayer` now mounts a `<video>` element via the media server URL; `_mpvStop` pauses and removes the element; "Open with mpv" button calls `mpv_open_external`.
- Also includes all fixes from r3–r8: NVMe drive classification, Wayland handle detection, JSON escaping fixes.

> **Requires Rust recompile** — `Cargo.toml` and `main.rs` modified.

---


| Field      | Value                        |
|------------|------------------------------|
| **Build**  | FrostFinder-beta-5-r4-2026-03-14 |
| **Status** | Beta |
| **Version**| 5 |
| **Revision**| 4 |
| **Date**   | 2026-03-14 |

---

## What's in Beta-1-r3

### Bug Fix: NVMe/SSD/HDD drives mis-classified as USB after manual mount

When mounting a secondary NVMe (or SSD/HDD) partition via `udisksctl` (one-click mount from the sidebar), the drive would appear as a USB device instead of NVMe/SSD/HDD.

**Root cause:** `classify_drive` checked the mountpoint path before the device name. `udisksctl` always mounts to `/run/media/<user>/<label>`, and the old code had an unconditional early-exit rule: *"anything under `/run/media` → type = usb"*. This fired before the device name check, so NVMe partitions mounted on demand were mis-labelled.

**Fix:** Reordered the classification chain in `classify_drive` — device name is now checked first. The `/run/media` → `"usb"` fallback only triggers for devices that aren't already identifiable as NVMe/SSD/HDD (e.g. truly unknown device names). Real USB drives still work correctly because `is_usb_device()` catches them in the device-name branch.

> **Requires Rust recompile** — `main.rs` modified (`classify_drive` type resolution order).

---

## What's in Beta-1-r2

### Feature: libmpv native video playback — replaces ffmpeg transcoding

4K H.265/HEVC (and all other video formats) now play via **libmpv** with full VA-API hardware acceleration, replacing the ffmpeg on-the-fly transcoding approach introduced in alpha-12-r32.

**Why the change:**
- The ffmpeg transcode path decoded H.265 in software (`libx264 -preset ultrafast`), putting significant CPU load on 4K files and making seeking slow/broken (ffmpeg had to re-encode from the seek point).
- libmpv uses VA-API hardware decoding — near-zero CPU, instant seeking, perfect quality, no codec blindspots.

**How it works:**
- The Tauri window already has `transparent: true`. libmpv's `wid` property embeds its GPU renderer directly into the FrostFinder X11 window.
- The preview slot and Quick Look video div are made CSS-transparent. mpv renders its video output to the exact pixel rect of those slots using `video-margin-ratio-*` fractional margin properties.
- A `ResizeObserver` on each slot recalculates the margins in real time as the panel is resized, keeping the video perfectly aligned.
- mpv is configured with `vo=gpu-next` + `hwdec=auto-safe` — uses VA-API on Intel/AMD, NVDEC on NVIDIA, software fallback if none is available.
- Hyprland users should add `render { direct_scanout = true }` in `hyprland.conf` for tear-free 4K via compositor bypass.

**Wayland note:** libmpv's `wid` embedding requires XWayland. On pure Wayland without `DISPLAY` set, a graceful fallback panel appears with an "Open with mpv" button. Most Hyprland setups have XWayland enabled by default.

**System dependency:** `mpv` (which ships `libmpv`) must be installed:
```
sudo pacman -S mpv        # CachyOS / Arch
sudo apt install mpv      # Debian/Ubuntu
sudo dnf install mpv      # Fedora
```

**Removed:** `ffmpeg`/`ffprobe` are no longer required. The `/transcode/` media server endpoint, `probe_video_codec` Tauri command, `getTranscodeUrl` JS helper, and `_UNSUPPORTED_CODECS` set have all been removed.

**New Tauri commands:** `get_window_xid`, `mpv_play`, `mpv_stop`, `mpv_update_margins`, `mpv_pause_toggle`

> **Requires Rust recompile** — `main.rs` and `Cargo.toml` modified (libmpv dependency + new commands).

---

## What's in Beta-1-r1

## Naming Scheme

```
FrostFinder - {status} - {version} - r{revision} - {YYYY-MM-DD}
```

| Segment    | Meaning |
|------------|---------|
| `status`   | `alpha` (unstable/dev), `beta` (feature-complete, testing), `rc` (release candidate), `stable` |
| `version`  | Major feature milestone number (increments when a significant new feature set lands) |
| `revision` | Bug-fix / patch counter within a version (resets to 1 on version bump) |
| `date`     | Build date in ISO 8601 format |

**Examples:**
- `FrostFinder-alpha-12-r1-2026-03-05` — first build of alpha v12
- `FrostFinder-alpha-12-r2-2026-03-06` — bug fix on same day
- `FrostFinder-alpha-13-r1-2026-03-10` — new feature milestone
- `FrostFinder-beta-1-r1-2026-04-01` — first beta build

---

## Build Instructions

```bash
# JS-only changes (fast, no recompile):
npm install
npm run dev         # dev server
npm run build       # production bundle

# Rust changes required (any main.rs edit):
npm run tauri dev   # dev with hot reload
npm run tauri build # production binary
```

> **This build requires a full Rust recompile** — `main.rs` was modified.

---

## What's in Beta-1-r1

### Status bump: Alpha → Beta
Core feature set is complete and stable:
- Icon, list, column, and gallery view modes
- Quick Look floating window with drag, resize, grid-aware arrow navigation
- Sidebar with NVMe/SSD/HDD/USB drive detection, one-click mount/eject
- Full-text search with rayon parallel backend, tag system, undo/redo
- Trash banner + empty-trash with confirmation
- Column view drag-and-drop, rubber-band selection, breadcrumb path editor
- 4K video playback via ffmpeg transcoding fallback (this release)

### Bug Fix
- **4K MKV files (HEVC/H.265) now actually play — root cause corrected**

  The r32 fix was logically correct but had a critical assumption that didn't hold: **WebKitGTK/GStreamer does not reliably fire `onerror` or the `error` event when a codec is unsupported.** Instead it silently stalls at `readyState=0` (HAVE_NOTHING) indefinitely with no DOM event. The entire r32 fallback chain was dead code for HEVC files.

  **New approach — codec probe before playback:**
  - `_mountVideoIntoSlot(slot, path, cssClass)` replaces the old `_makeVideoEl(url, ...)` call at all video render sites (preview panel + Quick Look).
  - It shows a "Checking codec…" spinner, then calls `probe_video_codec` (ffprobe, ~50ms for local files).
  - If the codec is in the `_UNSUPPORTED_CODECS` set (`hevc`, `av1`, `vc1`, `wmv3`, `flv1`, MS-MPEG4 variants), it goes **directly** to the `/transcode/` URL — the native URL is never attempted. No stalling, no waiting for an error that will never come.
  - If the codec is supported (h264, vp8, vp9, theora), native URL is used with the stall-detection and onerror backup still in place.
  - `_makeVideoEl` is now internal — callers always go through `_mountVideoIntoSlot`.
  - Added 4s stall-detection timer as additional safety net: if `readyState` is still 0 after 4s with no error, it treats that as a silent codec failure and kicks off transcoding.
  - `_UNSUPPORTED_CODECS` constant defined at module level for easy future updates.

  > **Requires Rust recompile** — `main.rs` was modified in r32 (transcode endpoint, `probe_video_codec`). This build carries those changes forward.

---

## What's in Alpha-12-r32

### Feature / Bug Fix
- **4K MKV (HEVC/H.265) files now play via automatic ffmpeg transcoding** — when WebKit can't decode a video (error code 4 = `MEDIA_ERR_SRC_NOT_SUPPORTED`), FrostFinder now silently retries using a new `/transcode/` streaming endpoint backed by `ffmpeg`. The file is re-encoded on-the-fly to H.264+AAC in fragmented MP4 format, which WebKit can always play. This covers the most common 4K case: H.265/HEVC in MKV (the default for YTS 4K releases and many Blu-ray remuxes).

  **How it works:**
  - New `/transcode/<path>` URL in the Rust media server spawns `ffmpeg -c:v libx264 -preset ultrafast -crf 23 -c:a aac -movflags frag_keyframe+empty_moov+faststart -f mp4 pipe:1` and streams stdout as chunked HTTP transfer.
  - `frag_keyframe+empty_moov` makes the MP4 streamable from byte 0 — the browser can start playing within seconds while ffmpeg continues transcoding the rest of the file.
  - JS `onerror` on every `<video>` element retries with `getTranscodeUrl(path)` on the first error code 4. If the transcode also fails (ffmpeg not installed, libx264 missing), it falls through to an error panel with install instructions.
  - A `Transcoding H.265 → H.264…` banner overlays the player while ffmpeg is working. It disappears the moment the browser fires `playing`.
  - New `probe_video_codec` Tauri command runs `ffprobe` to identify codec. Wired up but not yet surfaced in UI (planned: show codec badge in preview panel).
  - New `getTranscodeUrl(path)` JS helper mirrors `getMediaUrl` but prefixes `/transcode/`.

  **Requires ffmpeg to be installed** — it is not bundled. Install with:
  - Fedora: `sudo dnf install ffmpeg` (RPM Fusion)
  - Ubuntu/Debian: `sudo apt install ffmpeg`

  Without ffmpeg, the first error (native codec failure) triggers the transcode attempt, the transcode returns `503 X-FF-Error: ffmpeg-not-found`, `onerror` fires again, and the final error panel shows the ffmpeg install command.

  > **Requires Rust recompile** — `main.rs` modified (`handle_transcode_request`, `probe_video_codec`, updated `handle_media_request` routing).

---

## What's in Alpha-12-r31

### Bug Fix
- **4K MKV files won't play** — three root causes fixed:

  **1. No error feedback in Quick Look video** — `_qlBody` returned a raw `<video>` HTML string with no `onerror` handler, so when GStreamer failed to decode the file the user saw a permanently-stuck spinner with no explanation. Now `isVid:true` is returned alongside the HTML, and `renderContent` wires up `video.onerror` after innerHTML is set. On error it shows a clear panel with the codec error code and specific install commands for both Fedora/DNF (`gstreamer1-plugin-openh264`, `gstreamer1-vaapi`) and Debian/APT (`gstreamer1.0-libav`), plus an **"Open with external player"** button. The most common failure for 4K MKV is `MEDIA_ERR_SRC_NOT_SUPPORTED` (error code 4), caused by H.265/HEVC not being available through GStreamer.

  **2. `muted` attribute on Quick Look video** — the `<video>` element had `muted` set, so all sound was silenced. Removed. Quick Look now plays with audio.

  **3. Media server Nagle's algorithm stalling GStreamer range requests** — GStreamer's souphttpsrc makes many small HTTP range requests during MKV container parsing and seek probing (reading index clusters, codec private data, etc.). With Nagle enabled, the OS batches outgoing data and waits up to ~200ms before flushing each small response, serialising these requests. For a large 4K file where the index is at the end, this causes a visible stall before playback starts. Fixed by calling `s.set_nodelay(true)` on each accepted TCP connection in `start_media_server`. Media server read buffer also increased from 64 KB → 256 KB (`vec![0u8;262144]`) to reduce per-chunk syscall overhead when streaming large files.

  > **Requires Rust recompile** — `main.rs` modified (`set_nodelay`, buffer size).

---

## What's in Alpha-12-r30

### Feature / Bug Fix
- **Quick Look is now a true floating window, separate from the file browser** — replacing the previous side-panel approach. QL now opens as an independent floating window with macOS-style window chrome (close dot in the top-left, title centered, file size + counter on the right), a deep drop-shadow, rounded corners, and no backdrop overlay. It sits on top of FrostFinder without covering or dimming it, just like GNOME Sushi / Nautilus Quick Preview does.

- **Draggable** — the title bar is a full drag handle. Clicking and dragging moves the QL window freely. On first drag the window transitions from CSS-centered positioning to absolute `left`/`top` so it stays exactly where you place it.

- **FrostFinder icon highlight follows arrow key navigation while QL is open** — this was broken because `ql.focus()` was stealing keyboard focus from the main window, so arrow keys went to QL's own handler (which only updated the preview) instead of to main.js (which moves the selection highlight and then updates the preview). Fix: `ql.focus()` removed entirely and QL's own arrow-key `keydown` listener removed. All navigation is now handled exclusively by main.js. The only key QL listens for is `Escape` (via a capture-phase document listener that is removed when QL closes).

- **No flash on arrow navigation** — previously, every arrow key press called `openQuickLook` which did `ql.remove()` then recreated the whole div, causing the window to flash and reset its position. Now a module-level `_qlUpdate` hook is exposed. When `openQuickLook` is called while QL is already open, it routes through `_qlUpdate` which patches only the title bar text and body content in-place, leaving the window's position, size, and scroll state unchanged.

  Implementation summary (`src/views.js`):
  - `_qlBody()` helper unchanged.
  - Module-level `let _qlUpdate = null` — set on open, cleared on close.
  - `openQuickLook` checks `document.getElementById('quicklook') && _qlUpdate` at the top; if true, calls `_qlUpdate(...)` and returns immediately without touching the DOM structure.
  - `renderContent()` closure handles all innerHTML updates and re-wires buttons after each refresh.
  - `_attachDrag()` wires the titlebar drag after each `renderContent()` (idempotent via `_dragWired` flag).
  - Escape key handled via `document.addEventListener('keydown', handler, true)` (capture phase) — no focus required.
  - `ql.tabIndex` not set, `ql.focus()` not called.
  - `quickLookNavigate` retained as a no-op stub for backward compatibility.

---

## What's in Alpha-12-r29

### Feature
- **Quick Look opens as a side panel beside FrostFinder** — Quick Look no longer appears as a centered modal overlay that covers the file browser. It now slides in from the left as a fixed side panel (`--ql-panel-w: 440px`) while the main FrostFinder window shifts right to sit beside it. Both panels are fully visible and usable simultaneously. Pressing Space, Escape, or the ✕ button collapses the panel and slides the app back to full width.

  Implementation details:
  - `#quicklook` changed from `position:fixed;inset:0` (full-screen overlay) to a left-edge panel (`position:fixed;left:0;top:0;bottom:0;width:var(--ql-panel-w)`).
  - `.ql-backdrop` hidden — no dim/blur overlay needed.
  - `.ql-window` restyled to fill the panel (transparent background, no rounded corners or drop-shadow).
  - New `body.ql-side .window { left:var(--ql-panel-w) }` rule shrinks the app window to the right portion of the screen when the panel is open.
  - `.window` gains `transition:left .2s ease` so the shift in/out animates smoothly.
  - `openQuickLook` adds `document.body.classList.add('ql-side')` on open; all close paths (✕ button, Escape, Space toggle, backdrop click) call `document.body.classList.remove('ql-side')` before removing the element.
  - `--ql-panel-w` CSS variable in `:root` for easy width adjustment.

---

## What's in Alpha-12-r28

### Bug Fix / Feature
- **Quick Look arrow navigation follows icon grid layout** — previously, pressing ↑/↓ while Quick Look was open in icon view moved to the previous/next file in a flat list (same as ←/→), ignoring the visual grid. Now all four arrow keys navigate spatially within the grid:
  - `↑` — show the file one row above (jumps back `cols` positions in the entry list)
  - `↓` — show the file one row below (jumps forward `cols` positions)
  - `←` — show the file one cell to the left
  - `→` — show the file one cell to the right

  If the target cell is a folder it is skipped and the nearest file in the travel direction is used instead. In list, column, and gallery views the behaviour is unchanged: ←/↑ = previous file, →/↓ = next file.

  Implementation: `openQuickLook` now accepts an `iconCols` parameter and keeps a `curAllIdx` cursor (position in the full entry list, dirs + files) alongside the existing `curIdx` (position in the files-only list used for the ‹ › buttons and the N/M counter). The call sites in `main.js` now pass `entries` (all entries) + `curIdx` (index in all entries) + `state._iconCols` so the grid dimensions are available inside the overlay.

---

## What's in Alpha-12-r27

### Feature
- **Empty Trash banner** — when navigating to the Trash folder (`~/.local/share/Trash`), a slim banner appears between the breadcrumb toolbar and the file list. It shows a reminder that items in Trash will be permanently deleted when emptied, and an **Empty Trash** button on the right. Clicking it shows a confirmation dialog then calls `empty_trash` and refreshes the view. The banner hides automatically when navigating away from Trash. Implemented as a persistent `#trash-banner` div in the HTML that `renderTrashBanner()` shows/hides and repopulates on every render cycle.

---

## What's in Alpha-12-r26

### Bug Fix
- **Column view collapses to one column after any file operation** — the same root cause as r24 (drag-and-drop), but affecting all other file operations: delete, rename, create folder/file, compress, extract, undo, redo, clipboard paste, and empty trash. All of them called `refreshCurrent()` after completing, which calls `navigate(state.currentPath, 0, false)` — that wipes `state.columns` with `splice(0)` and rebuilds a single column.

  Fixed by replacing every post-operation `refreshCurrent()` call with `refreshColumns()`, which reloads each open column's directory listing in-place via `Promise.all` and re-renders without touching the column structure. In non-column views `refreshColumns()` still falls back to `refreshCurrent()` so behaviour is unchanged elsewhere.

  The four `refreshCurrent()` calls intentionally left unchanged: the function definition itself, the fallback inside `refreshColumns`, the filesystem watcher (which fires outside any user action context), and the F5 / Cmd+R explicit full-refresh shortcut.

---

## What's in Alpha-12-r25

### Breadcrumb improvements
- **Separator changed from `›` to `/`** — matches the design shown in screenshots; plain forward-slash between path segments, consistent with how file paths look everywhere.
- **Active (last) segment now bold white** — the current directory name is rendered in full white at `font-weight:600`; ancestor segments remain muted gray, making it immediately clear where you are.
- **Whole rail is click-to-edit** — previously only the invisible deadspace region to the right of the last pill would trigger path-edit mode. Now clicking anywhere on the breadcrumb rail that isn't a pill or ellipsis (including gaps between pills and the empty right area) enters edit mode, which is more discoverable.
- **Clear button in path-input mode** — the `✕` button on the right of the input clears the field without dismissing edit mode, so you can type a new path from scratch without having to select-all first. Uses `mousedown` + `preventDefault` so it doesn't blur the input.
- **Input field redesign** — the path input now fills the entire rail as a single wrapped container (`bc-input-wrap`) with a darker background and blue border, matching the look in the screenshot.

---

## What's in Alpha-12-r24

### Bug Fix
- **Column view collapses to one column after drag and drop** — `setupDropTarget` called `refreshCurrent()` on every successful drop. `refreshCurrent()` calls `navigate(state.currentPath, 0, false)`, and inside `navigate` the column view branch does `state.columns.splice(0)` — wiping the entire column stack — then pushes back a single new column for `state.currentPath`. All other open columns were gone.

  Fixed with a new `refreshColumns()` function that reloads every open column's directory listing in-place using `Promise.all`, preserving the full column stack, selections, and scroll positions. The drop handler now calls `refreshColumns()` instead of `refreshCurrent()`. In non-column views `refreshColumns()` falls back to `refreshCurrent()` as before.

---

## What's in Alpha-12-r23

### Bug Fixes — Column View

- **Arrow key directions corrected (again)** — Left and Right were still swapped from what was intended:
  - `→` Right — navigates INTO the highlighted folder, opening it as a new column.
  - `←` Left — goes back to the parent column, restoring its selection.

- **Drag and drop glitching** — `dragover` was not calling `e.stopPropagation()`. Both the directory frow and its parent `colList` are registered as separate drop targets. When dragging over a directory row, `dragover` fired on the frow (adding `drop-over`), then bubbled up to the `colList` (adding `drop-over` there too) — two overlapping blue outlines simultaneously. As the cursor moved between items, `dragleave` fired on each level at different times causing the highlights to flash and flicker. The `drop` handler already had `stopPropagation` (added in r20); `dragover` now has it too, so only the most specific drop target under the cursor highlights at any time.

---

## What's in Alpha-12-r22

### Bug Fix
- **Click to deselect had no visual effect in icon view** — `paint()` has an early-return guard at the top:
  ```js
  if (startRow === _rendered.start && endRow === _rendered.end) return;
  ```
  When the user clicks on empty space, the scroll position hasn't changed, so `startRow`/`endRow` are identical to the previous paint — `paint()` returns immediately and does nothing. `sel.clear()` had already run and correctly cleared the selection in state, but the DOM was never updated so items kept their `.sel` highlight.

  The correct function to call here is `d().render()`, which goes through `renderIconView`'s incremental path — that path walks every currently-rendered `.icon-item` element and calls `item.classList.toggle('sel', sel.hasp(e.path))`, which is exactly what's needed to visually deselect items without a full DOM rebuild.

  The same `paint()` bug affected the icon view contextmenu handler: right-clicking an unselected item called `sel.set(idx)` then `paint()` — the item state was updated but the `.sel` class was never added visually. Fixed the same way.

  List view, column view, and gallery view were unaffected — their deselect handlers call `render()` which always does a full rebuild.

---

## What's in Alpha-12-r21

### Bug Fix
- **Drag and drop into subfolders blocked (column view)** — the drop guard introduced in r20 was:
  ```js
  if(destPath === srcPath || destPath.startsWith(srcPath + '/')) return;
  ```
  `srcPath` is the **parent directory** of the dragged file, not the file itself. So dragging `Documents/file.txt` (srcPath = `/home/user/Documents`) onto `Documents/Projects/` (destPath = `/home/user/Documents/Projects`) hit the `startsWith` check and was silently blocked — making every drop onto any subfolder within the same column impossible.

  Fixed: the same-dir check (`destPath === srcPath`) is kept, but the descendant check now correctly tests each *dragged entry* individually: only blocks if a dragged item is itself a directory and `destPath` is that directory or inside it.

---

## What's in Alpha-12-r20

### Bug Fixes — Column View: Drag & Drop + Arrow Keys

**Drag and drop**

- **Root cause: wrong `srcPath`** — `dragState.srcPath` was set to `state.currentPath`, which in column view is always the *deepest open column*, not the column the file is actually being dragged from. The drop guard `if(destPath===dragState.srcPath)return` then blocked every valid cross-column drop. Fixed: `srcPath` is now computed from the dragged entry's own parent directory (`entry.path.slice(0, lastIndexOf('/'))`) — correct for all views.
- **`dragleave` firing on child elements** — every time the cursor moved from a `.frow` into one of its child spans (`.fico`, `.fname`, `.fchev`), `dragleave` fired and `drop-over` was removed. This made it visually impossible to hold the cursor steady over a drop target, and on some WebKitGTK versions prevented the `drop` event from registering. Fixed: `dragleave` now checks `relatedTarget` — only removes `drop-over` when the cursor actually exits the element, not when it moves between children.
- **Drop event propagation** — added `e.stopPropagation()` to the `drop` handler so drops on a directory frow don't also bubble to the parent `col-list` drop target.
- **Folder-into-itself guard** — added a check `destPath.startsWith(srcPath+'/')` to prevent moving a folder into one of its own descendants.
- **Directory frows as drop targets** — directory rows in column view now register as drop targets, so you can drag files directly onto a folder in any column.

**Arrow keys**

- **Left/Right were inverted** — corrected:
  - `←` Left — navigates INTO the highlighted folder, opening it as a new column to the right.
  - `→` Right — goes back to the parent column, restoring its previous selection highlight.
- **`state.currentPath` not updated on go-back** — after pressing Right to pop the last column, `state.currentPath` wasn't updated to the parent's path. `getVisibleEntries()` then searched for a column matching the stale path and returned `[]`, breaking Up/Down after any go-back. Fixed.
- **`sel._e` not restored on go-back** — `sel.set()` uses `sel._e[i].path`, but `sel._e` still pointed at the now-removed column's entries. Fixed: `sel._e` is now reassigned to the parent column's sorted/filtered entries before calling `sel.set()`.
- **Up/Down scroll** — selected row now scrolls into view with `behavior:'smooth'` after Up/Down navigation.

---

## What's in Alpha-12-r19

### Quality of Life
- **Click empty space to deselect** — clicking anywhere outside file items now clears the selection in all four views. Previously only right-click on empty space (context menu trigger) would clear selection; a plain left-click did nothing.

  - **Icon view** — `mousedown` on the wrap background (not targeting `.icon-item`) immediately clears selection and calls `paint()`. The rubber-band drag callback was also fixed: dragging over empty space and releasing (zero items hit, non-additive) now explicitly deselects rather than silently returning. This means drag-to-select → miss → release = deselected, which matches expected behaviour.
  - **List view** — `mousedown` on `.list-wrap` background (not targeting `.list-row`) clears selection.
  - **Column view** — `mousedown` on the columns container background (not targeting `.frow`) clears selection.
  - **Gallery view** — clicking between thumbnails in the strip (the delegated `click` on `#gallery-strip` where no `.gthumb` is found) clears selection and resets `gallerySelIdx`.

  All handlers respect modifier keys: `Ctrl`, `Meta`, and `Shift` clicks on empty space are ignored so that modifier+drag workflows are not broken.

---

## What's in Alpha-12-r18

### Bug Fix
- **MKV (and other video) files play audio/controls but show a black frame** — the `WEBKIT_DISABLE_DMABUF_RENDERER` environment variable was explicitly set to `0` (enabled). When DMA-BUF rendering is active alongside VA-API hardware decoding, WebKit tries to composite decoded video frames directly from GPU memory via the DMA-BUF path. Many GPU/driver combinations (AMD, Intel, NVIDIA with nouveau) cannot complete this path — the GStreamer pipeline initialises, audio decodes and plays, seek/pause work, but every video frame is composited as black. Three env var changes fix this:

  - `WEBKIT_DISABLE_DMABUF_RENDERER=1` — disables the DMA-BUF compositor path, forces WebKit to use a GL texture-upload path instead. This works universally across GPU drivers.
  - `GST_GL_PLATFORM=egl` — tells GStreamer to use EGL as its GL platform so it shares the same GL context as WebKit. Required for the GL texture-upload path to work correctly on Wayland.
  - `WEBKIT_USE_GSTREAMER_GL=0` — disables the GStreamer-GL integration. When combined with DMA-BUF disabled, leaving this on causes a conflict where GStreamer outputs frames via a GL path that WebKit's non-DMA-BUF compositor doesn't know how to receive, resulting in the same black-frame symptom.

  VA-API hardware decoding (`GST_VAAPI_ALL_DRIVERS=1`) is kept enabled — GStreamer will still decode using hardware acceleration, it just won't attempt to hand frames off via DMA-BUF.

> **Requires Rust recompile** — `src-tauri/src/main.rs` modified (startup env vars only).

---

## What's in Alpha-12-r17

### Bug Fixes
- **Some MKV files would not play** — three bugs in the HTTP media server (`src-tauri/src/main.rs`):

  1. **`Content-Range` was included on every HTTP response, including `200 OK`** (the root cause). RFC 7233 §4.1 says `Content-Range` must only appear on `206 Partial Content` responses. WebKit's GStreamer `souphttpsrc` element detects the contradiction (200 status but Content-Range present) and fails to initialise the GStreamer pipeline. Files that only need a single sequential read (small/simple MKVs) played fine; files where GStreamer issues a seek probe during demux init (larger MKVs, H.265, multi-track containers) failed silently. Fixed: `200 OK` responses now omit `Content-Range`; `206 Partial Content` responses include it as required.

  2. **`start` was not validated against `file_size`** — if a client sent `Range: bytes=N-` with `N ≥ file_size`, `end` was clamped to `file_size-1` but `start` remained larger, causing `end - start + 1` to underflow as `u64` (wraps to a huge value). The server would then try to read billions of bytes, immediately get EOF, and send a truncated response. Fixed: returns `416 Range Not Satisfiable` with `Content-Range: bytes */{file_size}` when `start ≥ file_size`.

  3. **No `Connection: close` header** — the server handles exactly one request per thread then closes the socket. Without `Connection: close` the browser assumes HTTP/1.1 keep-alive and tries to reuse the connection for subsequent range requests (e.g. seeking). Fixed: all responses now include `Connection: close`.

- **Video playback failures were silent** — both the gallery view and the preview panel had no `onerror` handler on `<video>` elements. When playback failed the loading spinner showed indefinitely. Fixed: a helper `_makeVideoEl()` builds the video element with an `onerror` callback that replaces the spinner with an error panel showing the reason (codec error vs network error) and an "Open with external player" button that calls `open_file` for system-default launch.

> **Requires Rust recompile** — `src-tauri/src/main.rs` modified (HTTP media server).

---

## What's in Alpha-12-r16

### Features
- **Nautilus-style breadcrumb rail** — The plain text breadcrumb and drag-resize handle have been replaced with an interactive pill rail:
  - **Pill buttons** — each path segment is a rounded pill button with a hover highlight. Root shows a home icon. The active (current) folder pill is visually distinct with a brighter background and border.
  - **Chevron separators** — `›` glyphs between pills, non-interactive.
  - **Overflow elision** — paths deeper than 5 segments collapse the middle into a `…` pill. Clicking `…` opens a small popover listing the hidden intermediate folders; clicking any navigates directly to it.
  - **Deadspace hit target** — the empty area to the right of the last pill is a `cursor:text` hit target. Clicking it activates inline path-edit mode.
  - **Inline path input (Ctrl+L or click deadspace)** — breadcrumbs are replaced by a focused text input pre-filled with the current absolute path. Press Enter to navigate (absolute path) or trigger a search (no leading `/`). Press Esc or click away to dismiss without navigating. Zero toolbar rebuild — only the rail `innerHTML` is swapped, search focus is never disturbed.
  - **Search mode label** — when in search mode the rail shows "Results for X — N items" with the live searching… badge, same as before but now with deadspace so Ctrl+L still works.
  - **Keyboard**: `Ctrl+L` enters edit mode, `Esc` exits it (before clearing search), `Enter` navigates or searches.

---

## What's in Alpha-12-r15

### Bug Fixes
- **Gallery view glitch when navigating between files** — Every thumbnail click and arrow key triggered a full `host.innerHTML` wipe-and-rebuild of the entire gallery DOM (main area + toolbar bar + entire strip). This caused: a visible blank flash while the new image loaded from the HTTP media server; the strip scroll position jumping to 0; all already-loaded thumbnail `<img>` elements being discarded and re-fetched from scratch; the `IntersectionObserver` being torn down and recreated on every navigation.

  **Fix — incremental update path:** `renderGalleryView` now stores `host._galleryMeta = {path, count}` after each full build. On subsequent calls within the same directory, it takes a fast incremental path instead:
  - Replaces only `#gallery-main` innerHTML (new file's content slot)
  - Replaces only `.gallery-bar` innerHTML (zoom/open controls)
  - Toggles `.sel` class on existing gthumb elements in-place — the strip DOM, thumb `<img>` tags, and scroll position are completely untouched
  - Loads media content into the already-inserted slot, binds zoom controls, applies zoom
  - Full rebuild only happens when navigating to a new directory or on first render

  Strip thumbnail click/dblclick handlers converted to **event delegation** on `#gallery-strip` (one listener, attached once per full build) instead of per-element listeners re-attached on every render.

  `_doRender()` invalidates `host._galleryMeta` on directory change (alongside existing `_ivMeta` invalidation for icon view) so a directory navigation always triggers a clean full rebuild.

---

## What's in Alpha-12-r14

### Features
- **Scroll-to-selected on view switch** — Switching view modes (icon / list / column / gallery) now always scrolls the previously selected item into the center of the viewport. Previously the scroll only fired when multi-select paths were saved; now it fires unconditionally for any `selIdx ≥ 0`. Uses two nested `requestAnimationFrame` calls so the DOM finishes painting (including virtual-scroll layout) before computing scroll position. All views use `block:'center'` so the item lands in the middle of the viewport, not at the edge.

- **Gallery view syncs selection on switch** — When switching to gallery view, `gallerySelIdx` is now explicitly set to `savedSelIdx` so the strip and main preview both show the item that was selected in the previous view.

- **Right-click → "Open With…"** — Right-clicking any file now shows an "Open With…" option (hidden for directories and multi-select). Clicking it opens a modal dialog that:
  - Reads all installed `.desktop` application entries from `/usr/share/applications`, `/usr/local/share/applications`, `/var/lib/flatpak/exports/share/applications`, and `~/.local/share/applications` (including Flatpak user installs).
  - Filters out `NoDisplay=true` and `Hidden=true` entries; strips `%f/%F/%u/%U` exec placeholders.
  - Deduplicates by app name, sorts alphabetically.
  - Shows a live search field to filter by app name.
  - Clicking an app launches it with the file path as the argument via a new `open_with_app` Tauri command.

> **Requires Rust recompile** — `main.rs` modified (new `list_apps_for_file`, `open_with_app` commands).

---

## What's in Alpha-12-r13

### Bug Fixes
- **Gallery strip: labels still invisible/cropped (r12 partial fix)** — r12 fixed the class name (`gthumb-name` → `gthumb-lbl`) but the label remained hard to read due to `contain: layout style paint` on `.gthumb` restricting painting, and `align-items:center` on `.gallery-strip` sometimes clipping tall items. Full fix: removed `contain` from `.gthumb` (kept it on all other interactive items), changed strip to `align-items:flex-end` so thumbs sit flush at the bottom, rewrote `.gthumb-lbl` to use `flex:1; display:flex; align-items:center` — a dark `rgba(0,0,0,.45)` backing fills the label zone guaranteeing white text is always readable regardless of thumbnail content. Strip height 128px → 136px, gthumb height 106px → 118px, icon area 60px → 64px.
- **Window title still showed α12-r1** — `tauri.conf.json` title string was never updated after r1. Updated to `FrostFinder α12-r13` so the running revision is always visible in the title bar.

### Visual Changes
- **Sidebar +/− buttons** — Buttons confirmed in FAVORITES header right edge (moved in r12). Restyled to blue tint (`rgba(96,165,250)`) making them visually distinct from the section label and easier to spot.

> **Requires Rust recompile** — `tauri.conf.json` changed (window title).

---

## What's in Alpha-12-r12

### Bug Fixes
- **Gallery strip labels invisible/cropped** — The thumbnail label `<span>` in `renderGalleryView` was using class `gthumb-name` which had no CSS definition (the stylesheet targets `.gthumb-lbl`). Fixed by correcting the class name to `gthumb-lbl` in `views.js`. Additionally improved label styling: font size raised from 8.5px → 10.5px, weight set to 500, color hardened to `#e8e8ea` (vs inheriting a dim tertiary variable), `white-space:nowrap` replaced with `display:-webkit-box; -webkit-line-clamp:2; word-break:break-word` so long names wrap to two lines instead of being silently truncated. Thumbnail height increased 88px → 106px and strip height 110px → 128px to accommodate the extra line.

### Features
- **Sidebar +/− size buttons moved to Favorites header** — The sticky `sb-size-footer` at the bottom of the sidebar has been removed. The `−` and `+` buttons now live inline at the right edge of the **FAVORITES** section header, keeping them always visible without consuming persistent footer space. The `sb-title` row is now `display:flex; justify-content:space-between` so the buttons float right without affecting the uppercase label.

---

## What's in Alpha-12-r11

### Bug Fixes
- **Unused variable warning in `lsblk_unmounted_all`** — The `mounted_mnts` parameter (a `HashSet<String>` of already-shown mountpoints) was declared in the function signature but never read inside the body — the function already filters by device path via `mounted_devs` and by lsblk-reported mountpoints directly. Renamed to `_mounted_mnts` to suppress the `#[warn(unused_variables)]` compiler warning while preserving the parameter for API compatibility.

> **Requires Rust recompile** — `main.rs` modified (`_mounted_mnts` rename in `lsblk_unmounted_all`).

---

## What's in Alpha-12-r10

### Bug Fixes
- **Right-click scroll jump in list view** — `contextmenu` on a list row called `render()` which rebuilt `host.innerHTML`, destroying `.list-wrap` and resetting its `scrollTop`. Fixed by snapshotting `listWrap.scrollTop` before `render()` and restoring it in the next `requestAnimationFrame`. Same fix applied to the flat list (search results) view.
- **Right-click scroll jump in column view** — Same root cause. Fixed by snapshotting all `.col-list` scroll positions before `render()` and restoring them in an RAF, matching what the left-click handler already does.
- **Root Disk, cache, tmp hidden from sidebar** — `classify_drive` now explicitly hides `/` (Root Disk) plus any mountpoint whose last path segment is `cache`, `tmp`, `log`, `lost+found`, `proc`, or `sys`. The exact-hide list was also extended to cover `/root` and `/srv`.

### Features
- **Sidebar size +/- buttons** — A sticky footer at the bottom of the sidebar has `−` and `+` buttons that scale all sidebar text and icons between 75%–140% of their base size. Uses the CSS custom property `--sb-scale` applied to `font-size`, `padding`, and icon `width`/`height` via `calc()`. Scale persists to `localStorage` as `ff_sb_scale`.

---

## What's in Alpha-12-r9

### Bug Fixes
- **System partitions hidden from sidebar** — `boot`, `cache`, `log`, `root`, `srv`, `tmp`, and `/boot` paths are now excluded in `classify_drive()`. Added explicit `exact_hide` list and also moved `/boot/*` into the prefix-filter so partitions like `/boot/efi` no longer appear. The sidebar now shows only meaningful storage: Root Disk, your named NVMe/SSD/HDD data partitions, USB drives, and network mounts.
- **Icon view click glitch (flash to blank then back)** — Root cause: every `render()` call in icon view destroyed `host.innerHTML` and rebuilt the entire virtual scroller from scratch, creating a blank frame. Fix: `renderIconView` now checks if `#iv-wrap` already exists for the same `{path, iconSz, count}`. If yes, it does an **incremental repaint** — walks only currently-rendered items, toggles `.sel` class and inline styles, and returns immediately without touching the DOM structure. Full rebuild only happens on directory change, icon size change, or entry count change. `_ivMeta` is stamped on `host` after every full build and invalidated in `_doRender` when the path changes.

### Features  
- **Resizable sidebar** — A 4px drag handle sits between the sidebar and content area. Drag it left/right to resize between 120px–400px. Width is persisted to `localStorage` as `ff_sb_w` and restored on startup. The handle highlights blue on hover and during drag.

> **Requires Rust recompile** — `main.rs` modified (system mount filter expanded).

---

## What's in Alpha-12-r8

### Bug Fixes
- **Gallery folder names unreadable** — `.gthumb-lbl` was using `var(--text-secondary)` (#98989f grey) making folder titles barely visible against the dark strip background. Changed to `var(--text-primary)` (#e8e8ea) so all labels are clearly white. Selected thumbs get full `#fff`. 
- **Sidebar/toolbar color change during icon view scroll** — The `body.is-scrolling` CSS rule (used to disable `backdrop-filter` during scrolling for performance) also applied `background: rgba(18,18,22,0.97)` — a near-black color visibly different from the actual sidebar `#252528` and toolbar `#2a2a2d`. The wrong background override has been removed; the rule now only disables backdrop-filter (which is the performance goal).
- **Icon view glitches on click** — Two root causes fixed: (1) `content-visibility: auto` on `.icon-item` was causing the browser to re-evaluate item visibility every time selection changed, producing a paint flash — removed. (2) Scroll restoration was setting `wrap.scrollTop` after `paint()` in an RAF, but the browser first paints a frame with `scrollTop=0`. Fixed by pre-computing spacer height (same formula as `paint()`) *before* setting `scrollTop` in the RAF, so the browser's first composite of the new `iv-wrap` already has the correct scroll position.
- **Only NVMe unmounted partitions now show all drives** — `lsblk_unmounted_removable` previously filtered to `rm=true` (hotplug/removable flag), excluding NVMe/SSD/HDD secondary partitions entirely. Replaced with `lsblk_unmounted_all` which scans every block device, uses the `TRAN` field (usb/nvme/sata/ata) plus device name prefix and `is_rotational()` to correctly classify each unmounted partition as nvme/ssd/hdd/usb, and filters out unformatted/swap partitions. The Fedora NVMe partition will now appear with a "Not mounted — click to mount" entry in Locations.

> **Requires Rust recompile** — `main.rs` modified (`lsblk_unmounted_all` replaces `lsblk_unmounted_removable`).

---

## What's in Alpha-12-r7

### Bug Fixes
- **Icon view jumps to top on click** — Clicking any file while scrolled down caused the view to snap back to the top. Root cause: `handleEntryClick` triggers `render()` → `renderIconView(host)` which wipes `host.innerHTML` and creates a fresh `#iv-wrap` at `scrollTop=0`. Fix: snapshot `{path, top}` into `state._iconScroll` in both the click handler (before `handleEntryClick`) and in `_doRender` (before the rebuild), then restore `wrap.scrollTop` in the first `requestAnimationFrame` of the new `renderIconView`. Restores only when the path hasn't changed (navigating to a new folder correctly resets scroll to 0).

### Features
- **Unmounted drives visible in sidebar** — Sidebar now shows USB/removable drives that are plugged in but not yet mounted (e.g. CachyOS doesn't auto-mount by default). They appear dimmed with a green "Not mounted — click to mount" sublabel and a ↓ mount button. Powered by a new `lsblk -J` scan (`lsblk_unmounted_removable()`) that runs alongside `/proc/mounts` parsing in both `get_drives()` and `get_sidebar_data()`. Drives are sorted: mounted before unmounted within each type.
- **One-click mount** — The mount button (↓) on an unmounted drive calls the new `mount_drive(device)` Tauri command which runs `udisksctl mount -b /dev/sdXN`. If udisksctl triggers a Polkit popup for privileges, it will appear natively. On success the sidebar refreshes and FrostFinder navigates to the new mountpoint automatically.
- **Hot-plug detection now fires on plug, not just mount** — The background watcher previously only triggered on `/proc/mounts` changes, so a USB that required manual mounting never caused the sidebar to update. The watcher now also snapshots `/sys/block` directory listing (block device names), fires `drives-changed` when either source changes, and includes unmounted drives in the emitted payload.

> **Requires Rust recompile** — `main.rs` modified (new `lsblk_unmounted_removable`, `collect_drives_with_unmounted`, `mount_drive` command, updated watcher).

---

## What's in Alpha-12-r6

### Bug Fixes
- **Icon view name truncation** — File names were clipped to 2 lines even when more space was allocated. Increased `.ico-lbl` `-webkit-line-clamp` from 2→3 and bumped `ITEM_H` from `iconSz+62` to `iconSz+78` to give the third line room to breathe. Long names like `_Inuman Sessions Vol. 2_ Pangarap…` are now fully visible.
- **Scroll bleeds sidebar/toolbar color** — Scrolling the icon view caused WebKitGTK to repaint the full composite frame, making the transparent `html`/`body` background bleed through the sidebar and toolbar momentarily. Fixed by: (1) adding `overscroll-behavior:none` to `html`, `body`, and the `#iv-wrap` scroll container; (2) adding `will-change:transform; isolation:isolate` to `.sidebar`, `.toolbar`, and `.titlebar` so they live on separate GPU compositing layers and never re-composite with the view area.
- **USB drives not appearing in sidebar** — Two issues: (a) the `drives-changed` Tauri event handler captured `prev` *after* already overwriting `state.sidebarData.drives`, so the old drive list was lost and the USB connect/disconnect toast could never fire; (b) the fallback polling interval was 2 s. Fixed the variable capture order and tightened polling to 1 s.
- **No way to clear search quickly** — Added an `✕` clear button inside the search bar that appears whenever there is text in the field (via `:has(input:not(:placeholder-shown))`). Clicking it instantly clears the query, exits search mode, and refocuses the input — same effect as pressing Escape.

---

## What's in Alpha-12-r5

### Bug Fixes
- **Gallery view JS syntax error** — `renderGalleryView` body (zoom controls, click handlers, content loaders) plus `_setupThumbObserver`, `_loadGthumb`, and `openLightboxUrl` were accidentally swallowed into the `host.innerHTML` string assignment, causing Vite's import-analysis plugin to throw a JSX parse error on the unescaped `<div` inside `lb.innerHTML`. Rewrote the `host.innerHTML` assignment as a proper backtick template literal, rebuilt the `.gthumb` strip via a `stripHtml` generator, and restored all logic as executable code.

---

## What's in Alpha-12-r4

### Bug Fixes
- UI polish and incremental fixes carried forward into r5.

---

## What's in Alpha-12-r3

### Bug Fixes
- Column view rendering and scroll position improvements.

---

## What's in Alpha-12-r2

### Bug Fixes
- Minor gallery view stability fixes and render pipeline corrections from r1.

---

## What's in Alpha-12-r1

### Bug Fixes
- **Gallery view parse error** — nested backtick template literals inside `host.innerHTML` caused Vite import analysis to fail. Fixed video/audio/doc slot innerHTML assignments to use string concatenation instead.
- **Column view Left/Right arrow keys** — handlers were dead code (generic Up/Down block returned before reaching them). Moved column arrow interception before the generic block.
- **Deep search root** — search was scoped to the deepest open subfolder in column view instead of the top-level navigated folder. Fixed to always use `columns[0].path`.
- **Search duplicate results** — parallel rayon search across top-level subdirs could return the same file from multiple workers. Added path-based dedup with a `Set`.
- **USB drive not appearing** — drives mounted under `/run/media/` or `/media/` now force type `usb` regardless of `is_usb_device()` sysfs result. `vfat`/`exfat`/`ntfs`/`fuseblk` filesystem types also trigger USB classification.
- **Gallery toolbar overlap** — Open button and zoom controls floated over video player controls. Moved into a dedicated `gallery-bar` strip between the media area and thumbnail strip. Zoom hidden for video (has native controls).

### New Features
- **Search respects view mode** — search results now render in the active view (icon view → icon grid with thumbnails, gallery → gallery with preview). List and column fall back to flat list table.
- **Ctrl+Z Undo / Ctrl+Y Redo** — undo stack (50 ops) tracks paste operations (move/copy). Redo re-applies. Delete undo not supported (items go to Trash).
- **Drive type badges** — sidebar shows NVMe / SSD / HDD / USB / NET / OPT badges with type-specific colors.
- **Breadcrumb resize handle** — drag the thin handle between breadcrumb and toolbar buttons to redistribute space. Breadcrumb also scrolls horizontally when path is long.
- **USB hot-plug detection** — Rust background thread polls `/proc/mounts` every 1.5s and emits a `drives-changed` Tauri event on change. Sidebar updates instantly with a toast notification.

### Architecture Notes
- Search listeners use event delegation on `#toolbar` (attached once in `init()`, never re-attached on re-render)
- `getVisibleEntries()` returns `state.searchResults` in search mode — icon/gallery pick them up automatically
- Drive sort order: NVMe → SSD → HDD → USB → Optical → Network
- Undo stack: `state._undoStack[]` / `state._redoStack[]`, capped at 50 entries

---

## Known Issues / Limitations
- Undo only tracks paste (Ctrl+V) operations in this revision. Drag-and-drop moves are not yet tracked.
- Column view search falls back to flat list (column view requires a real directory tree).
- USB detection requires either `/run/media/` mount path OR `is_usb_device()` sysfs check passing. If your distro mounts USB elsewhere, check `classify_drive()` in `main.rs`.

---

## File Structure

```
frostfinder/
├── src/
│   ├── main.js          — app state, navigation, keyboard, search, sidebar, toolbar
│   ├── views.js         — renderColumnView, renderListView, renderIconView, renderGalleryView
│   ├── utils.js         — icons, fileColor, fileIcon, driveIcon, driveTypeBadge, fmtSize
│   ├── style.css        — all styles
│   └── search.worker.js — off-thread search/sort web worker
├── src-tauri/src/
│   └── main.rs          — Rust backend: filesystem, search, drives, thumbnails, media server
├── RELEASE.md           — this file
└── index.html
```

